#ifndef _APPVIDEODATA_H
#define _APPVIDEODATA_H

#include "appdata.h"

extern "C" {
    #include <dirent.h>

}

class APPVideoData : public APPData
{
    public:
        typedef enum {AVI, FOLDER} VideoType;

        APPVideoData();
        virtual ~APPVideoData();

        void LoadVideo(CImage* cimg, const string& pVideoDir, const string& pVideoName);
        void UnloadVideo();

        bool IsVideoOver();

        CImage* GetNextFrame(int pFrame = -1);

        int GetCurFrameID()
        {
            return mCurFrame;
        }

        int GetNFrames()
        {
            return mNFrames;
        }

    protected:

//        AVFormatContext* mAVFormatCtx;
//        AVCodecContext* mAVCodecCtx;
        int mVideoStream;
        int mFlag;

        unsigned int mCurFrame;
        unsigned int mNFrames;
        string mVideoDir;

        APPVideoData::VideoType mType;

        void _LoadAVI(const string& pVideoDir, const string& pVideoName);
        void _LoadVideoFolder(const string& pVideoDir);

        CImage* _NextAVIFrame();
        CImage* _NextVideoFolderFrame(int pFrame = -1);
};

#endif // _APPVIDEODATA_H
