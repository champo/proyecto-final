#include "appdata.h"

int main()
{
    APPData* a = new APPData();

    CImage* c = CreateCImage(10,10);
    a->CreateData(c,0,CreateAdjRel(3));
    Image* t = a->GetImage("seedLbMapSEG");

    if(t == NULL) printf("ok\n");
}
