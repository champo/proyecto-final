#include "commonsse.h"

inline float* AllocAlgnFloatArray(int n, int align)
{
    return (float *) _mm_malloc(n*sizeof(float),align);
}

inline int* AllocAlgnIntArray(int n, int align)
{
    return (int *) _mm_malloc(n*sizeof(int),align);
}

inline __m128 Mux2to1(const __m128 x, const __m128 y, const __m128 s)
{
    return _mm_or_ps(_mm_and_ps(x,s), _mm_andnot_ps(s,y));
}

float MinimumPS(__m128 A)
{
	__m128 tmp;

	tmp = _mm_min_ps(A, _mm_shuffle_ps(A,A,_MM_SHUFFLE(2,1,0,3)));
	tmp = _mm_min_ps(tmp, _mm_shuffle_ps(A,A,_MM_SHUFFLE(1,0,3,2)));
	tmp = _mm_min_ps(tmp, _mm_shuffle_ps(A,A,_MM_SHUFFLE(0,3,2,1)));

	float minimum[4] __attribute__((aligned(16)));
	_mm_store_ps(minimum,tmp);

	return minimum[0];
}

float MaximumPS(__m128 A)
{
	__m128 tmp;

	tmp = _mm_max_ps(A, _mm_shuffle_ps(A,A,_MM_SHUFFLE(2,1,0,3)));
	tmp = _mm_max_ps(tmp, _mm_shuffle_ps(A,A,_MM_SHUFFLE(1,0,3,2)));
	tmp = _mm_max_ps(tmp, _mm_shuffle_ps(A,A,_MM_SHUFFLE(0,3,2,1)));

	float maximum[4] __attribute__((aligned(16)));
	_mm_store_ps(maximum,tmp);

	return maximum[0];
}
