
#include "filelist.h"


FileList *CreateFileList(int cap){
  FileList *L;
  int i;

  L = (FileList *) calloc(1,sizeof(FileList));
  if(L == NULL)
    Error(MSG1,"CreateFileList");

  L->files = (char **) calloc(cap, sizeof(char *));
  if(L->files == NULL)
    Error(MSG1,"CreateFileList");

  for(i=0; i<cap; i++)
    L->files[i] = NULL;
  L->cap = cap;
  L->n = 0;

  return L;
}


void      DestroyFileList(FileList **L){
  FileList *aux;
  int i;

  aux = *L;
  if(aux != NULL){
    if(aux->files != NULL){
      for(i=0; i<aux->n; i++)
	if(aux->files[i]!=NULL)
	  free(aux->files[i]);
      free(aux->files);
    }
    free(aux);
    *L = NULL;
  }
}


FileList *ReadFileList(char *filename){
  char name[512];
  char msg[512];
  FileList *L;
  FILE *fp;
  int ret,i,j,n;

  fp = fopen(filename,"r");
  if(fp==NULL){
    sprintf(msg,"Cannot open %s",filename);
    Error(msg,"ReadFileList");
  }

  fscanf(fp,"%d",&n);
  L = CreateFileList(ROUND(1.10*n));

  for(i=0; i<n; i++){
    ret = fscanf(fp,"%d %[^\n]", &j, name);
    if(ret==EOF)
      Error("Bad or corrupted file",
	    "ReadFileList");

    AddFile(L, name);
  }

  fclose(fp);

  return L;
}


void      WriteFileList(FileList *L,
			char *filename){
  char msg[512];
  FILE *fp;
  int i;
  
  fp = fopen(filename,"w");
  if(fp == NULL){
    sprintf(msg,"Cannot open %s",filename);
    Error(msg,"WriteFileList");
  }

  fprintf(fp,"%d\n",L->n);
  for(i=0; i<L->n; i++)
    fprintf(fp,"%d %s\n",i,L->files[i]);
  
  fclose(fp);
}


void      DeleteFilesInFileList(FileList *L){
  char command[5000];
  int i;

  for(i=0; i<L->n; i++){
    sprintf(command,"rm %s -f",GetFile(L, i));
    system(command);
  }
}


void      AddFile(FileList *L, char *file){
  int s,n,i;

  TrimString(file);
  s = strlen(file);
  n = L->n;
  if(n < L->cap){
    L->files[n] = (char *) calloc(s+1,sizeof(char));
    strcpy(L->files[n], file);
    L->n++;
  }
  else{
    L->cap = ROUND(L->cap*1.25);
    L->files = (char **)realloc(L->files,
				L->cap*sizeof(char *));
    if(L->files == NULL)
      Error(MSG1,"AddFile");
    for(i=n; i<L->cap; i++)
      L->files[i] = NULL;
    AddFile(L, file);
  }
}


char     *GetFile(FileList *L, int index){
  if(index<0 || index>=L->n)
    return NULL;
  return L->files[index];
}


void  AddFiles(FileList *L,
	       char *path, 
	       char *basename, 
	       int first, int last,
	       char *ext){
  char name[512];
  int nfiles,i,s;

  s = strlen(path);
  if(s>0)
    if(path[s-1]=='/')
      path[s-1] = '\0';

  nfiles = last-first+1;
  for(i=0; i<nfiles; i++){
    sprintf(name,"%s/%s%03d%s",
	    path, basename, i+first, ext);
    AddFile(L, name);
  }
}


void  AddRandomFiles(FileList *L,
		     char *path, 
		     char *basename, 
		     int first, int last,
		     int nfiles,
		     char *ext){
  char name[512];
  int nfiles_max,i,j,s,tmp;
  int *file_id;
  
  s = strlen(path);
  if(s>0)
    if(path[s-1]=='/')
      path[s-1] = '\0';
  
  nfiles_max = last-first+1;
  if(nfiles>nfiles_max){
    sprintf(name,"Nfiles too great, using %d",nfiles_max);
    Warning(name,"AddRandomFiles");
    nfiles = nfiles_max;
  }

  file_id = AllocIntArray(nfiles_max);
  for(i=0; i<nfiles_max; i++)
    file_id[i] = i+first;
  for(i=0; i<nfiles_max; i++){
    j = RandomInteger(0, nfiles_max-1);
    tmp = file_id[i];
    file_id[i] = file_id[j];
    file_id[j] = tmp;
  }
  for(i=0; i<nfiles; i++){
    sprintf(name,"%s/%s%03d%s",
	    path, basename, file_id[i], ext);
    AddFile(L, name);
  }
  free(file_id);
}


void   RemoveFileExtension(char *file){
  int n = strlen(file);

  while(n>0){
    n--;
    if(file[n]=='/') break;
    if(file[n]=='.') file[n] = '\0';
  }
}


void   RemoveFileDirectory(char *file){
  int n,i;

  n = strlen(file);
  while(n>0){
    n--;
    if(file[n]=='/') break;
  }
  
  if(file[n]=='/') n++;

  i = 0;
  while(file[n]!='\0'){
    file[i] = file[n];
    i++; n++;
  }
  file[i] = '\0';
}


void      TrimString(char *str){
  int i,j,s,space;
  
  s = strlen(str);
  if(s==0) return;

  i = 0;
  j = s-1;

  while(i<s){
    space = 0;
    if(str[i]==' '  ||
       str[i]=='\t' ||
       str[i]=='\n')
      space = 1;
    if(!space)
      break;
    i++;
  }

  while(j>=0){
    space = 0;
    if(str[j]==' '  ||
       str[j]=='\t' ||
       str[j]=='\n')
      space = 1;
    if(!space)
      break;
    j--;
  }
  
  SubString(str, i, j);
}



void      SubString(char *str,
		    int beginIndex,
		    int endIndex){
  int i,j;

  if(beginIndex>endIndex){
    str[0] = '\0';
    return;
  }

  j = 0;
  for(i=beginIndex; i<=endIndex; i++){
    str[j] = str[i];
    j++;
  }
  str[j] = '\0';
}


