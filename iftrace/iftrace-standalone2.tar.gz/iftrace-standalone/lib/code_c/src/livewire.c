#include "livewire.h"

int *Path2Array(Image *pred, int dst)
{
    int *path=NULL,i,n,p;

    p = dst;
    n = 1;
    while (pred->val[p]!=NIL)
    {
        n++;
        p = pred->val[p];
    }

    path = AllocIntArray(n+1);
    path[0]=n;
    p = dst;
    i = 0;
    while (pred->val[p]!=NIL)
    {
        i++;
        path[i]=p;
        p = pred->val[p];
    }
    i++;
    path[i]=p;

    return(path);
}


int *iftLiveWire(Image *cost, Image *pred,
                 SparseGraph *g, Set **S,
                 int init, int src, int dst)
{
    Queue *Q=NULL;
    AdjRel *A = g->A;
    int i,p,q,n,tmp,pre,mincost=INT_MAX,weight;
    Pixel u,v;
    int *path=NULL;

    if (pred->val[init]==NIL)
    {
        cost->val[init] = INT_MAX;
    }

    if (pred->val[dst]==NIL)
    {

        n = g->ncols*g->nrows;
        Q = CreateQueue((int)pow(g->Wmax,1.5)+1,n);

        if (*S == NULL)
        {
            InsertSet(S,src);
            cost->val[src] = 0;
        }
        while (*S != NULL)
        {
            p = RemoveSet(S);
            if (cost->val[p] < mincost)
                mincost = cost->val[p];
            InsertQueue(Q,cost->val[p]%Q->C.nbuckets,p);
        }
        Q->C.current = mincost%Q->C.nbuckets;

        while (!EmptyQueue(Q))
        {
            p = RemoveQueue(Q);
            if (p==dst)
            {
                InsertSet(S,p);
                break;
            }
            u.x = p%g->ncols;
            u.y = p/g->ncols;
            for (i=1; i < A->n; i++)
            {
                v.x = u.x + A->dx[i];
                v.y = u.y + A->dy[i];
                if (ValidPixel(pred,v.x,v.y))
                {
                    q = v.x + pred->tbrow[v.y];
                    if (cost->val[p] < cost->val[q])
                    {
                        weight = (g->n_link[p])[i];
                        tmp = cost->val[p]+(int)pow(weight,1.5);
                        if (tmp < cost->val[q])
                        {
                            if (cost->val[q]==INT_MAX)
                                InsertQueue(Q,tmp%Q->C.nbuckets,q);
                            else
                                UpdateQueue(Q,q,cost->val[q]%Q->C.nbuckets,tmp%Q->C.nbuckets);
                            cost->val[q]  = tmp;
                            pred->val[q]  = p;
                        }
                    }
                }
            }
        }

        while (!EmptyQueue(Q))
        {
            p = RemoveQueue(Q);
            InsertSet(S,p);
        }

        DestroyQueue(&Q);
    }

    if (pred->val[init]!=NIL)
    {
        pre = pred->val[init];
        if (dst==init) tmp = pre;
        else          tmp = dst;
        pred->val[init] = NIL;
        path = Path2Array(pred,tmp);
        pred->val[init] = pre;
    }
    else
        path = Path2Array(pred,dst);

    return(path);
}




int *iftOLiveWire(Image *cost, Image *pred,
                  SparseGraph *g, Set **S,
                  Image *oimg, char orient,
                  int init, int src, int dst)
{
    Queue *Q=NULL;
    int i,p,q,n,tmp,pre,left,right,Cmax,mincost=INT_MAX,weight;
    Pixel u,v;
    AdjRel *L,*R,*A=g->A;
    int *path=NULL;

    if (pred->val[init]==NIL)
    {
        cost->val[init] = INT_MAX;
    }

    if (pred->val[dst]==NIL)
    {

        Cmax = (int)pow(g->Wmax,1.5);
        n = g->ncols*g->nrows;
        Q = CreateQueue(Cmax+1,n);

        if (*S == NULL)
        {
            InsertSet(S,src);
            cost->val[src] = 0;
        }
        while (*S != NULL)
        {
            p = RemoveSet(S);
            if (cost->val[p] < mincost)
                mincost = cost->val[p];
            InsertQueue(Q,cost->val[p]%Q->C.nbuckets,p);
        }
        Q->C.current = mincost%Q->C.nbuckets;

        L = LeftSide(A);
        R = RightSide(A);

        while (!EmptyQueue(Q))
        {
            p = RemoveQueue(Q);
            if (p==dst)
            {
                InsertSet(S,p);
                break;
            }
            u.x = p%g->ncols;
            u.y = p/g->ncols;
            for (i=1; i < A->n; i++)
            {
                v.x = u.x + A->dx[i];
                v.y = u.y + A->dy[i];
                if (ValidPixel(pred,v.x,v.y))
                {
                    q = v.x + pred->tbrow[v.y];
                    if (cost->val[p] < cost->val[q])
                    {
                        weight = (g->n_link[p])[i];
                        v.x = u.x + L->dx[i];
                        v.y = u.y + L->dy[i];
                        if (ValidPixel(pred,v.x,v.y))
                            left = v.x + pred->tbrow[v.y];
                        else
                            left = q;
                        v.x = u.x + R->dx[i];
                        v.y = u.y + R->dy[i];
                        if (ValidPixel(pred,v.x,v.y))
                            right = v.x + pred->tbrow[v.y];
                        else
                            right = q;
                        if (orient == 1)
                        {
                            if (oimg->val[left] < oimg->val[right])
                                tmp = cost->val[p]+(int)pow(weight,1.5);
                            else
                                tmp = cost->val[p]+Cmax;
                        }
                        else   /* assuming that orient is 2 */
                        {
                            if (oimg->val[left] > oimg->val[right])
                                tmp = cost->val[p]+(int)pow(weight,1.5);
                            else
                                tmp = cost->val[p]+Cmax;
                        }
                        if (tmp < cost->val[q])
                        {
                            if (cost->val[q] == INT_MAX)
                                InsertQueue(Q,tmp%Q->C.nbuckets,q);
                            else
                                UpdateQueue(Q,q,cost->val[q]%Q->C.nbuckets,tmp%Q->C.nbuckets);
                            cost->val[q] = tmp;
                            pred->val[q] = p;
                        }
                    }
                }
            }
        }

        while (!EmptyQueue(Q))
        {
            p = RemoveQueue(Q);
            InsertSet(S,p);
        }

        DestroyQueue(&Q);
        DestroyAdjRel(&L);
        DestroyAdjRel(&R);
    }

    if (pred->val[init]!=NIL)
    {
        pre = pred->val[init];
        if (dst==init) tmp = pre;
        else          tmp = dst;
        pred->val[init] = NIL;
        path = Path2Array(pred,tmp);
        pred->val[init] = pre;
    }
    else
        path = Path2Array(pred,dst);

    return(path);
}






