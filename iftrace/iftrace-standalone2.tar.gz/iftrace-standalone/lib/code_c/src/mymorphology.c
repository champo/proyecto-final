#include "mymorphology.h"

Image *CloseLabelHoles(Image *label, Image* root, int deflabel)
{
    AdjRel *A=NULL;
    Image *marker=NULL,*cimg=NULL;
    int x,y,i,j,Imax;

    Imax   = MaximumValue(label);
    marker   = CreateImage(label->ncols,label->nrows);
    SetImage(marker,Imax+1);
    for (y=0; y < marker->nrows; y++)
    {
        i = marker->tbrow[y];
        j = marker->ncols-1+marker->tbrow[y];
        marker->val[i] = label->val[i];
        marker->val[j] = label->val[j];
    }
    for (x=0; x < marker->ncols; x++)
    {
        i = x+marker->tbrow[0];
        j = x+marker->tbrow[marker->nrows-1];
        marker->val[i] = label->val[i];
        marker->val[j] = label->val[j];
    }
    A      = Circular(1.0);
    cimg   = LabelSupRec(label,marker,root,deflabel,A);
    DestroyImage(&marker);
    DestroyAdjRel(&A);

    return(cimg);
}

Image *LabelSupRec(Image *label, Image *marker, Image* root, int deflabel, AdjRel *A)
{
    Image *fcost=NULL,*cost=NULL,*flabel=NULL, *froot = NULL;
    Queue *Q=NULL;
    int i,sz,p,q,tmp,n;
    AdjPxl *N=NULL;

    sz  = FrameSize(A);
    flabel = AddFrame(label,sz,INT_MIN);
    fcost = AddFrame(marker,sz,INT_MIN);
    froot = AddFrame(root, sz, NIL);
    N  = AdjPixels(fcost,A);
    n = fcost->ncols*fcost->nrows;
    Q = CreateQueue(MaximumValue(marker)+1,n);

    for (p = 0; p < n; p++)
        if (fcost->val[p] != INT_MIN)
        {
            InsertQueue(Q,fcost->val[p],p);
        }

    while (!EmptyQueue(Q))
    {
        p=RemoveQueue(Q);

        /// if the hole is taken by deflabel
        /// sets its cost (final label) as deflabel
        /// or it will keep Imax+1 as its value
        if(froot->val[p] != NIL && label->val[froot->val[p]] == deflabel)
            fcost->val[p] = deflabel;

        for (i=1; i < N->n; i++)
        {
            q = p + N->dp[i];

            int proceed = 0;

            /// if pixel p label is an object label
            if(flabel->val[p] != deflabel)
            {
                /// and if q's root is NIL OR is not deflabel pixel
                /// proceed to conquer
                if(froot->val[q] == NIL || label->val[froot->val[q]] != deflabel)
                    proceed = 1;
            }else{
                proceed = 1;
            }

            if (fcost->val[p] < fcost->val[q] && proceed)
            {
                tmp = MAX(fcost->val[p],flabel->val[q]);
                if (tmp < fcost->val[q])
                {
                    UpdateQueue(Q,q,fcost->val[q],tmp);
                    fcost->val[q] = tmp;
                }
            }
        }
    }

    cost = RemFrame(fcost,sz);

    DestroyQueue(&Q);
    DestroyImage(&flabel);
    DestroyImage(&fcost);
    DestroyImage(&froot);
    DestroyAdjPxl(&N);

    return(cost);
}
