#include "methods.h"


// DIFT

Set* ForestRemoval(Image *cost, Image *pred, Image* root, float radius, Set *seeds, Set* delSet)
{
    AdjRel* A = Circular(radius);
    Set* Frontier = NULL; /// frontier pixels
    Set* T = NULL; /// queue

    int ncols = cost->ncols;
    int nrows = cost->nrows;
    int n = ncols*nrows;
    bool not_frontier[n]; /// seeds cannot be frontier, i.e. F = F\S

    int i,p;

    for (i = 0; i < n; i++) not_frontier[i] = false;

    Set* aux = delSet;
    while (aux != NULL)
    {
        p = aux->elem;
        InsertSet(&T, p);
        cost->val[p] = INT_MAX;
        pred->val[p] = NIL;
        aux = aux->next;
    }

    aux = seeds;
    while (aux != NULL)
    {
        not_frontier[aux->elem] = true;
        aux = aux->next;
    }


    while (T != NULL)
    {
        p = RemoveSet(&T);

        Pixel u;
        u.x = p%ncols;
        u.y = p/ncols;

        for (i = 1; i < A->n; i++)
        {
            Pixel v;

            v.x = u.x + A->dx[i];
            v.y = u.y + A->dy[i];

            if (ValidPixel(cost, v.x, v.y))
            {
                int q = v.x + cost->tbrow[v.y];

                if (pred->val[q] == p)
                {
                    cost->val[q] = INT_MAX;
                    pred->val[q] = NIL;
                    InsertSet(&T, q);
                }
                else if (not_frontier[q] == false)
                {
                    /// cost->val[q] != INT_MAX means it is not in rootSet
                    if (!IsInSet(delSet, root->val[q]) && cost->val[q] != INT_MAX)
                    {
                        InsertSet(&Frontier, q);
                        not_frontier[q] = true; /// this pixel will not be revisited
                    }
                }
            }
        }
    }

    DestroyAdjRel(&A);

    return Frontier;
}

void DifferentialIFT(Image *label, Image *cost, Image *pred, Image* root,
                     Image* grad, float radius, Set *Si, Set *Se, Set* delSet)
{
    GQueue *Q=NULL;
    int i,p,q,n,cst,weight;
    Pixel u,v;
    Set *seeds;
    Set* allSeeds = CloneSet(Si);
    Set* Se2 = CloneSet(Se);
    AdjRel* A = Circular(radius);

    int Wmax = MaximumValue(grad);

    n    = grad->ncols*grad->nrows;
    Q    = CreateGQueue(Wmax+1,n,cost->val);

    MergeSets(&allSeeds, &Se2);

    Se2 = NULL;

    Set* F = ForestRemoval(cost, pred, root, radius, allSeeds, delSet);

    seeds = F;

    while (seeds != NULL)
    {
        InsertGQueue(&Q, seeds->elem);
        seeds = seeds->next;
    }

    seeds = Si;
    while (seeds != NULL)
    {
        p = seeds->elem;

        cost->val[p]  = 0; //Marker imposition.
        InsertGQueue(&Q,p);
        label->val[p] = 1;
        pred->val[p] = NIL;
        root->val[p] = p;

        seeds = seeds->next;
    }

    seeds = Se;
    while (seeds != NULL)
    {
        p = seeds->elem;

        cost->val[p]  = 0; //Marker imposition.
        InsertGQueue(&Q,p);
        label->val[p] = 0;
        pred->val[p] = NIL;
        root->val[p] = p;

        seeds = seeds->next;
    }

    while (!EmptyGQueue(Q))
    {
        p=RemoveGQueue(Q);

        u.x = p%label->ncols;
        u.y = p/label->ncols;
        for (i=1; i < A->n; i++)
        {
            v.x = u.x + A->dx[i];
            v.y = u.y + A->dy[i];
            if (ValidPixel(label, v.x, v.y))
            {
                q = v.x + label->tbrow[v.y];

                weight = (grad->val[p] + grad->val[q])/2;

                cst = MAX(cost->val[p], weight);

                if ((cst < cost->val[q])||(pred->val[q] == p))
                {
                    if (Q->L.elem[q].color == GRAY)
                        RemoveGQueueElem(Q,q);
                    cost->val[q]  = cst;
                    pred->val[q]  = p;
                    label->val[q] = label->val[p];
                    root->val[q] = root->val[p];
                    InsertGQueue(&Q,q);
                }
            }
        }
    }

    DestroyGQueue(&Q);
    DestroyAdjRel(&A);
    DestroySet(&F);
    DestroySet(&allSeeds);
}


void DiffIFT(Image *label, Image *cost, Image *pred, Image* root,
                     Image* objMap, Features* feat, float radius, Set *Si, Set *Se, Set* delSet, float Wobj)
{
    GQueue *Q=NULL;
    int i,p,q,n,cst,weight;
    Pixel u,v;
    Set *seeds;
    Set* allSeeds = CloneSet(Si);
    Set* Se2 = CloneSet(Se);
    AdjRel* A = Circular(radius);
    float* md = AllocFloatArray(A->n);

    n    = label->ncols*label->nrows;
    Q    = CreateGQueue(MAXDENS+1,n,cost->val);

    for (i=1; i < A->n; i++)
        md[i]=sqrt(A->dx[i]*A->dx[i]+A->dy[i]*A->dy[i]);

    float max_feat_values[feat->nfeats];
    float min_feat_values[feat->nfeats];
    float feat_values_amp = 0.0;
    for(i = 0; i < feat->nfeats; i++)
    {
        max_feat_values[i] = FLT_MIN;
        min_feat_values[i] = FLT_MAX;
    }

    for(p = 0; p < feat->nelems; p++)
    {
        for(i = 0; i < feat->nfeats; i++)
        {
            max_feat_values[i] = MAX(feat->elem[p].feat[i],max_feat_values[i]);
            min_feat_values[i] = MIN(feat->elem[p].feat[i],min_feat_values[i]);
        }
    }

    feat_values_amp = sqrtf(EuclDist(max_feat_values, min_feat_values, feat->nfeats));

//    fprintf(stdout,"feat_values_amp %f\n",feat_values_amp);

    MergeSets(&allSeeds, &Se2);

    Se2 = NULL;

    Set* F = ForestRemoval(cost, pred, root, radius, allSeeds, delSet);

    seeds = F;

    while (seeds != NULL)
    {
        InsertGQueue(&Q, seeds->elem);
        seeds = seeds->next;
    }

    seeds = Si;
    while (seeds != NULL)
    {
        p = seeds->elem;

        cost->val[p]  = 0; //Marker imposition.
        InsertGQueue(&Q,p);
        label->val[p] = 1;
        pred->val[p] = NIL;
        root->val[p] = p;

        seeds = seeds->next;
    }

    seeds = Se;
    while (seeds != NULL)
    {
        p = seeds->elem;

        cost->val[p]  = 0; //Marker imposition.
        InsertGQueue(&Q,p);
        label->val[p] = 0;
        pred->val[p] = NIL;
        root->val[p] = p;

        seeds = seeds->next;
    }

    while (!EmptyGQueue(Q))
    {
        p=RemoveGQueue(Q);

        u.x = p%label->ncols;
        u.y = p/label->ncols;
        for (i=1; i < A->n; i++)
        {
            v.x = u.x + A->dx[i];
            v.y = u.y + A->dy[i];
            if (ValidPixel(label, v.x, v.y))
            {
                q = v.x + label->tbrow[v.y];

                const float featdist = (sqrtf(EuclDist(feat->elem[p].feat, feat->elem[q].feat, feat->nfeats))/feat_values_amp)*MAXDENS;
                const float mapdist = (float)labs(objMap->val[p] - objMap->val[q]);

                weight = (int)((Wobj*mapdist + (1-Wobj)*featdist)/md[i]);

                cst = MAX(cost->val[p], weight);

                if ((cst < cost->val[q])||(pred->val[q] == p))
                {
                    if (Q->L.elem[q].color == GRAY)
                        RemoveGQueueElem(Q,q);
                    cost->val[q]  = cst;
                    pred->val[q]  = p;
                    label->val[q] = label->val[p];
                    root->val[q] = root->val[p];
                    InsertGQueue(&Q,q);
                }
            }
        }
    }

    DestroyGQueue(&Q);
    DestroyAdjRel(&A);
    DestroySet(&F);
    DestroySet(&allSeeds);
    free(md);
}


void DiffIFTBB(Image *label, Image *cost, Image *pred, Image* root,
                     Image* objMap, Features* feat, float radius, Set *Si, Set *Se, Set* delSet, float Wobj, int xmin, int ymin, int xmax, int ymax)
{
    GQueue *Q=NULL;
    int i,p,q,x,y,n,cst,weight;
    Pixel u,v;
    Set *seeds;
    Set* allSeeds = CloneSet(Si);
    Set* Se2 = CloneSet(Se);
    AdjRel* A = Circular(radius);
    n    = label->ncols*label->nrows;
    Q    = CreateGQueue(MAXDENS+1,n,cost->val);

    float *md = AllocFloatArray(A->n);

    for (i=1; i < A->n; i++)
        md[i]=sqrt(A->dx[i]*A->dx[i]+A->dy[i]*A->dy[i]);

    float max_feat_values[feat->nfeats];
    float min_feat_values[feat->nfeats];
    float feat_values_amp = 0.0;
    for(i = 0; i < feat->nfeats; i++)
    {
        max_feat_values[i] = FLT_MIN;
        min_feat_values[i] = FLT_MAX;
    }

    for(y = ymin; y < ymax; y++)
        for(x = xmin; x < xmax; x++)
        {
            p = x + y*feat->ncols;
            for(i = 0; i < feat->nfeats; i++)
            {
                max_feat_values[i] = MAX(feat->elem[p].feat[i],max_feat_values[i]);
                min_feat_values[i] = MIN(feat->elem[p].feat[i],min_feat_values[i]);
            }
        }

    feat_values_amp = sqrtf(EuclDist(max_feat_values, min_feat_values, feat->nfeats));
//    fprintf(stdout,"feat_values_amp %f\n",feat_values_amp);

    MergeSets(&allSeeds, &Se2);

    Se2 = NULL;

    Set* F = ForestRemoval(cost, pred, root, radius, allSeeds, delSet);

    seeds = F;

    while (seeds != NULL)
    {
        InsertGQueue(&Q, seeds->elem);
        seeds = seeds->next;
    }

    seeds = Si;
    while (seeds != NULL)
    {
        p = seeds->elem;

        cost->val[p]  = 0; //Marker imposition.
        InsertGQueue(&Q,p);
        label->val[p] = 1;
        pred->val[p] = NIL;
        root->val[p] = p;

        seeds = seeds->next;
    }

    seeds = Se;
    while (seeds != NULL)
    {
        p = seeds->elem;

        cost->val[p]  = 0; //Marker imposition.
        InsertGQueue(&Q,p);
        label->val[p] = 0;
        pred->val[p] = NIL;
        root->val[p] = p;

        seeds = seeds->next;
    }

    while (!EmptyGQueue(Q))
    {
        p=RemoveGQueue(Q);

        u.x = p%label->ncols;
        u.y = p/label->ncols;
        for (i=1; i < A->n; i++)
        {
            v.x = u.x + A->dx[i];
            v.y = u.y + A->dy[i];
            if (v.x >= xmin && v.x < xmax && v.y >= ymin && v.y < ymax && ValidPixel(label, v.x, v.y))
            {
                q = v.x + label->tbrow[v.y];

                // features must be between in [0,1]
                const float featdist = (sqrtf(EuclDist(feat->elem[p].feat, feat->elem[q].feat, feat->nfeats))/feat_values_amp)*MAXDENS;
                const float mapdist = (float)labs(objMap->val[p] - objMap->val[q]);

                weight = (int)((Wobj*mapdist + (1-Wobj)*featdist)/md[i]);

                cst = MAX(cost->val[p], weight);

                if ((cst < cost->val[q])||(pred->val[q] == p))
                {
                    if (Q->L.elem[q].color == GRAY)
                        RemoveGQueueElem(Q,q);
                    cost->val[q]  = cst;
                    pred->val[q]  = p;
                    label->val[q] = label->val[p];
                    root->val[q] = root->val[p];
                    InsertGQueue(&Q,q);
                }
            }
        }
    }

    DestroyGQueue(&Q);
    DestroyAdjRel(&A);
    DestroySet(&F);
    DestroySet(&allSeeds);
    free(md);
}


Set* ForestRemovalByRegions(Image* label, Image *cost, Image *pred, Image* root, Image* regions, float radius, Set *seeds, Set* delSet, int defaut_label)
{
    AdjRel* A = Circular(radius);
    Set* Frontier = NULL; /// frontier pixels
    Set* T = NULL; /// queue

    int ncols = cost->ncols;
    int nrows = cost->nrows;
    int n = ncols*nrows;
    bool not_frontier[n]; /// seeds cannot be frontier, i.e. F = F\S

    int i,p;

    for (i = 0; i < n; i++) not_frontier[i] = false;

    Set* aux = delSet;
    while (aux != NULL)
    {
        p = aux->elem;
        InsertSet(&T, p);
        cost->val[p] = INT_MAX;
        pred->val[p] = NIL;
        root->val[p] = NIL;
        label->val[p] = defaut_label;
        aux = aux->next;
    }

    aux = seeds;
    while (aux != NULL)
    {
        not_frontier[aux->elem] = true;
        aux = aux->next;
    }


    while (T != NULL)
    {
        p = RemoveSet(&T);

        Pixel u;
        u.x = p%ncols;
        u.y = p/ncols;

        for (i = 1; i < A->n; i++)
        {
            Pixel v;

            v.x = u.x + A->dx[i];
            v.y = u.y + A->dy[i];

            if (ValidPixel(cost, v.x, v.y))
            {
                int q = v.x + cost->tbrow[v.y];

                if (regions->val[q] == regions->val[p])
                {
                    if (pred->val[q] == p)
                    {
                        cost->val[q] = INT_MAX;
                        pred->val[q] = NIL;
                        label->val[q] = 0;
                        root->val[q] = NIL;
                        InsertSet(&T, q);
                    }
                    else if (not_frontier[q] == false)
                    {
                        /// cost->val[q] != INT_MAX means it is not in rootSet
                        if (!IsInSet(delSet, root->val[q]) && cost->val[q] != INT_MAX)
                        {
                            InsertSet(&Frontier, q);
                            not_frontier[q] = true; /// this pixel will not be revisited
                        }
                    }
                }
            }
        }
    }

    DestroyAdjRel(&A);

    return Frontier;
}

void DifferentialIFTByRegions(Image *label, Image *cost, Image *pred, Image* root, Image* handicap,
                              Image* grad, Image* regions, float radius, Set *Si, Set *Se, Set* delSet)
{
    GQueue *Q=NULL;
    int i,p,q,n,cst,weight;
    Pixel u,v;
    Set *seeds;
    Set* allSeeds = CloneSet(Si);
    Set* Se2 = CloneSet(Se);
    AdjRel* A = Circular(radius);

    int Wmax = MaximumValue(grad);

    n    = grad->ncols*grad->nrows;
    Q    = CreateGQueue(Wmax+1,n,cost->val);

    MergeSets(&allSeeds, &Se2);

    Se2 = NULL;

    Set* F = ForestRemovalByRegions(label, cost, pred, root, regions, radius, allSeeds, delSet, 0);

    seeds = F;
    while (seeds != NULL)
    {
        InsertGQueue(&Q, seeds->elem);
        seeds = seeds->next;
    }

    seeds = Si;
    while (seeds != NULL)
    {
        p = seeds->elem;

        if(handicap != NULL)
            cost->val[p]  = handicap->val[p]; //Marker imposition.
        else
            cost->val[p] = 0;

        InsertGQueue(&Q,p);
        label->val[p] = 1;
        pred->val[p] = NIL;
        root->val[p] = p;

        seeds = seeds->next;
    }

    seeds = Se;
    while (seeds != NULL)
    {
        p = seeds->elem;

         if(handicap != NULL)
            cost->val[p]  = handicap->val[p]; //Marker imposition.
        else
            cost->val[p] = 0;

        InsertGQueue(&Q,p);
        label->val[p] = 0;
        pred->val[p] = NIL;
        root->val[p] = p;

        seeds = seeds->next;
    }

    while (!EmptyGQueue(Q))
    {
        p=RemoveGQueue(Q);

        u.x = p%label->ncols;
        u.y = p/label->ncols;
        for (i=1; i < A->n; i++)
        {
            v.x = u.x + A->dx[i];
            v.y = u.y + A->dy[i];
            if (ValidPixel(label, v.x, v.y))
            {
                q = v.x + label->tbrow[v.y];
                if (regions->val[q] == regions->val[p])
                {
                    weight = (grad->val[p] + grad->val[q])/2;

                    cst = MAX(cost->val[p], weight);

                    if ((cst < cost->val[q])||(pred->val[q] == p))
                    {
                        if (Q->L.elem[q].color == GRAY)
                            RemoveGQueueElem(Q,q);
                        cost->val[q]  = cst;
                        pred->val[q]  = p;
                        label->val[q] = label->val[p];
                        root->val[q] = root->val[p];
                        InsertGQueue(&Q,q);
                    }
                }
            }
        }
    }

    DestroyGQueue(&Q);
    DestroyAdjRel(&A);
    DestroySet(&F);
    DestroySet(&allSeeds);
}

void DifferentialIFTMultObj(Image *label, Image *cost, Image *pred,
                            SparseGraph *g, Set **SeedsArray, int size)
{
    GQueue *Q=NULL;
    int i,p,q,n,cst,weight;
    Pixel u,v;
    AdjRel *A = g->A;
    Set *seeds;

    n    = g->ncols*g->nrows;
    Q    = CreateGQueue(g->Wmax+1,n,cost->val);

    for (i = 0; i < size; i++)
    {
        seeds = SeedsArray[i];
        while (seeds != NULL)
        {
            p = seeds->elem;
            cost->val[p]  = 0; //Marker imposition.
            InsertGQueue(&Q,p);
            label->val[p] = i;
            pred->val[p] = NIL;
            seeds = seeds->next;
        }
    }

    //contador=0;
    while (!EmptyGQueue(Q))
    {
        p=RemoveGQueue(Q);

        /*
        if (contador==ContMax)
          break;
        else
          contador += 1;
        */
        u.x = p%label->ncols;
        u.y = p/label->ncols;
        for (i=1; i < A->n; i++)
        {
            v.x = u.x + A->dx[i];
            v.y = u.y + A->dy[i];
            if (ValidPixel(label, v.x, v.y))
            {
                q = v.x + label->tbrow[v.y];

                weight = (g->n_link[p])[i];
                cst = MAX(cost->val[p], weight);
                if ((cst < cost->val[q])||(pred->val[q] == p))
                {
                    if (Q->L.elem[q].color == GRAY)
                        RemoveGQueueElem(Q,q);
                    cost->val[q]  = cst;
                    pred->val[q]  = p;
                    label->val[q] = label->val[p];
                    InsertGQueue(&Q,q);
                }
            }
        }
    }

    DestroyGQueue(&Q);
}


void IFTTieZones2Bkg(Image *label, Image *cost, Image *pred,
                     Image *g, float radius, Set *Si, Set *Se)
{
    PriorityQueue *Q=NULL;
    int i,p,q,n,cst,weight;
    Pixel u,v;

    AdjRel* A = Circular(radius);

    Set *seeds;

    SetImage(pred,  NIL);
    SetImage(cost,  INT_MIN);
    SetImage(label, 0);

    int Wmax = MaximumValue(g);

    n = g->ncols*g->nrows;
    Q = CreatePQueue(Wmax+2, n, cost->val);

    seeds = Si;
    while (seeds != NULL)
    {
        p = seeds->elem;
        cost->val[p]  = Wmax+1; //Marker imposition.
        FastInsertElemPQueue(Q, p);
        label->val[p] = 1;
        pred->val[p] = NIL;
        seeds = seeds->next;
    }

    seeds = Se;
    while (seeds != NULL)
    {
        p = seeds->elem;
        cost->val[p]  = Wmax+1; //Marker imposition.
        FastInsertElemPQueueAsFirst(Q, p);
        label->val[p] = 0;
        pred->val[p] = NIL;
        seeds = seeds->next;
    }

    while (!IsEmptyPQueue(Q))
    {
        p = FastRemoveMaxFIFOPQueue(Q);

        u.x = p%label->ncols;
        u.y = p/label->ncols;
        for (i=1; i<A->n; i++)
        {
            v.x = u.x + A->dx[i];
            v.y = u.y + A->dy[i];
            if (ValidPixel(label, v.x, v.y))
            {
                q = v.x + label->tbrow[v.y];

                if (Q->L.elem[q].color == BLACK) continue;

                weight = g->val[p] + g->val[q];
                cst = MIN(cost->val[p], weight);
                if ((cst > cost->val[q])||
                        (cst== cost->val[q] && label->val[p]==0))
                {
                    if (Q->L.elem[q].color == GRAY)
                        FastRemoveElemPQueue(Q, q);
                    cost->val[q]  = cst;
                    pred->val[q]  = p;
                    label->val[q] = label->val[p];
                    if (label->val[q]==0)
                        FastInsertElemPQueueAsFirst(Q, q);
                    else
                        FastInsertElemPQueue(Q, q);
                }
            }
        }
    }
    DestroyPQueue(&Q);
    DestroyAdjRel(&A);
}


Image *GetTieZones(Image *g, float radius, Set *Si, Set *Se)
{
    Image *tzones,*label1,*label2,*cost,*pred;
    int p,n;

    tzones = CreateImage(g->ncols,g->nrows);
    label1 = CreateImage(g->ncols,g->nrows);
    label2 = CreateImage(g->ncols,g->nrows);
    cost   = CreateImage(g->ncols,g->nrows);
    pred   = CreateImage(g->ncols,g->nrows);
    IFTTieZones2Bkg(label1, cost, pred, g, radius, Si, Se);
    IFTTieZones2Bkg(label2, cost, pred, g, radius, Se, Si);

    n = g->ncols*g->nrows;
    for (p=0; p<n; p++)
    {
        if (label1->val[p]==0 && label2->val[p]==0)
            tzones->val[p] = 1;
        else
            tzones->val[p] = 0;
    }

    DestroyImage(&label1);
    DestroyImage(&label2);
    DestroyImage(&cost);
    DestroyImage(&pred);

    return tzones;
}

// WaterGray


Image *VWaterGray(Image *img, Image *marker, Image* cost, AdjRel *A)
{
    Image *label=NULL;
    GQueue *Q=NULL;
    int i,p,q,tmp,n,r=1;
    Pixel u,v;

    n     = img->ncols*img->nrows;
    label = CreateImage(img->ncols,img->nrows);
    Q     = CreateGQueue(MaximumValue(marker)+2,n,cost->val);
    for (p=0; p < n; p++)
    {
        cost->val[p]=marker->val[p]+1;
        InsertGQueue(&Q,p);
    }

    while (!EmptyGQueue(Q))
    {
        p=RemoveGQueue(Q);
        if (label->val[p]==0)
        {
            cost->val[p]=img->val[p];
            label->val[p]=r;
            r++;
        }
        u.x = p%img->ncols;
        u.y = p/img->ncols;
        for (i=1; i < A->n; i++)
        {
            v.x = u.x + A->dx[i];
            v.y = u.y + A->dy[i];
            if (ValidPixel(img,v.x,v.y))
            {
                q = v.x + img->tbrow[v.y];
                if (cost->val[q] > cost->val[p])
                {
                    tmp = MAX(cost->val[p],img->val[q]);
                    if (tmp < cost->val[q])
                    {
                        UpdateGQueue(&Q,q,tmp);
                        label->val[q] = label->val[p];
                    }
                }
            }
        }
    }
    DestroyGQueue(&Q);

    return(label);
}

//--------------------------------------------------
// IFT + GraphCut

void IFTGraphCut(Image *label, ExSparseGraph *cap,
                 Set *Si, Set *Se,
                 int measure, float maxorder,
                 float lambda, bool posproc)
{
    GQueue *Q=NULL;
    AdjRel *A;
    int i,p,q,n,ord,cst,weight,Wmax,nsi;
    Pixel u,v;
    Image *Od,*cost,*flabel,*slabel;
    Set *seeds;
    double  ai,ie,ae,Rbkg,Robj,*M,tmp,min,dweight;
    int     nie;
    FILE   *fp;

    Wmax = cap->Wmax;
    A  = (cap->G)->A;
    fp = fopen("plot.txt","w");
    n  = label->ncols*label->nrows;
    cost  = CreateImage(label->ncols,label->nrows);
    Q     = CreateGQueue(Wmax+1,n,cost->val);

    Od    = CreateImage(label->ncols,label->nrows);
    M     = AllocDoubleArray(n);
    for (p=0; p<n; p++) M[p] = DBL_MAX;

    nie = 0;
    ai = ie = ae = Rbkg = Robj = 0.0;
    SetImage(label,      0);
    SetImage(cost, INT_MAX);
    SetImage(Od,   INT_MAX);
    for (p=0; p<n; p++)
    {
        Rbkg += (double)(cap->t_link_S)->val[p]/(double)Wmax;
        u.x = p%label->ncols;
        u.y = p/label->ncols;
        for (i=1; i<A->n; i++)
        {
            v.x = u.x + A->dx[i];
            v.y = u.y + A->dy[i];
            if (ValidPixel(label,v.x,v.y))
            {
                q = v.x + label->tbrow[v.y];
                dweight = (double)((cap->G)->n_link[p])[i]/(double)Wmax;
                ae += dweight/2.0;
            }
            else ae += 1.0;
        }
    }

    nsi = 0;
    seeds = Si;
    while (seeds != NULL)
    {
        p = seeds->elem;
        cost->val[p]  = 0; //Marker imposition.
        InsertGQueue(&Q,p);
        label->val[p] = 1;
        seeds = seeds->next;
        nsi++;
    }

    seeds = Se;
    while (seeds != NULL)
    {
        p = seeds->elem;
        cost->val[p]  = 0; //Marker imposition.
        InsertGQueue(&Q,p);
        label->val[p] = 0;
        seeds = seeds->next;
    }

    ord = 1;
    while (!EmptyGQueue(Q))
    {
        p=RemoveGQueue(Q);

        if (label->val[p]>0)
        {
            Od->val[p] = ord;
            ord++;
        }
        u.x = p%label->ncols;
        u.y = p/label->ncols;
        for (i=1; i<A->n; i++)
        {
            v.x = u.x + A->dx[i];
            v.y = u.y + A->dy[i];
            if (ValidPixel(label,v.x,v.y))
            {
                q = v.x + label->tbrow[v.y];

                dweight  = (double)((cap->G)->n_link[p])[i];
                weight   = (int)(Wmax-dweight);
                dweight /= (double)Wmax;

                if (Od->val[q]<Od->val[p])
                {
                    if (label->val[p]>0)
                    {
                        ie -= dweight;
                        ai += dweight;
                        nie--;
                    }
                }
                else
                {
                    if (label->val[p]>0)
                    {
                        ie += dweight;
                        ae -= dweight;
                        nie++;
                    }
                    cst = MAX(cost->val[p], weight);
                    if (cst < cost->val[q])
                    {
                        if (Q->L.elem[q].color == GRAY)
                            RemoveGQueueElem(Q,q);
                        cost->val[q] = cst;
                        label->val[q] = label->val[p];
                        InsertGQueue(&Q,q);
                    }
                }
            }
            else
            {
                if (label->val[p]>0)
                {
                    ie += 1.0;
                    ae -= 1.0;
                    nie++;
                }
            }
        }

        if (label->val[p]==0)
        {
            M[p] = DBL_MAX;
            continue;
        }

        Rbkg -= (double)(cap->t_link_S)->val[p]/(double)Wmax;
        Robj += (double)(cap->t_link_T)->val[p]/(double)Wmax;

        if (measure==MEAN_CUT)
        {
            if (nie!=0) tmp = ie/nie;
            else       tmp = 1.0;
        }
        else if (measure==NORMALIZED_CUT)
        {
            if ((ie+ai)!=0.0) tmp = ie/(ie+ai);
            else             tmp = 1.0;

            if ((ie+ae)!=0.0) tmp += ie/(ie+ae);
            else	       tmp += 1.0;
        }
        else if (measure==ENERGY_FUNC)
        {
            tmp = lambda*(Robj+Rbkg)+ie;
        }
        else  //LAST_BOUNDARY
        {
            tmp = n-ord;
        }

        if (Od->val[p] <= n*(maxorder/100.0))
        {
            M[p] = tmp;
            fprintf(fp,"%f %lf\n",100.0*(Od->val[p]/(float)n), M[p]);
        }
    }

    min = DBL_MAX;
    ord = 0;
    for (p=0; p<n; p++)
    {
        if (M[p] < min && Od->val[p]>=nsi)
        {
            min = M[p];
            ord = Od->val[p];
        }
    }
    printf(" Min-cut: %f, ord: %d\n",min,ord);

    slabel = CopyImage(label);
    for (p=0; p<n; p++)
    {
        if (Od->val[p] > ord)
            label->val[p] = 0;
    }

    if (posproc)
    {
        flabel = CloseHoles(label);
        for (p=0; p<n; p++)
        {
            if (slabel->val[p]>0)
                label->val[p] = flabel->val[p];
            else
                label->val[p] = 0;
        }
        DestroyImage(&flabel);
    }

    fclose(fp);
    DestroyGQueue(&Q);
    DestroyImage(&slabel);
    DestroyImage(&cost);
    DestroyImage(&Od);
    free(M);
}






//------------------------------------------
// Tree Pruning Algorithms

int RootComp(Image *root, int p)
{
    if (root->val[p]==p)
        return(p);
    else
        return(root->val[p]=RootComp(root,root->val[p]));
}


Image *TreeCut(Image *pred, Set *S)
{
    int  p,n;
    Image *label,*root;
    Set *seeds;

    root  = CopyImage(pred);
    label = CreateImage(pred->ncols,pred->nrows);
    n     = pred->ncols*pred->nrows;

    for (p=0; p < n; p++)
    {
        label->val[p]=1;
        if (root->val[p]==NIL)
            root->val[p]=p;
    }

    seeds = S;
    while (seeds != NULL)
    {
        p = seeds->elem;
        root->val[p]=p;
        label->val[p]=0;
        seeds = seeds->next;
    }

    for (p=0; p < n; p++)
    {
        root->val[p]=RootComp(root,p);
        label->val[p]=label->val[root->val[p]];
    }

    /* retoma o label 1 no ponto de vazamento */
    /*
    for (p=0; p < n; p++) {
      if (root->val[p]==p)
        label->val[p]=1;
    }
    */
    DestroyImage(&root);
    return(label);
}


Set *GetTPObject(Image *pred, Set *B, SparseGraph *g)
{
    Set *pts=NULL,*seeds=NULL;
    Image *path=NULL;
    int max,pmax=0,p,q,s,smax=0,i,size,Gmax,w;
    BMap *bm=NULL;

    path = DescendantCount(pred,B);
    bm = BMapNew(pred->ncols*pred->nrows);
    size = 0;
    seeds = B;
    while (seeds != NULL)
    {
        p = seeds->elem;
        q = s = p;
        max = 0;
        while (pred->val[q] != NIL)
        {
            if (path->val[q] > max)
            {
                max = path->val[q];
                pmax = q;
                smax = s;
            }
            s = q;
            q = pred->val[q];
        }


        if (smax!=pmax)
        {
            i = get_edge_index(smax, pmax, g);
            Gmax = (g->n_link[smax])[i];
        }
        else
            Gmax = 0;

        q = pmax;
        while (pred->val[q] != NIL)
        {
            if (path->val[q] == max)
            {
                i = get_edge_index(q, pred->val[q], g);
                w = (g->n_link[q])[i];
                if (Gmax < w)
                {
                    Gmax = w;
                    pmax = q;
                }
            }
            q = pred->val[q];
        }

        if (_fast_BMapGet(bm,pmax)==0)
        {
            size += path->val[pmax];
            InsertSet(&pts,pmax);
            _fast_BMapSet1(bm,pmax);
        }
        seeds = seeds->next;
    }

    DestroyImage(&path);
    BMapDestroy(bm);

    return(pts);
}


Image *DescendantCount(Image *pred, Set *B)
{
    Image *path;
    Set *seeds=NULL;
    int p,q;

    path = CreateImage(pred->ncols,pred->nrows);
    seeds = B;
    while (seeds != NULL)
    {
        p = seeds->elem;
        q = p;
        while (pred->val[q] != NIL)
        {
            path->val[pred->val[q]]++;
            q = pred->val[q];
        }
        seeds = seeds->next;
    }

    return path;
}


Image *CompleteDescendantCount(Image *pred)
{
    int i,p,q,n;
    Image *nsons=NULL;
    Stack *S;
    FIFOQ *Q;
    AdjRel *A;
    Pixel v;

    A = Circular(1.5);
    n     = pred->ncols*pred->nrows;
    nsons = CreateImage(pred->ncols,pred->nrows);
    SetImage(nsons, 0);

    S = StackNew(n);
    Q = FIFOQNew(n);

    for (p=0; p < n; p++)
    {
        if (pred->val[p]==NIL)
            FIFOQPush(Q,p);
    }

    // Breadth-first traversal.
    while (!FIFOQEmpty(Q))
    {
        p = FIFOQPop(Q);
        StackPush(S, p);

        for (i=1; i<A->n; i++)
        {
            v.x = p%pred->ncols + A->dx[i];
            v.y = p/pred->ncols + A->dy[i];
            if ( ValidPixel(pred, v.x, v.y) )
            {
                q = v.x + pred->tbrow[v.y];
                if (pred->val[q]==p)
                    FIFOQPush(Q,q);
            }
        }
    }

    // Reverse breadth-first traversal.
    while (!StackEmpty(S))
    {
        p = StackPop(S);
        q = pred->val[p];
        if (q!=NIL)
            nsons->val[q] += (nsons->val[p] + 1);
    }

    FIFOQDestroy(Q);
    StackDestroy(S);
    DestroyAdjRel(&A);

    return(nsons);
}



Image  *LabelTrees(Image *pred)
{
    int p,q,i,n,ncols,nrows,id;
    Image *label;
    FIFOQ *Q;
    AdjRel *A;
    Pixel v;

    ncols = pred->ncols;
    nrows = pred->nrows;
    label = CreateImage(ncols,nrows);
    SetImage(label, 0);
    n = ncols*nrows;
    A = Circular(1.5);
    Q = FIFOQNew(n);

    id = 1;
    for (p=0; p<n; p++)
    {
        if (pred->val[p]==NIL)
        {

            for (i=1; i<A->n; i++)
            {
                v.x = p%ncols + A->dx[i];
                v.y = p/ncols + A->dy[i];
                if ( ValidPixel(pred, v.x, v.y) )
                {
                    q = v.x + pred->tbrow[v.y];
                    if (pred->val[q]==p)
                    {
                        label->val[q] = id++;
                        FIFOQPush(Q,q);
                    }
                }
            }

        }
    }

    // Breadth-first traversal.
    while (!FIFOQEmpty(Q))
    {
        p = FIFOQPop(Q);

        for (i=1; i<A->n; i++)
        {
            v.x = p%ncols + A->dx[i];
            v.y = p/ncols + A->dy[i];
            if ( ValidPixel(pred, v.x, v.y) )
            {
                q = v.x + pred->tbrow[v.y];
                if (pred->val[q]==p)
                {
                    label->val[q] = label->val[p];
                    FIFOQPush(Q,q);
                }
            }
        }
    }

    FIFOQDestroy(Q);
    DestroyAdjRel(&A);

    return(label);
}


//------------------------------------------
//Seed competition with K-connectivity
void KappaConnComp(Image *label, SparseGraph *g,
                   Set *Si, Set *Se, float Th)
{
    Pixel u,v;
    GQueue *Q;
    AdjRel *A = g->A;
    Image *cost,*pcost,*root,*kappa,*size;
    int n, r, p, q, i, weight, cst;
    int percent;
    Set *seeds=NULL;

    kappa = CreateImage(g->ncols, g->nrows);
    size  = CreateImage(g->ncols, g->nrows);
    root  = CreateImage(g->ncols, g->nrows);
    cost  = CreateImage(g->ncols, g->nrows);
    pcost = CreateImage(g->ncols, g->nrows);

    n     = g->nrows*g->ncols;
    percent = (int)((((float)Th)/100.0)*n);
    Q     = CreateGQueue(g->Wmax+1,n,cost->val);

    for (p=0; p<n; p++)
    {
        root->val[p]  = p;
        kappa->val[p] = INT_MAX;
        cost->val[p]  = INT_MAX;
        pcost->val[p] = 0;
        label->val[p] = 0;
        size->val[p]  = 0;
    }

    seeds = Si;
    while (seeds != NULL)
    {
        p = seeds->elem;
        cost->val[p]  = 0; //Marker imposition.
        label->val[p] = 1;
        InsertGQueue(&Q,p);
        seeds = seeds->next;
    }

    seeds = Se;
    while (seeds != NULL)
    {
        p = seeds->elem;
        cost->val[p]  = 0; //Marker imposition.
        label->val[p] = 0;
        InsertGQueue(&Q,p);
        seeds = seeds->next;
    }

    while (!EmptyGQueue(Q))
    {
        p = RemoveGQueue(Q);
        r = root->val[p];

        u.x = p%label->ncols;
        u.y = p/label->ncols;

        if ((kappa->val[r] == INT_MAX) &&
                (label->val[r] != 0))
        {

            if (cost->val[p] != pcost->val[r])
            {
                size->val[r] = 1;
                pcost->val[r] = cost->val[p];
            }
            else
                size->val[r]++;

            if (size->val[r]>percent)
            {
                kappa->val[r]=MAX(cost->val[p]-1,0);
                printf("kappa: %d\n",kappa->val[r]);
            }
        }
        if (cost->val[p] <= kappa->val[r])
        {

            for (i=1; i < A->n; i++)
            {
                v.x = u.x + A->dx[i];
                v.y = u.y + A->dy[i];
                if (ValidPixel(label,v.x,v.y))
                {
                    q = v.x + label->tbrow[v.y];
                    if (cost->val[q] > cost->val[p])
                    {

                        weight = (g->n_link[p])[i];
                        cst = MAX(cost->val[p], weight);

                        if (cst < cost->val[q])
                        {
                            if (Q->L.elem[q].color == GRAY)
                                RemoveGQueueElem(Q,q);
                            cost->val[q] = cst;
                            root->val[q] = root->val[p];
                            InsertGQueue(&Q,q);
                        }
                    }
                }
            }
        }
    }
    for (p=0; p<n; p++)
    {
        if (cost->val[p]<=kappa->val[root->val[p]])
            label->val[p] = label->val[root->val[p]];
    }

    DestroyGQueue(&Q);
    DestroyImage(&kappa);
    DestroyImage(&size);
    DestroyImage(&root);
    DestroyImage(&cost);
    DestroyImage(&pcost);
}


//--------------------------------------------------
// IFT to create animations

Curve *IFTVideo(Image *label,
                Image *cost,
                Image *pred,
                Image *rank,
                ExSparseGraph *cap,
                Set *Si, Set *Se,
                int measure, float maxorder,
                float lambda)
{
    int i,p,q,n,ord,cst,weight,Wmax;
    double ai,ie,ae,Rbkg,Robj,tmp,min,dweight;
    int    nie;
    GQueue *Q=NULL;
    AdjRel *A;
    Pixel u,v;
    Set *seeds;
    Curve *M;

    Wmax = cap->Wmax;
    A  = (cap->G)->A;
    n  = label->ncols*label->nrows;
    Q  = CreateGQueue(Wmax+1,n,cost->val);

    M = CreateCurve(n);
    for (p=0; p<n; p++)
    {
        M->X[p] = DBL_MAX;
        M->Y[p] = DBL_MAX;
    }
    nie = 0;
    ai = ie = ae = Rbkg = Robj = 0.0;
    SetImage(label,      0);
    SetImage(cost, INT_MAX);
    SetImage(pred,     NIL);
    SetImage(rank, INT_MAX);
    for (p=0; p<n; p++)
    {
        Rbkg += (double)(cap->t_link_S)->val[p]/(double)Wmax;
        u.x = p%label->ncols;
        u.y = p/label->ncols;
        for (i=1; i<A->n; i++)
        {
            v.x = u.x + A->dx[i];
            v.y = u.y + A->dy[i];
            if (ValidPixel(label,v.x,v.y))
            {
                q = v.x + label->tbrow[v.y];
                dweight = (double)((cap->G)->n_link[p])[i]/(double)Wmax;
                ae += dweight/2.0;
            }
            else ae += 1.0;
        }
    }

    seeds = Si;
    while (seeds != NULL)
    {
        p = seeds->elem;
        cost->val[p]  = 0; //Marker imposition.
        InsertGQueue(&Q,p);
        label->val[p] = 1;
        seeds = seeds->next;
    }

    seeds = Se;
    while (seeds != NULL)
    {
        p = seeds->elem;
        cost->val[p]  = 0; //Marker imposition.
        InsertGQueue(&Q,p);
        label->val[p] = 0;
        seeds = seeds->next;
    }

    ord = 1;
    while (!EmptyGQueue(Q))
    {
        p=RemoveGQueue(Q);

        rank->val[p] = ord;
        ord++;

        u.x = p%label->ncols;
        u.y = p/label->ncols;
        for (i=1; i<A->n; i++)
        {
            v.x = u.x + A->dx[i];
            v.y = u.y + A->dy[i];
            if (ValidPixel(label,v.x,v.y))
            {
                q = v.x + label->tbrow[v.y];

                dweight  = (double)((cap->G)->n_link[p])[i];
                weight   = (int)(Wmax-dweight);
                dweight /= (double)Wmax;

                if (rank->val[q]<rank->val[p])
                {
                    if (label->val[p]>0)
                    {
                        ie -= dweight;
                        ai += dweight;
                        nie--;
                    }
                }
                else
                {
                    if (label->val[p]>0)
                    {
                        ie += dweight;
                        ae -= dweight;
                        nie++;
                    }
                    cst = MAX(cost->val[p], weight);
                    if (cst < cost->val[q])
                    {
                        if (Q->L.elem[q].color == GRAY)
                            RemoveGQueueElem(Q,q);
                        label->val[q] = label->val[p];
                        cost->val[q] = cst;
                        pred->val[q] = p;
                        InsertGQueue(&Q,q);
                    }
                }
            }
            else
            {
                if (label->val[p]>0)
                {
                    ie += 1.0;
                    ae -= 1.0;
                    nie++;
                }
            }
        }

        if (label->val[p]==0)
        {
            M->Y[p] = DBL_MAX;
            continue;
        }

        Rbkg -= (double)(cap->t_link_S)->val[p]/(double)Wmax;
        Robj += (double)(cap->t_link_T)->val[p]/(double)Wmax;

        if (measure==MEAN_CUT)
        {
            if (nie!=0) tmp = ie/nie;
            else       tmp = 1.0;
        }
        else if (measure==NORMALIZED_CUT)
        {
            if ((ie+ai)!=0.0) tmp = ie/(ie+ai);
            else             tmp = 1.0;

            if ((ie+ae)!=0.0) tmp += ie/(ie+ae);
            else	       tmp += 1.0;
        }
        else if (measure==ENERGY_FUNC)
        {
            tmp = lambda*(Robj+Rbkg)+ie;
        }
        else  //LAST_BOUNDARY
        {
            tmp = n-ord;
        }

        if (rank->val[p] <= n*(maxorder/100.0))
        {
            M->Y[p] = tmp;
            M->X[p] = 100.0*(rank->val[p]/(float)n);
        }
    }

    min = DBL_MAX;
    ord = 0;
    for (p=0; p<n; p++)
    {
        if (M->Y[p] < min)
        {
            min = M->Y[p];
            ord = rank->val[p];
        }
    }
    //printf(" Min-cut: %f, ord: %d\n",min,ord);

    DestroyGQueue(&Q);
    return (M);
}


CImage *IFTVideoFrame(int r, CImage *cimg,
                      Image *label, Image *rank,
                      Set *Si, Set *Se, bool posproc,
                      int objColor, int bkgColor,
                      int w, int h)
{
    Image *flabel,*nlabel,*aux,*aux2;
    CImage *hlight,*frame;
    int colormap[3];
    colormap[0] = 0x000000;
    colormap[1] = bkgColor;
    colormap[2] = objColor;

    nlabel = MyAdd(label, 1);
    frame  = CreateCImage(w, h);

    aux = Threshold(rank, 0, r);
    if (posproc)
    {
        aux2 = CloseHoles(aux);
        DestroyImage(&aux);
        aux = aux2;
    }
    flabel = Mult(aux, nlabel);
    hlight = CWideHighlightLabels(cimg, flabel, 1.0,
                                  colormap, true);
    DrawSet2CImage(hlight, Si, colormap[2]);
    DrawSet2CImage(hlight, Se, colormap[1]);

    //zoom = ZoomView(cimg, size, 0xdddddd);
    SetCImage(frame, 0x000000);
    PasteSubCImage(frame, hlight,
                   w/2-hlight->C[0]->ncols/2,
                   h/2-hlight->C[0]->nrows/2);

    DestroyCImage(&hlight);
    DestroyImage(&flabel);
    DestroyImage(&aux);
    DestroyImage(&nlabel);

    return frame;
}


void WriteIFTVideoFrames(CImage *cimg,
                         Image *label, Image *rank,
                         Set *Si, Set *Se, bool posproc,
                         int objColor, int bkgColor,
                         int w, int h, FileList *L)
{
    CImage *frame;
    int i,dr,r;

    r = 1;
    dr = MaximumValue(rank)/(L->n-1);
    for (i=0; i<L->n; i++)
    {
        frame = IFTVideoFrame(r, cimg, label, rank,
                              Si, Se, posproc,
                              objColor, bkgColor, w, h);
        WriteCImage(frame, GetFile(L, i));
        DestroyCImage(&frame);
        r += dr;
    }
}


/*
void WriteKCCVideoFrames(CImage *cimg,
			 Image *label, Image *cost,
			 Set *Si, Set *Se, bool posproc,
			 int objColor, int bkgColor,
			 int w, int h, FileList *L){
  CImage *frame;
  int c,k,i,dr,r,Rmax,Cmax;
  Curve * hist = Histogram(cost);
  WriteCurve(hist,"kcc_hist.txt");

  Rmax = 0;
  for(i=0; i<hist->n; i++){
    if(hist->Y[i]>0.0) Rmax++;
  }
  Cmax = MaximumValue(cost);

  k = i = 0;
  r = 0;
  dr = Rmax/(L->n-1);
  for(c=0; c<Cmax; c++){

    if(k==r && i<L->n){
      frame = IFTVideoFrame(c, cimg, label, cost,
			    Si, Se, posproc,
			    objColor, bkgColor, w, h);
      WriteCImage(frame, GetFile(L, i));
      DestroyCImage(&frame);

      r += dr;
      if(r>=Rmax) r=Rmax-1;
      i++;
    }
    if(hist->Y[c]>0.0) k++;
  }
}
*/

void WriteKCCVideoFrames(CImage *cimg,
                         Image *label, Image *cost,
                         Set *Si, Set *Se, bool posproc,
                         int objColor, int bkgColor,
                         int w, int h, FileList *L)
{
    CImage *frame;
    int c,i,dh,ph;
    Curve * hist = Histogram(cost);
    Curve *nhist = RemoveEmptyBins(hist);
    WriteCurve(hist,"kcc_hist.txt");

    dh = ROUND((float)nhist->n/(L->n-1));
    ph = 0;
    for (i=0; i<L->n; i++)
    {
        c = (int)nhist->X[ph];
        frame = IFTVideoFrame(c, cimg, label, cost,
                              Si, Se, posproc,
                              objColor, bkgColor, w, h);
        WriteCImage(frame, GetFile(L, i));
        DestroyCImage(&frame);

        ph += dh;
        if (ph >= nhist->n) ph = nhist->n-1;
        if (i+1==L->n-1)    ph = nhist->n-1;
    }
    DestroyCurve(&hist);
    DestroyCurve(&nhist);
}


int ComputePathLength(Image *pred, int p)
{
    int length=0;

    while (p!=NIL)
    {
        length++;
        p = pred->val[p];
    }
    return length;
}


void WriteTPVideoFrames(CImage *cimg,
                        Image *pred, Set *Si,
                        int objColor, int bkgColor,
                        int w, int h, FileList *L)
{
    int n,p,i,k,l,Lmax=0;
    CImage *frame,*hlight,*cdraw;
    Image *alpha;
    Set *B=NULL,*seeds;
    float dlf,lf;

    n = pred->ncols*pred->nrows;
    for (p=0; p<n; p++)
    {
        l = ComputePathLength(pred, p);
        if (l>Lmax)
            Lmax = l;
    }

    B = ImageBorder(pred);
    frame = CreateCImage(w, h);
    cdraw = CreateCImage(w, h);
    alpha = CreateImage(w, h);

    i = 0;
    lf = 0.0;
    dlf = (float)Lmax/(float)(L->n-1);
    for (k=0; k<Lmax; k++)
    {

        l = ROUND(lf);
        if (l>=Lmax) l=Lmax-1;

        if (k==l && i<L->n)
        {
            hlight = CopyCImage(cimg);
            DrawSet2CImage(hlight, Si, objColor);
            //DrawSet2CImage(hlight, B,  bkgColor);
            SetCImage(cdraw, 0x000000);
            SetImage(alpha, 0);
            DrawCImageSet(cdraw, alpha, B, 1.0,
                          bkgColor, 255, true);
            BlendDrawCImage(hlight, cdraw, alpha);
            SetCImage(frame, 0x000000);
            PasteSubCImage(frame, hlight,
                           w/2-hlight->C[0]->ncols/2,
                           h/2-hlight->C[0]->nrows/2);
            WriteCImage(frame, GetFile(L, i));
            DestroyCImage(&hlight);
            lf += dlf;
            i++;
        }

        seeds = B;
        while (seeds != NULL)
        {
            p = seeds->elem;
            if (pred->val[p]!=NIL)
                seeds->elem = pred->val[p];
            seeds = seeds->next;
        }
    }
    DestroyCImage(&frame);
    DestroyCImage(&cdraw);
    DestroyImage(&alpha);
    DestroySet(&B);
}



void DifferentialIFTBB(Image *label, Image *cost, Image *pred, Image* root,
                       Image* grad, float radius, Set *Si, Set *Se, Set* delSet, int xmin, int ymin, int xmax, int ymax)

{
    GQueue *Q=NULL;
    int i,p,q,n,cst,weight;
    Pixel u,v;
    Set *seeds;
//    Set* allSeeds = CloneSet(Si);
//    Set* Se2 = CloneSet(Se);
    AdjRel* A = Circular(radius);

    int Wmax = MaximumValue(grad);

    n    = grad->ncols*grad->nrows;
    Q    = CreateGQueue(Wmax+1,n,cost->val);

//    MergeSets(&allSeeds, &Se2);

//    Se2 = NULL;

//    Set* F = ForestRemoval(cost, pred, root, radius, allSeeds, delSet);
//
//    seeds = F;
//
//    while (seeds != NULL)
//    {
//        InsertGQueue(&Q, seeds->elem);
//        seeds = seeds->next;
//    }
//
    seeds = Si;
    while (seeds != NULL)
    {
        p = seeds->elem;

        cost->val[p]  = 0; //Marker imposition.
        InsertGQueue(&Q,p);
        label->val[p] = 1;
        pred->val[p] = NIL;
        root->val[p] = p;

        seeds = seeds->next;
    }

    seeds = Se;
    while (seeds != NULL)
    {
        p = seeds->elem;

        cost->val[p]  = 0; //Marker imposition.
        InsertGQueue(&Q,p);
        label->val[p] = 0;
        pred->val[p] = NIL;
        root->val[p] = p;

        seeds = seeds->next;
    }

    while (!EmptyGQueue(Q))
    {
        p=RemoveGQueue(Q);

        u.x = p%label->ncols;
        u.y = p/label->ncols;
        for (i=1; i < A->n; i++)
        {
            v.x = u.x + A->dx[i];
            v.y = u.y + A->dy[i];
            if (v.x >= xmin && v.x < xmax && v.y >= ymin && v.y < ymax && ValidPixel(label, v.x, v.y))
            {
                q = v.x + label->tbrow[v.y];

                weight = (grad->val[p] + grad->val[q])/2;

                cst = MAX(cost->val[p], weight);

                if ((cst < cost->val[q])||(pred->val[q] == p))
                {
                    if (Q->L.elem[q].color == GRAY)
                        RemoveGQueueElem(Q,q);
                    cost->val[q]  = cst;
                    pred->val[q]  = p;
                    label->val[q] = label->val[p];
                    root->val[q] = root->val[p];
                    InsertGQueue(&Q,q);
                }
            }
        }
    }

    DestroyGQueue(&Q);
    DestroyAdjRel(&A);
//    DestroySet(&F);
//    DestroySet(&allSeeds);
}




