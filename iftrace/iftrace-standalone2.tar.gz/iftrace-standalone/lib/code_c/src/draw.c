
#include "draw.h"


void    BlendDrawImage(Image *img, 
		       Image *draw, 
		       Image *alpha){
  int p,n;
  float a;

  n = img->ncols*img->nrows;
  for(p=0; p<n; p++){
    a = alpha->val[p]/255.0;
    img->val[p] = ROUND(draw->val[p]*a + img->val[p]*(1.0-a));
  }
}


void    BlendDrawCImage(CImage *cimg, 
			CImage *cdraw, 
			Image *alpha){
  BlendDrawImage(cimg->C[0], cdraw->C[0], alpha);
  BlendDrawImage(cimg->C[1], cdraw->C[1], alpha);
  BlendDrawImage(cimg->C[2], cdraw->C[2], alpha);
}


inline void DrawCImagePixel(CImage *cdraw, 
			    Image *alpha, 
			    int p, 
			    int color,
			    int a){
  DrawImagePixel(cdraw->C[0], alpha, p, t0(color), a);
  DrawImagePixel(cdraw->C[1], alpha, p, t1(color), a);
  DrawImagePixel(cdraw->C[2], alpha, p, t2(color), a);
}


inline void DrawImagePixel(Image *draw, 
			   Image *alpha, 
			   int p,
			   int val,
			   int a){
  if(a >= alpha->val[p]){
    alpha->val[p] = a;
    draw->val[p]  = val;
  }
}


void    DrawCImageFloodFill(CImage *cdraw, 
			    Image *alpha, 
			    int s, 
			    int color,
			    int a){
  int p,q,n,i,R,G,B,old;
  int ncols,nrows;
  FIFOQ *Q;
  AdjRel *A;
  Pixel u,v;

  R = cdraw->C[0]->val[s];
  G = cdraw->C[1]->val[s];
  B = cdraw->C[2]->val[s];
  old = triplet(R,G,B);
  if(old==color) return;

  ncols = cdraw->C[0]->ncols;
  nrows = cdraw->C[0]->nrows;
  n = ncols*nrows;
  Q = FIFOQNew(n);
  A = Circular(1.0);
  if(alpha->val[s]<=a){
    FIFOQPush(Q, s);
    DrawCImagePixel(cdraw, alpha, s, color, a);
  }

  while(!FIFOQEmpty(Q)){
    p = FIFOQPop(Q);

    u.x = p%ncols;
    u.y = p/ncols;
    for (i=1; i < A->n; i++){
      v.x = u.x + A->dx[i];
      v.y = u.y + A->dy[i];
      if (ValidPixel(cdraw->C[0],v.x,v.y)){
	q = v.x + cdraw->C[0]->tbrow[v.y];
	R = cdraw->C[0]->val[q];
	G = cdraw->C[1]->val[q];
	B = cdraw->C[2]->val[q];
	if(triplet(R,G,B)==old &&
	   alpha->val[q]<=a){
	  FIFOQPush(Q, q);
	  DrawCImagePixel(cdraw, alpha, q, color, a);
	}
      }
    }
  }

  FIFOQDestroy(Q);
  DestroyAdjRel(&A);
}


void    DrawImageFloodFill(Image *draw, 
			   Image *alpha, 
			   int s, 
			   int val,
			   int a){
  int p,q,n,i,old;
  FIFOQ *Q; 
  AdjRel *A;
  Pixel u,v;

  old = draw->val[s];
  if(old==val) return;

  n = draw->ncols*draw->nrows;
  Q = FIFOQNew(n);
  A = Circular(1.0);
  if(alpha->val[s]<=a){
    FIFOQPush(Q, s);
    DrawImagePixel(draw, alpha, s, val, a);
  }

  while(!FIFOQEmpty(Q)){
    p = FIFOQPop(Q);

    u.x = p%draw->ncols;
    u.y = p/draw->ncols;
    for (i=1; i < A->n; i++){
      v.x = u.x + A->dx[i];
      v.y = u.y + A->dy[i];
      if (ValidPixel(draw,v.x,v.y)){
	q = v.x + draw->tbrow[v.y];
	if(draw->val[q]==old &&
	   alpha->val[q]<=a){
	  FIFOQPush(Q, q);
	  DrawImagePixel(draw, alpha, q, val, a);
	}
      }
    }
  }

  FIFOQDestroy(Q);
  DestroyAdjRel(&A);
}


void    DrawCImageLine(CImage *cdraw, 
		       Image *alpha, 
		       int p, int q, 
		       float r, 
		       int color,
		       int a,
		       bool smooth){
  DrawImageLine(cdraw->C[0], alpha, p, q, r, t0(color), a, smooth);
  DrawImageLine(cdraw->C[1], alpha, p, q, r, t1(color), a, smooth);
  DrawImageLine(cdraw->C[2], alpha, p, q, r, t2(color), a, smooth);
}


void    DrawImageLine(Image *draw, 
		      Image *alpha, 
		      int p, int q, 
		      float r, 
		      int val,
		      int a,
		      bool smooth){
  int x1, y1, xn, yn, vx, vy;
  float Dx, Dy;
  int amostras; /* numero de pontos a serem pintados */
  float m; /* coeficiente angular da reta */
  int i,ncols;
  float xk, yk;

  ncols = draw->ncols;
  x1 = p%ncols; y1 = p/ncols;
  xn = q%ncols; yn = q/ncols;
  vx = xn - x1; 
  vy = yn - y1;
  
   if(vx == 0){  
     Dx = 0.0;
     Dy = (float) SIGN(vy);
     amostras = abs(vy)+1;
   }
   else{  
     m = ((float)vy )/((float)vx);
     if( abs(vx) > abs(vy)){
       Dx = (float) SIGN(vx);
       Dy = m * Dx;
       amostras = abs(vx)+1; 
     }
     else{  
       Dy = (float) SIGN(vy);
       Dx = Dy / m;
       amostras = abs(vy)+1;
     }
   }
   
   xk = (float) x1;
   yk = (float) y1;
   for(i = 0; i < amostras; i++){ 
     if( ValidPixel(draw,ROUND(xk),ROUND(yk)) ){
       p = ROUND(xk)+draw->tbrow[ROUND(yk)];
       DrawImageCircle(draw, alpha, p, r, val, a, smooth);
     }
     xk += Dx;
     yk += Dy;
   }
}


void    DrawCImageCircle(CImage *cdraw, 
			 Image *alpha, 
			 int c, 
			 float r, 
			 int color,
			 int a,
			 bool smooth){
  DrawImageCircle(cdraw->C[0], alpha, c, r, t0(color), a, smooth);
  DrawImageCircle(cdraw->C[1], alpha, c, r, t1(color), a, smooth);
  DrawImageCircle(cdraw->C[2], alpha, c, r, t2(color), a, smooth);
}


void    DrawImageCircle(Image *draw, 
			Image *alpha, 
			int c, 
			float r, 
			int val,
			int a,
			bool smooth){
  int q,dx,dy,ncols,nrows,ri,al;
  float d;
  Pixel C;

  ri = ROUND(r);
  ncols = draw->ncols;
  nrows = draw->nrows;
  C.x = c%ncols;
  C.y = c/ncols;
  for(dy=-ri; dy<=ri; dy++){
    for(dx=-ri; dx<=ri; dx++){
      if(ValidPixel(draw, dx+C.x, dy+C.y)){
	q = dx+C.x + draw->tbrow[dy+C.y];
	d = dx*dx + dy*dy;
	if( d<(r-0.5)*(r-0.5) || !smooth)
	  al = a;
	else if( d>=(r-0.5)*(r-0.5) && d<(r+0.5)*(r+0.5))
	  al = a/2;
	else
	  continue;
	
	DrawImagePixel(draw, alpha, q, val, al);
      }
    }
  }
}



void    DrawImageCircumference(Image *draw, 
			       Image *alpha, 
			       int c, 
			       float r, 
			       int val,
			       int a){
  int q,dx,dy,ncols,nrows,ri;
  float d;
  Pixel C;

  ri = ROUND(r);
  ncols = draw->ncols;
  nrows = draw->nrows;
  C.x = c%ncols;
  C.y = c/ncols;
  for(dy=-ri; dy<=ri; dy++){
    for(dx=-ri; dx<=ri; dx++){
      d = dx*dx + dy*dy;
      if( d>= (r-0.5)*(r-0.5) && d<(r+0.5)*(r+0.5) ){
	if(ValidPixel(draw, dx+C.x, dy+C.y)){
	  q = dx+C.x + draw->tbrow[dy+C.y];
	  DrawImagePixel(draw, alpha, q, val, a);
	}
      }
    }
  }
}



void    DrawImageFillRectangle(Image *draw, 
			       Image *alpha, 
			       int p, int q, 
			       int val,
			       int a){
  Pixel u,v;
  int i,j,k;
  int ncols,nrows;

  ncols = alpha->ncols;
  nrows = alpha->nrows;
  u.x = p%ncols;
  u.y = p/ncols;

  v.x = q%ncols;
  v.y = q/ncols;

  for(i=u.y; i<=v.y; i++){
    for(j=u.x; j<=v.x; j++){
      k = j + i*ncols;
      DrawImagePixel(draw, alpha, k, val, a);
    }
  }
}


void    DrawCImageFillRectangle(CImage *cdraw, 
				Image *alpha, 
				int p, int q, 
				int color,
				int a){
  DrawImageFillRectangle(cdraw->C[0], alpha, p, q, t0(color), a);
  DrawImageFillRectangle(cdraw->C[1], alpha, p, q, t1(color), a);
  DrawImageFillRectangle(cdraw->C[2], alpha, p, q, t2(color), a);
}



void    DrawCImageArrow(CImage *cdraw, 
			Image *alpha, 
			int p, int q, 
			float r, float w, float h,
			int color,
			int a,
			bool smooth){
  DrawImageArrow(cdraw->C[0], alpha, p, q, r,w,h, t0(color), a, smooth);
  DrawImageArrow(cdraw->C[1], alpha, p, q, r,w,h, t1(color), a, smooth);
  DrawImageArrow(cdraw->C[2], alpha, p, q, r,w,h, t2(color), a, smooth);
}


void DrawImageArrow(Image *draw, 
		    Image *alpha, 
		    int p, int q, 
		    float r, float w, float h,
		    int val,
		    int a,
		    bool smooth){
  float dlm,dlx,dly,dtx,dty;
  int xc,yc,xb,yb,xq,yq,xp,yp,c,b;

  xq = q%(alpha->ncols);
  yq = q/(alpha->ncols);
  xp = p%(alpha->ncols);
  yp = p/(alpha->ncols);

  // A vector along the arc:
  dlm = hypot(xq - xp, yq - yp);
  dlx = (xq - xp)/dlm;
  dly = (yq - yp)/dlm;
  // A vector orthogonal to the arc:
  dtx = -dly;
  dty = dlx;
  // Arrowhead corners:
  xc = xq - ROUND(h*dlx + w*dtx);
  yc = yq - ROUND(h*dly + w*dty);
  xb = xq - ROUND(h*dlx - w*dtx);
  yb = yq - ROUND(h*dly - w*dty);
  // Draw arc from p to q:
  DrawImageLine(draw, alpha, p, q, r, val, a, smooth);
  // Paint arrowhead:
  c = xc + yc*(alpha->ncols);
  b = xb + yb*(alpha->ncols);
  DrawImageLine(draw, alpha, c, b, r, val, a, smooth);
  DrawImageLine(draw, alpha, b, q, r, val, a, smooth);
  DrawImageLine(draw, alpha, c, q, r, val, a, smooth);
}


void    DrawCImageSet(CImage *cdraw, Image *alpha, Set *S,
		      float r, int color, int a, bool smooth){
  Set *aux;
  int p;

  aux = S;
  while(aux != NULL){
    p = aux->elem;
    DrawCImageCircle(cdraw, alpha, p, r, color, a, smooth);
    aux = aux->next;
  }
}


void    DrawCImageSimpleDot(CImage *cdraw, Image *alpha, int c,
			    float r, int color, int a){
  int q,dx,dy,ncols,nrows,ri,al,co;
  float d;
  Pixel C;

  ri = ROUND(r);
  ncols = alpha->ncols;
  nrows = alpha->nrows;
  C.x = c%ncols;
  C.y = c/ncols;
  for(dy=-ri; dy<=ri; dy++){
    for(dx=-ri; dx<=ri; dx++){
      if(ValidPixel(alpha, dx+C.x, dy+C.y)){
	q = dx+C.x + alpha->tbrow[dy+C.y];
	d = dx*dx + dy*dy;
	if( d<(r-0.5)*(r-0.5) ){
	  al = a;
	  co = color;
	}
	else if( d>=(r-0.5)*(r-0.5) && d<(r+0.5)*(r+0.5)){
	  al = a/2;
	  co = 0x000000;
	}
	else
	  continue;
	
	DrawCImagePixel(cdraw, alpha, q, co, al);
      }
    }
  }
}


void    DrawCImageStripedDot(CImage *cdraw, Image *alpha, int c,
			     float r, int color, int a,
			     int n, double angle){
  double *dx,*dy,*dx2,*dy2;
  double xr,yr;
  int i,p,q,xc,yc,ncols;

  angle = -angle;
  ncols = alpha->ncols;
  xc = c%ncols;
  yc = c/ncols;
  DrawCImageSimpleDot(cdraw, alpha, c, r, color, a);

  dx = AllocDoubleArray(n);
  dy = AllocDoubleArray(n);
  dx2 = AllocDoubleArray(n);
  dy2 = AllocDoubleArray(n);

  dy[0] = -r;
  for(i=1; i<n; i++){
    dy[i] = dy[i-1] + (2.0*r)/n;
    dx[i] = sqrt(r*r - dy[i]*dy[i]);
    dy2[i] = dy[i];
    dx2[i] = -dx[i];
  }
  for(i=1; i<n; i++){
    xr = dx[i]*cos(angle)-dy[i]*sin(angle);
    yr = dy[i]*cos(angle)+dx[i]*sin(angle);
    dx[i] = xr;
    dy[i] = yr;
    xr = dx2[i]*cos(angle)-dy2[i]*sin(angle);
    yr = dy2[i]*cos(angle)+dx2[i]*sin(angle);
    dx2[i] = xr;
    dy2[i] = yr;
  }
  for(i=1; i<n; i++){
    p = ROUND(xc+dx[i])  + alpha->tbrow[ROUND(yc+dy[i])];
    q = ROUND(xc+dx2[i]) + alpha->tbrow[ROUND(yc+dy2[i])];
    DrawCImageLine(cdraw, alpha, p, q,
		   0.0, 0x000000, a, false);
  }
  free(dx2);
  free(dy2);
  free(dx);
  free(dy);
}


void    DrawCImageGridDot(CImage *cdraw, Image *alpha, int c,
			  float r, int color, int a,
			  int n, double angle){
  double *dx,*dy,*dx2,*dy2;
  double xr,yr;
  int i,j,p,q,xc,yc,ncols;

  angle = -angle;
  ncols = alpha->ncols;
  xc = c%ncols;
  yc = c/ncols;
  DrawCImageSimpleDot(cdraw, alpha, c, r, color, a);

  dx = AllocDoubleArray(n);
  dy = AllocDoubleArray(n);
  dx2 = AllocDoubleArray(n);
  dy2 = AllocDoubleArray(n);

  dy[0] = -r;
  for(i=1; i<n; i++){
    dy[i] = dy[i-1] + (2.0*r)/n;
    dx[i] = sqrt(r*r - dy[i]*dy[i]);
    dy2[i] = dy[i];
    dx2[i] = -dx[i];
  }

  for(j=0; j<2; j++){
    for(i=1; i<n; i++){
      xr = dx[i]*cos(angle)-dy[i]*sin(angle);
      yr = dy[i]*cos(angle)+dx[i]*sin(angle);
      dx[i] = xr;
      dy[i] = yr;
      xr = dx2[i]*cos(angle)-dy2[i]*sin(angle);
      yr = dy2[i]*cos(angle)+dx2[i]*sin(angle);
      dx2[i] = xr;
      dy2[i] = yr;
    }
    for(i=1; i<n; i++){
      p = ROUND(xc+dx[i])  + alpha->tbrow[ROUND(yc+dy[i])];
      q = ROUND(xc+dx2[i]) + alpha->tbrow[ROUND(yc+dy2[i])];
      DrawCImageLine(cdraw, alpha, p, q,
		     0.0, 0x000000, a, false);
    }
    angle = PI/2.0;
  }

  free(dx2);
  free(dy2);
  free(dx);
  free(dy);
}



