#include "water.h"

/* This function computes the classical watershed with one influence
   zone per pixel of minimum.
*/

Image *ClassicalWatershed(Image *image)
{
  AdjRel *A=NULL;
  GQueue *Q=NULL;
  Image  *cost=NULL,*label=NULL;
  Pixel   u,v;
  int     i,p,q,n,tmp;
  
  Image *mov=CreateImage(image->ncols,image->nrows);
  char   filename[200];
  int    cont=0,frame=1;

  /* Initializations */

  cost  = CreateImage(image->ncols,image->nrows);
  label = CreateImage(image->ncols,image->nrows);
  n     = image->ncols*image->nrows;
  Q     = CreateGQueue(MaximumValue(image)+2,n,cost->val);
  A     = Circular(1.5);

  for (p=0; p < n; p++){
    cost->val[p] =image->val[p]+1;
    mov->val[p]=label->val[p]=p;
    InsertGQueue(&Q,p);
  }

  /* Ordered Propagation */

  while (!EmptyGQueue(Q)){
    p   = RemoveGQueue(Q);

    mov->val[p]=label->val[p];

    /* Create movie */

    cont++;
    if (CREATE_MOVIE){
      if ((cont%1000)==0){
	sprintf(filename,"mov%d.%03d",MOVIE_NUMBER,frame);
	frame++;
	WriteImage(mov,filename);
      }
    }

    u.x = p%image->ncols;
    u.y = p/image->ncols;
    for (i=1; i < A->n; i++) {
      v.x = u.x + A->dx[i];
      v.y = u.y + A->dy[i];
      if (ValidPixel(image,v.x,v.y)){
	q   = v.x + image->tbrow[v.y];
	if (cost->val[p] < cost->val[q]){
	  tmp = MAX(cost->val[p],image->val[q]);
	  if (tmp < cost->val[q]){
	    RemoveGQueueElem(Q,q);
	    cost->val[q] =tmp;
	    label->val[q]=label->val[p];
	    InsertGQueue(&Q,q);
	  }
	}
      }
    }
  }

  /* Memory Deallocation */
 
  DestroyGQueue(&Q);
  DestroyImage(&cost);
  DestroyImage(&label);
  DestroyAdjRel(&A);

  return(mov);
}

/* This function computes the classical watershed with one influence
   zone per minimum.
*/

Image *ClassicalWatershedOnTheFlyLabeling(Image *image)
{
  AdjRel *A=NULL;
  GQueue *Q=NULL;
  Image  *cost=NULL,*label=NULL;
  Pixel   u,v;
  int     i,p,q,n,tmp;

  Image *mov=CreateImage(image->ncols,image->nrows);
  char   filename[200];
  int    cont=0,frame=1;
 
  /* Initializations */

  cost  = CreateImage(image->ncols,image->nrows);
  label = CreateImage(image->ncols,image->nrows);
  n     = image->ncols*image->nrows;
  Q     = CreateGQueue(MaximumValue(image)+2,n,cost->val);
  A     = Circular(1.5);

  for (p=0; p < n; p++){
    cost->val[p] =image->val[p]+1;
    mov->val[p]=label->val[p] =p;
    InsertGQueue(&Q,p);
  }

  /* Ordered Propagation */

  while (!EmptyGQueue(Q)){
    p   = RemoveGQueue(Q);


    mov->val[p]=label->val[p];

    /* Create movie */

    cont++;
    if (CREATE_MOVIE){
      if (cont < 1000){
	if ((cont%100)==0){
	sprintf(filename,"mov%d.%03d",MOVIE_NUMBER,frame);
	frame++;
	WriteImage(mov,filename);
	}
      }else{
	if ((cont%1000)==0){
	  sprintf(filename,"mov%d.%03d",MOVIE_NUMBER,frame);
	  frame++;
	  WriteImage(mov,filename);
	}
      }
    }
  
    if (label->val[p]==p){
      cost->val[p]--;
    }
    u.x = p%image->ncols;
    u.y = p/image->ncols;
    for (i=1; i < A->n; i++) {
      v.x = u.x + A->dx[i];
      v.y = u.y + A->dy[i];
      if (ValidPixel(image,v.x,v.y)){
	q   = v.x + image->tbrow[v.y];
	if (cost->val[p] < cost->val[q]){
	  tmp = MAX(cost->val[p],image->val[q]);
	  if (tmp < cost->val[q]){
	    RemoveGQueueElem(Q,q);
	    cost->val[q] =tmp;
	    label->val[q]=label->val[p];
	    InsertGQueue(&Q,q);
	  }
	} 
      }
    }
  }

  /* Memory Deallocation */
 
  DestroyGQueue(&Q);
  DestroyImage(&cost);
  DestroyImage(&label);
  DestroyAdjRel(&A);

  return(mov);
}

/* This function computes the superior reconstruction in cost and the
   watershed transform in label. */

Image *SuperiorReconstruction(Image *image, Image *initcost)
{
  AdjRel *A=NULL;
  GQueue *Q=NULL;
  Image  *cost=NULL,*label=NULL;
  Pixel   u,v;
  int     i,p,q,n,tmp;

  Image *mov=CreateImage(image->ncols,image->nrows);
  char   filename[200];
  int    cont=0,frame=1;
 
  /* Initializations */

  cost  = CreateImage(image->ncols,image->nrows);
  label = CreateImage(image->ncols,image->nrows);
  n     = image->ncols*image->nrows;
  Q     = CreateGQueue(MaximumValue(initcost)+2,n,cost->val);
  A     = Circular(1.5);

  for (p=0; p < n; p++){
    mov->val[p]=cost->val[p] =initcost->val[p]+1;
    label->val[p] =p;
    InsertGQueue(&Q,p);
  }

  /* Ordered Propagation */

  while (!EmptyGQueue(Q)){
    p   = RemoveGQueue(Q);

    mov->val[p]=cost->val[p];

    /* Create movie */

    cont++;
    if (CREATE_MOVIE){
      if ((cont%1000)==0){
	sprintf(filename,"mov%d.%03d",MOVIE_NUMBER,frame);
	frame++;
	WriteImage(mov,filename);
      }
    }
  
    if (label->val[p]==p){
      cost->val[p]--;
    }
    u.x = p%image->ncols;
    u.y = p/image->ncols;
    for (i=1; i < A->n; i++) {
      v.x = u.x + A->dx[i];
      v.y = u.y + A->dy[i];
      if (ValidPixel(image,v.x,v.y)){
	q   = v.x + image->tbrow[v.y];
	if (cost->val[p] < cost->val[q]){
	  tmp = MAX(cost->val[p],image->val[q]);
	  if (tmp < cost->val[q]){
	    RemoveGQueueElem(Q,q);
	    cost->val[q] =tmp;
	    label->val[q]=label->val[p];
	    InsertGQueue(&Q,q);
	  }
	} 
      }
    }
  }

  /* Memory Deallocation */
 
  DestroyGQueue(&Q);
  DestroyImage(&label);
  DestroyImage(&cost);
  DestroyAdjRel(&A);

  return(mov);
}

