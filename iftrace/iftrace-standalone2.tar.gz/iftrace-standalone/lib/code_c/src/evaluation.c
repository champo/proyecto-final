#include "evaluation.h"


real DiceSimilarity(Image *mask1, Image *mask2)
{
    real nelems_intersec,nelems_union;
    int  p,n;

    /* compute similarity between shapes */
    n = mask1->ncols*mask1->nrows;
    nelems_intersec = nelems_union = 0.0;
    for (p=0; p<n; p++)
    {
        if (mask1->val[p] > 0)
        {
            nelems_union++;
            if (mask2->val[p] > 0)
                nelems_intersec++;
        }
        else
        {
            if (mask2->val[p]>0)
                nelems_union++;
        }
    }

    return ((2.0*nelems_intersec)/(nelems_union+nelems_intersec));
}

bool ConfMatrix(Image* label, Image* mask, int* truepos, int* trueneg, int* falsepos, int* falseneg)
{
    if(label == NULL || mask == NULL) return false;

    if(label->ncols != mask->ncols || label->nrows != mask->nrows) return false;

    int p;

    int n = label->ncols*label->nrows;
    int tp = 0, tn = 0, fp = 0, fn = 0;

    for(p = 0; p < n; p++)
    {
        if(label->val[p] > 0)
        {
            if(mask->val[p] > 0)
                tp++;
            else
                fp++;
        }else{

            if(mask->val[p] > 0)
                fn++;
            else
                tn++;
        }
    }

    if(truepos != NULL) *truepos = tp;
    if(trueneg != NULL) *trueneg = tn;
    if(falsepos != NULL) *falsepos = fp;
    if(falseneg != NULL) *falseneg = fn;

    return true;
}

real Precision(int tp, int fp)
{
    if(tp + fp == 0) return 0;

    return (real)tp/(real)(tp + fp);
}

real Recall(int tp, int fn)
{
    if(tp + fn == 0) return 0;

    return (real)tp/(real)(tp + fn);
}

real FMeasure(real precision, real recall)
{
    if(precision + recall == 0) return 0;

    return 2*(precision*recall)/(precision + recall);
}

real ComputeFMeasure(Image* label, Image* mask)
{
    if(label == NULL || mask == NULL) return -1;

    int tp = 0, tn = 0, fp = 0, fn = 0;

    ConfMatrix(label, mask, &tp, &tn, &fp, &fn);

    real f = FMeasure(Precision(tp,fp), Recall(tp, fn));

    return f;
}

bool BinConfMatrix(Image* label, Image* mask, int* truepos, int* trueneg, int* falsepos, int* falseneg)
{
    if(label == NULL || mask == NULL) return false;

    if(label->ncols != mask->ncols || label->nrows != mask->nrows) return false;

    int p;

    int n = label->ncols*label->nrows;
    int tp = 0, tn = 0, fp = 0, fn = 0;

    int lbmax = MaximumValue(label), maskmax = MaximumValue(mask);

    for(p = 0; p < n; p++)
    {
        if(label->val[p] == lbmax)
        {
            if(mask->val[p] == maskmax)
                tp++;
            else
                fp++;
        }else{

            if(mask->val[p] == maskmax)
                fn++;
            else
                tn++;
        }
    }

    if(truepos != NULL) *truepos = tp;
    if(trueneg != NULL) *trueneg = tn;
    if(falsepos != NULL) *falsepos = fp;
    if(falseneg != NULL) *falseneg = fn;

    return true;
}

real ComputeBinFMeasure(Image* label, Image* mask)
{
    if(label == NULL || mask == NULL) return -1;

    int tp = 0, tn = 0, fp = 0, fn = 0;

    BinConfMatrix(label, mask, &tp, &tn, &fp, &fn);

    real f = FMeasure(Precision(tp,fp), Recall(tp, fn));

    return f;
}

real ComputeFuzzyGT(Image* label, Image* mask)
{
    if(label == NULL || mask == NULL) return -1;

    int i;
    int Imax = MaximumValue(mask);
    real RImax = (real)Imax;

    real measure = 0;
    real total = 0;

    for(i = 0; i < label->ncols*label->nrows; i++)
    {
        if(label->val[i] == 1)
            if(mask->val[i] == 0)
                measure += -RImax;
            else
                measure += (real)mask->val[i];
        else
            if(mask->val[i] == Imax)
                measure += -RImax;
            else
                measure += (real)-mask->val[i];

        total += ((real)mask->val[i]);
    }

    return measure/total;
}
