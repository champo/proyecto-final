#include "myopfsse.h"
#include <xmmintrin.h>
#include <omp.h>
#include "commonsse.h"
#include "ssemath.h"

inline __m128 ArcWeightPS(__m128 A, float maxdist)
{
    return _mm_mul_ps(_mm_div_ps(A,_mm_set_ps(maxdist,maxdist,maxdist,maxdist)), _mm_set_ps(MAXARCW,MAXARCW,MAXARCW,MAXARCW));
}


float** AlignSGFeatures(Subgraph* sg, float padding, int* n)
{
    register int i;

    float** algn = (float**)calloc(sg->nfeats,sizeof(float));

    *n = sg->nnodes+4-sg->nnodes%4; // total number of nodes + extra padding

    for(i=sg->nfeats; i--;)
        algn[i] = AllocAlgnFloatArray(*n,16);

    for(i = sg->nfeats; i--;)
    {
        int j;
        for(j = sg->nnodes; j--;)
            algn[i][j] = sg->node[j].feat[i];

        for(j = sg->nnodes; j < *n;j++)
            algn[i][j] = padding;
    }

    return algn;
}

void DestroyAlignedFeats(float*** algn, int nfeats)
{
    int i;

    for(i = nfeats; i--;)
        _mm_free((*algn)[i]);

    free(*algn);

    *algn = NULL;
}


/** Threaded SSE **/

void AlgnSGFeatsNPval(Subgraph* sg, float*** features, float** pathval)
{
    const int nnodes = sg->nnodes;
    const int n = nnodes + 4 - nnodes%4;
    const int nfeats = sg->nfeats;

    *features = (float**)_mm_malloc(nfeats*sizeof(float*), 16);
    *pathval = AllocAlgnFloatArray(n,16);

    int i,j;

    for(i = 0; i < nfeats; i++)
        (*features)[i] = AllocAlgnFloatArray(n, 16);

    for(j = nnodes; j--;)
    {
        (*pathval)[j] = sg->node[j].pathval;

        for(i = nfeats; i--;)
            (*features)[i][j] = sg->node[j].feat[i];
    }

    for(j = nnodes; j < n;j++)
    {
        (*pathval)[j] = FLT_MAX;

        for(i = nfeats; i--;)
            (*features)[i][j] = 0.0;
    }
}

Image* TFOPFMembershipMapSSE(Subgraph* sgtrainobj, Subgraph* sgtrainbkg, Features* f, int nthreads)
{
	return TFOPFMembershipMapSSEBB(sgtrainobj, sgtrainbkg, f, nthreads, 0, 0, f->ncols, f->nrows);
}

void TFOPFPathValueMapSSEBB(Subgraph *sg, Features *feat,
								float **features, float *pathval,
								Matrix* pvalmap,
								const int xmin, const int ymin,
								const int xmax, const int ymax)
{
    const int nnodes = sg->nnodes;// total number of nodes + extra paddingconst int nloop = n/4;
    const int n = nnodes+4-nnodes%4;
    const int nloop = n/4;
    const int nfeats = feat->nfeats;

    register int y;

	#pragma omp parallel for
    for(y = ymin; y < ymax; y++)
    {
    	register int x;

        for(x = xmin; x < xmax; x++)
        {
        	int i, j;
            int p = x + y*feat->ncols;
			// used to store the feature vector of a given pixel p
			// using the format F0,F0,F0,F0,F1,F1,F1,F1,...,Fn,Fn,Fn,Fn
			float f[4*nfeats] __attribute__((aligned(16)));

            for(i = 4*nfeats; i--;)
                f[i] = feat->elem[p].feat[i/4];

            __m128 minCost = _mm_set_ps(FLT_MAX, FLT_MAX, FLT_MAX, FLT_MAX);

            __m128* pval = (__m128*)pathval;

            for(j = 0; j < nloop; j++)
            {
                __m128 acc = _mm_setzero_ps();
                __m128* p1 = (__m128*)f;
                __m128 p2;
                const int index = j*4;
                for(i = 0; i < nfeats; i++)
                {
                    p2 = _mm_load_ps(features[i] + index);

                    __m128 sub = _mm_sub_ps(p2,*p1);

                    acc = _mm_add_ps(acc,_mm_mul_ps(sub,sub));
                    p1++;
                }

                minCost = _mm_min_ps(_mm_max_ps(ArcWeightPS(acc, sg->df), *pval),minCost);

                pval++;
            }
            pvalmap->val[p] = (double)MinimumPS(minCost);
        }
    }
}



Image* TFOPFMembershipMapSSEBB(Subgraph* sgtrainobj, Subgraph* sgtrainbkg, Features* f, int nthreads,
									int xmin, int ymin, int xmax, int ymax)
{
    register int i;
    Image* objMap = NULL;

    Matrix *obj=CreateMatrix(f->ncols,f->nrows);
    Matrix *bkg=CreateMatrix(f->ncols,f->nrows);

    float** featuresObj = NULL;
    float** featuresBkg = NULL;
    float* pathvalObj = NULL;
    float* pathvalBkg = NULL;

    AlgnSGFeatsNPval(sgtrainobj, &featuresObj, &pathvalObj);
    AlgnSGFeatsNPval(sgtrainbkg, &featuresBkg, &pathvalBkg);


	omp_set_num_threads(nthreads);
	TFOPFPathValueMapSSEBB(sgtrainobj, f, featuresObj, pathvalObj,
								obj, xmin, ymin, xmax, ymax);

	TFOPFPathValueMapSSEBB(sgtrainbkg, f, featuresBkg, pathvalBkg,
								bkg, xmin, ymin, xmax, ymax);

    objMap = ProbMapBB(obj,bkg,xmin,ymin,xmax,ymax);

    for(i = 0; i < sgtrainobj->nfeats; i++)
    {
        _mm_free(featuresObj[i]);
        _mm_free(featuresBkg[i]);
    }


    _mm_free(featuresObj);
    _mm_free(featuresBkg);
    _mm_free(pathvalObj);
    _mm_free(pathvalBkg);

    DestroyMatrix(&obj);
    DestroyMatrix(&bkg);

    return objMap;
}


