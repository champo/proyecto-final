
#ifndef _EVALUATION_H_
#define _EVALUATION_H_

#include "ift.h"
#include "shared.h"


real    DiceSimilarity(Image *mask1, Image *mask2);

real Precision(int tp, int fp);

real Recall(int tp, int fn);

real FMeasure(real precision, real recall);

real ComputeFMeasure(Image* label, Image* mask);

bool ConfMatrix(Image* label, Image* mask, int* truepos, int* trueneg, int* falsepos, int* falseneg);

real ComputeBinFMeasure(Image* label, Image* mask);

bool BinConfMatrix(Image* label, Image* mask, int* truepos, int* trueneg, int* falsepos, int* falseneg);

real ComputeFuzzyGT(Image* label, Image* mask);

#endif

