
#ifndef _CODE_C_H_
#define _CODE_C_H_

#include "gradient.h"
#include "sparsegraph.h"
#include "methods.h"
#include "featmap.h"
#include "preproc.h"
#include "shared.h"
#include "view.h"
#include "draw.h"
#include "myopf.h"
#include "livewire.h"
#include "lbp.h"
#include "bricor.h"
#include "evaluation.h"
#include "code_c.h"
#include "mymorphology.h"
#include "video_util.h"
#include "myopfsse.h"

#define GREY_IMAGE    0
#define COLOR_IMAGE   1
#define TXT_GRAPH     2

#endif


