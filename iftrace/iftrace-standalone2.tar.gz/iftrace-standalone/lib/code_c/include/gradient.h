
#ifndef _GRADIENT_H_
#define _GRADIENT_H_

#include "common.h"
#include "adjacency.h"
#include "cimage.h"
#include "filtering.h"
#include "gqueue.h"
#include "segmentation.h"
#include "opf.h"

#include "shared.h"
#include "featmap.h"

Image *nDimGradient(CImage *cimg);
Image *nDimSobel(CImage *cimg);
Image *SimpleGradient(Image *img);

Image *TextGradient(Image *img,float radius);
//Image *FeatureGradient(Image *img,int nfeats);
Image *TextGradientNew(Image *img,int rsize);
Image *ColorDistGradient(CImage *cimg);

Image *ImageGradient(Image *img,float radius);
Features *VImageGradient(Image *img,float radius, int frame);
Features *VFeaturesGradient(Features *f,float radius);
Features *BFeaturesGradient(Features *f, int nbands, int nscales, float radius);
Image *FeatObjVGrads2Image(Features *Gfeat, Features *Gobj, int* Wmax, float Wobj);

Image *VMaxEdgeGradient(Features* feat, Image *objMap, float Wobj, float radius);

/** Video **/
Features *VFeaturesGradientBB(Features *f,float radius, int xmin, int ymin, int xmax, int ymax);
Features *VImageGradientBB(Image *img,float radius, int xmin, int ymin, int xmax, int ymax);
Image *FeatObjVGrads2ImageBB(Features *Gfeat, Features *Gobj, int* Wmax, float Wobj, int xmin, int ymin, int xmax, int ymax);
#endif
