#ifndef _GABOR_H_
#define _GABOR_H_

#include <assert.h>
#include "ift.h"

  #ifndef PI
    #define PI 3.14159265f
  #endif

  #ifndef NSZE
    // number of scales during image decomposition.
    #define NSZE 128
  #endif

  #ifndef NSCALES
    // number of scales during image decomposition.
    #define NSCALES 4
  #endif

  #ifndef NORIENTATIONS
    // number of orientations during image decomposition.
    #define NORIENTATIONS 6
  #endif

  #ifndef DUH
    // highest frequency.
    #define DUH 0.4
  #endif

  #ifndef DUL
    // lowest frequency.
    #define DUL 0.05
  #endif


  typedef struct{
      DImage * m_pReal;
      DImage  * m_pImag;
      int m_nSze;
  }gabor;

  typedef struct{
    Spectrum ** m_pSpectralFilterBank;
    Features * m_pFeatures;
    int orientations;
    int scales;
  }Filterbank;

// Gabor functions.
  gabor* CreateGabor( int );
  void gaborFilter( gabor *, int, int );
  Features* GaborFeats(Features* feats);
  void DumpGabor( gabor *, int, char * );
  void DestroyGabor( gabor ** );

// Filterbank functions.
  Filterbank * CreateFilterbank( int );
  void applyFilterbank( Filterbank *, Features * );
  void DestroyFilterbank( Filterbank ** );

#endif
