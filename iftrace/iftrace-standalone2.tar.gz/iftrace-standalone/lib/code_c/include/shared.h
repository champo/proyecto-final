
#ifndef _SHARED_H_
#define _SHARED_H_

#include "ift.h"
#include "filelist.h"

int     MaximumNotInfinityValue(Image *img);

Set    *ImageBorder(Image *img);
Set    *ImageWideBorder(Image *img, int size);
Set    *ObjectBorder2Set(Image *label);

CImage *CopyCImageMask(CImage *cimg, 
		       Image *mask, int bkgcolor);
CImage *CopySubCImage(CImage *cimg, 
		      int j1, int i1, 
		      int j2, int i2);
void    MyPasteSubCImage(CImage *cimg, CImage *sub, 
			 int bkgcolor, int j, int i);
void    ComputeMBB(CImage *cimg, int bkgcolor, 
		   int *j1, int *i1, 
		   int *j2, int *i2);

Image  *MyAdd(Image *img, int value);

void    DrawSet2Image(Image *img, Set *S, 
		      int value);
void    DrawSet2CImage(CImage *cimg, Set *S, 
		       int color);

void    ConvertCImageList2jpeg(FileList *L);
void    ConvertCImageList2ppm(FileList *L);

CImage *MergeCImages(CImage *A, CImage *B);

void    MergeCImageList(FileList *in1,
			FileList *in2,
			FileList *out);

int     GetMinimumCurveIndex(Curve *C);

Curve  *RemoveEmptyBins(Curve *hist);

#endif


