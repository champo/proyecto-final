
#ifndef _MYOPF_H_
#define _MYOPF_H_

#include "ift.h"
#include "code_c.h"
#include <pthread.h>

#define USIS_OPFOBJLABEL 1
#define USIS_OPFBKGLABEL 0

Matrix *ImageDDF(Subgraph *sg, Features *f, int label);
Matrix *ImageDDFBB(Subgraph *sg, Features *f, int label, int xmin, int ymin, int xmax, int ymax);

void ClassifyDDF(Subgraph *sgTrain, Subgraph *sg);

// Compute node dist density for classification node
void NodeDD(Subgraph *sg, CNode *node);

// Compute node dist density for classification node
void NodeDDByTrueLabel(Subgraph *sg, CNode *node, int label);


void BestkMinErrorDDF(Subgraph *sgTrain,
		      Subgraph *sgEval, int kmax);

float LearningDDF(Subgraph **sgtrain, Subgraph **sgeval,
		 int iterations, int kmax);

Image *ObjProbMap(Matrix *dobj, Matrix *dbkg);
Image *BkgProbMap(Matrix *dobj, Matrix *dbkg);

int FindDDFkmax(Subgraph *sgTrain);

Matrix* ImagePVCompGraph(Subgraph* sgtrain, Features* f, int label);

void ImagePVMapsCompGraph(Subgraph* sgtrain, Features* f, Image** objMap, Image** bkgMap);

Subgraph* SubgraphFromMarkers(Features* f, Set* Si, Set* Se);

Subgraph* SplitSubgraphByTrueLabel(Subgraph* sg, int label);

/// Fuzzy opf
void FuzzySupTrainCompGraph(Subgraph *sg);

void FuzzyLearningCompGraph(Subgraph **sgtrainobj, Subgraph **sgtrainbkg, Subgraph **sgeval, int iterations);

/// Classify nodes of evaluation/test set for CompGraph
void FuzzyClassifyCompGraph(Subgraph *sgtrainobj, Subgraph* sgtrainbkg, Subgraph *sg);

void FuzzyImagePVMapsCompGraph(Subgraph* sgtrainobj, Subgraph* sgtrainbkg, Features* f, Image** objMap, Image** bkgMap);

/// Replace errors from evaluating set by non prototypes from training set
/// Notice that all nodes in this training set have the same label
void SwapErrorsbyLabeledNonPrototypes(Subgraph **sgtrain, Subgraph **sgeval);

/** Video **/
Image *ProbMapBB(Matrix *dobj, Matrix *dbkg, int xmin, int ymin, int xmax, int ymax);

void ImagePVMapsCompGraphBB(Subgraph* sgtrain, Features* f, Image** objMap, Image** bkgMap, int xmin, int ymin, int xmax, int ymax);

Matrix *ImagePVCompGraphBB(Subgraph *sg, Features *f, int label, int xmin, int ymin, int xmax, int ymax);

void FuzzyImagePVMapsCompGraphBB(Subgraph* sgtrainobj, Subgraph* sgtrainbkg, Features* f, Image** objMap, Image** bkgMap,
    int xmin, int ymin, int xmax, int ymax);


#endif


