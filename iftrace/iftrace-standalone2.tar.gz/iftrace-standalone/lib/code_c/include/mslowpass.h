#ifndef _MSLOWPASS_H_
#define _MSLOWPASS_H_

#include "code_c.h"

/******************************************/
/**  Author: Thiago Vallin Spina         **/
/**  November, 2008                      **/
/**  Used in MO445                       **/
/**  thiago.spina@gmail.com              **/
/**                                      **/
/**  Multi-scale low-pass filtering      **/
/******************************************/

#define MSLPSCALES 3


///** Applies a MSLP filterbank to an image.
// *
// *  @param img entry image
// *  @param bank SP filterbank
// *  @param startingnfeat index where the new image features created should
// *      begin to be placed in bank->m_pFeatures->feat array
// **/
//void ApplyMSLPFilterBank(DImage* img, Features* f, int startingnfeat, int scales);
//
///** Extracts MSLP features from all features in feats.
// *  By default 4 scales and 6 orientations are used, but that can be
// *  changed by altering MSLPSCALES and MSLPORIENTATIONS.
// *
// *  @param feats Features* already extracted from the image (e.g. Lab, RGB, etc.).
// *
// *  @return a new Features* struct which will contain feats->nfeats*SCALES*SPORIENTATIONS features,
// *      because each existent feature in feats will be filtered using SPSCALES and SPORIENTATIONS
// **/
//Features* MSLowPassFeats(Features* feats);
//



#endif // _LOWPASS_H_
