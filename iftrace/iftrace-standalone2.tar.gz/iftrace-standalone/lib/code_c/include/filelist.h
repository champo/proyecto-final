
#ifndef _FILELIST_H_
#define _FILELIST_H_

#include "ift.h"

typedef struct _fileList {
  char **files;
  int cap; //Capacity.
  int n;   //Number of files added.
} FileList;

FileList *CreateFileList(int cap);
void      DestroyFileList(FileList **L);

FileList *ReadFileList(char *filename);
void      WriteFileList(FileList *L,
			char *filename);

void      DeleteFilesInFileList(FileList *L);

void      AddFile(FileList *L, char *file);
char     *GetFile(FileList *L, int index);


//path:      Path where the files are,
//basename:  Basename of the files,
//first:     Number of the first file,
//last:      Number of the last file,
//ext:       File extension.
void  AddFiles(FileList *L,
	       char *path, 
	       char *basename, 
	       int first, int last,
	       char *ext);

//path:      Path where the files are,
//basename:  Basename of the files,
//first:     Number of the first file,
//last:      Number of the last file,
//nfiles:    Add "nfiles" from [first,last],
//ext:       File extension.
//
//Should use "void srand(unsigned int seed);" before calling.
void  AddRandomFiles(FileList *L,
		     char *path, 
		     char *basename, 
		     int first, int last,
		     int nfiles,
		     char *ext);

void      RemoveFileDirectory(char *file);
void      RemoveFileExtension(char *file);

//Removes the leading and trailing white space.
void      TrimString(char *str);
void      SubString(char *str,
		    int beginIndex,
		    int endIndex);

#endif

