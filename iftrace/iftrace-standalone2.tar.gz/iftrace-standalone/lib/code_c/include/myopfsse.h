#ifndef _MYOPFSSE_H_
#define _MYOPFSSE_H_

#include "ift.h"
#include "code_c.h"

// Creates an aligned float matrix with dimensions of NFEATSx[(NNODES+(4-NNODES%4)]
// and assigns the value of @param padding for the extra cells.
// The new number of columns is returned in *n
float** AlignSGFeatures(Subgraph* sg, float padding, int* n);

void DestroyAlignedFeats(float*** algn, int nfeats);

/** Threaded via OpenMP **/

Image* TFOPFMembershipMapSSE(Subgraph* sgtrainobj, Subgraph* sgtrainbkg, Features* f, int nthreads);
Image* TFOPFMembershipMapSSEBB(Subgraph* sgtrainobj, Subgraph* sgtrainbkg, Features* f, int nthreads, int xmin, int ymin, int xmax, int ymax);

#endif // _MYOPFSSE_H_
