
#ifndef _FEATMAP_H_
#define _FEATMAP_H_

#include "ift.h"


typedef struct _FeatMap {
  int n;
  int nfeat;
  real **data;
} FeatMap;


FeatMap *CreateFeatMap(int n, int nfeat);
void     DestroyFeatMap(FeatMap **fmap);

FeatMap *Image2FeatMapByMaxMinVal(Image *img, float radius);
FeatMap *CImage2FeatMap(CImage *cimg);

inline real DistanceSub(real *fv1, real *fv2, int nfeat);
inline real DistanceL1(real *fv1, real *fv2, int nfeat);
inline real DistanceL2(real *fv1, real *fv2, int nfeat);
inline real DistanceGRAD(real *fv1, real *fv2, int nfeat);

#endif


