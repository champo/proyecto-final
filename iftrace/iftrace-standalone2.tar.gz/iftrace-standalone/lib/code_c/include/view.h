
#ifndef _VIEW_H_
#define _VIEW_H_

#include "ift.h"
#include "shared.h"

Image  *WideHighlight(Image *img, Image *label, float radius, int value, bool fill);
CImage *CWideHighlight(CImage *cimg, Image *label, float radius, int color, bool fill);
CImage *CBWideHighlight(CImage *cimg, Image *label, float radius, int color, int bkgcolor, bool fill);

CImage *ColourLabels(CImage *cimg, Image *label, float radius, bool fill);
CImage *CWideHighlightLabels(CImage *cimg, Image *label, float radius, int *colormap, bool fill);
CImage *HighlightObjBkgLabels(CImage *cimg, Image *objlabel, Image *bkglabel, float radius, int objcolor, int bkgcolor, bool fill);
CImage *HighlightLabelsAndRegions(CImage *cimg, Image *label, Image *regions, float radius, int objcolor, int bkgcolor, bool fill);
CImage *WBHighlightLabelsAndRegions(CImage *cimg, Image *label, Image *regions, float radius, int objcolor, int bkgcolor, bool fill);

bool    HStripedTexture(int x, int y, int w, int h);
bool    VStripedTexture(int x, int y, int w, int h);
bool    BackslashTexture(int x, int y, int w, int h);
bool    SlashTexture(int x, int y, int w, int h);
bool    GridTexture(int x, int y, int w, int h);
bool    RGridTexture(int x, int y, int w, int h);

Image  *TextureHighlight(Image *img, Image *label, float radius, int value, bool fill,
			 bool (*texture)(int,int,int,int), int w, int h);
CImage *CTextureHighlight(CImage *cimg, Image *label, float radius, int color, bool fill,
			  bool (*texture)(int,int,int,int), int w, int h);


#endif

