#ifndef _LBP_H_
#define _LBP_H_

#include "ift.h"

Features* LBPFeats(Features* feats);

#endif
