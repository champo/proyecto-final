#include "iftrace.h"

iftrace_options_t GetIFTraceOptions (int frame0, int framen)
{
    iftrace_options_t o = (iftrace_options_t)calloc(1,sizeof(struct _iftrace_options_t));
    o->number_of_frames = framen - frame0 + 1;
    o->nFeatures = 400;
    o->start_seq = frame0;
    o->nscales = 4;
    o->Wobj  = 0.5;
    o->erosion_size = 5;
    o->dilation_size = 11;
    o->write_tmp_images = TRUE;
    o->total_time = 0.0;
    o->nrecords = 10;
    o->frame_path = NULL;
    o->diftradius = 1.5;
    o->seedspacing = 5;
    o->trackingFailureThreshold = 0.4;
    o->momentInvThreshold = 2;
    o->assessRetrainThreshold = 0.1;
    o->recoveryThreshold = 0.5;
    o->isSmallObject = FALSE; /*Adjust to TRUE in rat and plane video*/

	o->objColor = triplet(255,255,0);
	o->bkgColor = triplet(0,0,255);

    return o;
}

/*Auxiliary tracking functions*/
void SetCPUTime(clock_t* value)
{
    *value = clock();
}

double GetElapsedCPUTime(clock_t CPUstart, clock_t CPUend)
{
    return ((double) (CPUend - CPUstart)) / CLOCKS_PER_SEC;
}

void WriteClockExecution (FILE *clock, const char *information, clock_t CPUstart, clock_t CPUend, double *total_time)
{
	if(clock != NULL)
	{
		double partial_time = GetElapsedCPUTime(CPUstart, CPUend);
		*total_time += partial_time;
		fprintf(clock, "%s : %f\n", information, partial_time);
	}
}

double FILL (Image *Q, int x1, int y1, int x2, int y2, int x3, int y3)
{
    return (Q->val[x1 + Q->tbrow[y1]] + 2 * Q->val[x2 + Q->tbrow[y2]] + Q->val[x3 + Q->tbrow[y3]])/4.0;
}

void copy_to_wider_image (Image **img, int aditional_border_size, int label)
{
    int i, xa, xn, ya, yn;
    int ncols = (*img)->ncols + 2*aditional_border_size;
    int nrows = (*img)->nrows + 2*aditional_border_size;

    Image *Q = CreateImage(ncols, nrows);

    /*Copying original image to a wider frame*/
    for (yn = aditional_border_size, ya = 0; yn < nrows - aditional_border_size; yn++, ya++)
    {
        for (xn = aditional_border_size, xa = 0; xn < ncols - aditional_border_size; xn++, xa++)
        {
            Q->val[xn + Q->tbrow[yn]] = (*img)->val[xa + (*img)->tbrow[ya]];
        }
    }

    /*Filling the egde*/

    if (!label)
    {
        int m = aditional_border_size;

        for (i = 1; i <= m; i++)
        {
            int x;
            int nx = (*img)->ncols;
            int ny = (*img)->nrows;
            for (x = m - i + 1; x <= m + nx + i - 2; x++)
            {
                int xm = max (m - i + 1, x - 1);
                int xp = min (m + nx + i - 2, x + 1);
                int y = m - i;
                Q->val[x + Q->tbrow[y]] = (int)(FILL(Q, xm, y+1, x, y+1, xp, y+1));
                y = m + ny + i - 1;
                Q->val[x + Q->tbrow[y]] = (int)(FILL(Q, xm, y-1, x, y-1, xp, y-1));
            }
            int y;
            for (y = m - i + 1; y <= m + ny + i - 2; y++)
            {
                int ym = max (m - i + 1, y - 1);
                int yp = min (m + ny + i - 2, y + 1);
                int x = m - i;
                Q->val[x + Q->tbrow[y]] = (int)(FILL(Q, x+1, ym, x+1, y, x+1, yp));
                x = m + nx + i - 1;
                Q->val[x + Q->tbrow[y]] = (int)(FILL(Q, x-1, ym, x-1, y, x-1, yp));
            }
            x = m - i;
            y = m - i;
            Q->val[x + Q->tbrow[y]] = (int)((Q->val[x+1 + Q->tbrow[y]] + Q->val[x + Q->tbrow[y+1]])/2.0);
            x = m + nx - 1 + i;
            y = m - i;
            Q->val[x + Q->tbrow[y]] = (int)((Q->val[x-1 + Q->tbrow[y]] + Q->val[x + Q->tbrow[y+1]])/2.0);
            x = m - i;
            y = m + ny - 1 + i;
            Q->val[x + Q->tbrow[y]] = (int)((Q->val[x+1 + Q->tbrow[y]] + Q->val[x + Q->tbrow[y-1]])/2.0);
            x = m + nx - 1 + i;
            y = m + ny - 1 + i;
            Q->val[x + Q->tbrow[y]] = (int)((Q->val[x-1 + Q->tbrow[y]] + Q->val[x + Q->tbrow[y-1]])/2.0);
        }
    }

    DestroyImage(img);

    *img = Q;
}

FeatureVector1D * compute_features (Image *label)
{
    Curve *c1 = MomentInvariant(label);
    FeatureVector1D *f = CurveTo1DFeatureVector(c1);
    DestroyCurve(&c1);
    return f;
}

Image * GetContour (Image *img, int size)
{
    AdjRel *Adj1 = Circular(size);
    AdjRel *Adj2 = Circular(size-1);

    Image *tmp0 = CreateImage (img->ncols, img->nrows);
    Image *tmp1 = Dilate (img, Adj1);
    Image *tmp2 = Dilate (img, Adj2);

    int p,n;
    n = img->ncols*img->nrows;
    for(p = 0; p < n; p++)
    {
        if(tmp1->val[p] != tmp2->val[p])
        {
            tmp0->val[p] = 1.0;
        }
        else
        {
            tmp0->val[p] = 0.0;
        }
    }
    DestroyAdjRel(&Adj1);
    DestroyAdjRel(&Adj2);
    DestroyImage(&(tmp1));
    DestroyImage(&(tmp2));

    return tmp0;
}

int AssessRetraining (Image *obj, Image *seg, Set *Sext, double thresh)
{
    int p;
    int n = seg->ncols*seg->nrows;
    double x_sum = 0.0, x2_sum = 0.0;
    double pixels_in_object = 0.0;
    double nbkg_pixels = 0, misclass_bkg_pixels = 0.0;

    for(p = 0; p < n; p++)
    {
        if (seg->val[p] > 0)
        {
        	x_sum += obj->val[p];
        	x2_sum += obj->val[p]*obj->val[p];
            pixels_in_object++;
        }
    }

	if(pixels_in_object > 0)
	{
		double mean = x_sum / pixels_in_object;
		double std = sqrt(x2_sum/pixels_in_object - mean*mean);

		for(Set *aux = Sext; aux != NULL; aux = aux->next)
		{
			p = aux->elem;

			if(fabs(obj->val[p] - mean) <= 3*std)
//			if(obj->val[p]  >= mean  && obj->val[p] <= mean + 3*std)
			{
				misclass_bkg_pixels++;
			}

			nbkg_pixels++;
		}
	}

    return (misclass_bkg_pixels / MAX(nbkg_pixels,1.0) >= thresh);
}

Set *get_new_klt_internal_seeds(KLT_FeatureList fl, int width, int height)
{
    Set *S=NULL;
    int j,p;


    for (j = 0; j < fl->nFeatures; j++)
    {
        if (fl->feature[j]->val == KLT_TRACKED)
        {
            if ( (fl->feature[j]->x >= 0) &&
                    (fl->feature[j]->y >= 0) &&
                    (fl->feature[j]->x < width) &&
                    (fl->feature[j]->y < height) )
            {
                int y = (int)fl->feature[j]->y;
                int x = (int)fl->feature[j]->x;
                p = y * width + x;

                InsertSet(&S, p);
            }
        }
    }

    return S;
}

Set * UpdateSets (int xmin, int ymin, Set *Si, int width1, int height1, int width2, int height2, int border_size, FILE *fdebug)
{
    Set *S=NULL, *aux = Si;
    int elem = NIL;

    while (aux != NULL)
    {
        elem = aux->elem;

        int col = elem % width1;
        int row = elem / width1;

        col += (xmin);
        row += (ymin);

        if (row >= 0 && row < height2 && col >= 0 && col < width2)
        {
            elem = row * width2 + col;

            InsertSet(&S, elem);
        }
        aux = aux->next;
    }
    return S;
}

void TrackFeaturesDim (KLT_TrackingContext tc, int *xmin, int *ymin, int *xmax, int *ymax, int width, int height)
{
    int l = tc->nPyramidLevels - 1;

    int c = tc->subsampling;

    float window_halfwidth = min(tc->window_width,tc->window_height)/2.0f;

    float disp_max = tc->max_iterations*tc->step_factor;

    int disp_end = (int)(((pow(c,l)/(float)(c-1)) * disp_max ) + (pow(c,l) * window_halfwidth));

    if ((*xmin - disp_end) > 0)
    {
        *xmin -= disp_end;
    }
    else
    {
        *xmin = 0;
    }
    if ((*ymin - disp_end) > 0)
    {
        *ymin -= disp_end;
    }
    else
    {
        *ymin = 0;
    }

    if ((*xmax + disp_end) < width)
    {
        *xmax += disp_end;
    }
    else
    {
        *xmax = width;
    }

    if ((*ymax + disp_end) < height)
    {
        *ymax += disp_end;
    }
    else
    {
        *ymax = height;
    }
}

Image *CutImage (Image* img, int xmin, int ymin, int xmax, int ymax)
{
    int x, y, p;
    int ncols = xmax - xmin;
    int nrows = ymax - ymin;
    Image *nimg = CreateImage(ncols, nrows);

    for (y = ymin, p = 0; y < ymax; y++)
    {
        for (x = xmin; x < xmax; x++, p++)
        {
            nimg->val[p] = img->val[x + img->tbrow[y]];
        }
    }
    return nimg;
}

/* This function computes a maximum bounding box that includes the object label
   (e.g a bounding box that includes all pixel values of {label} image that are different
   than zero. The limits of the bounding box are given by {xmin, ymin, xmax, ymax}. */
void BoundingBox (Image *label, int *xmin, int *ymin, int *xmax, int *ymax)
{
    int n, p;

    n = label->ncols * label->nrows;

    *xmin = label->ncols;
    *ymin = label->nrows;
    *xmax = *ymax = 0;
    for (p = 0; p < n; p++)
    {
        if (label->val[p] > 0)
        {

            int x = p % label->ncols;
            int y = p / label->ncols;

            if (x < *xmin)
            {
                *xmin = x;
            }
            else if (x > *xmax)
            {
                *xmax = x;
            }

            if (y < *ymin)
            {
                *ymin = y;
            }
            else if (y > *ymax)
            {
                *ymax = y;
            }
        }
    }
}

Set * GetErodeObjSet (Image* label, float erosion_size)
{
    int n, p;
    Set *ESobj = NULL;
    AdjRel *Adj = NULL;
    Adj = Circular(erosion_size);
    Image *Eobj = Erode (label, Adj);

    n = label->ncols*label->nrows;

    for(p=0; p<n; p++)
    {
        if(Eobj->val[p] > 0)
        {
            InsertSet(&ESobj, p);
        }
    }

    DestroyAdjRel(&Adj);
    DestroyImage(&(Eobj));
    return ESobj;
}

Set * GetBkgSet (
    Image* label,
    int xmin,
    int ymin,
    int xmax,
    int ymax,
    int dilation_size,
    FILE *clock,
    iftrace_options_t ioptions )
{
    SetCPUTime(&ioptions->CPUstart);

    int i, p, q;

    Set *Sbkg = NULL;

    AdjRel *Adj = NULL;

    Adj = Circular (dilation_size);

    Image *tlabel = CutImage (label, xmin, ymin, xmax, ymax);

    Image *Dobj = Dilate (tlabel, Adj);

    Pixel u, v;

    AdjRel *N = NULL;
    N = Circular(1.0);
    for (u.y=0; u.y < tlabel->nrows; u.y++)
    {
        for (u.x=0; u.x < tlabel->ncols; u.x++)
        {
            p = u.x + tlabel->tbrow[u.y];
            for (i = 1; i < N->n; i++)
            {
                v.x = u.x + N->dx[i];
                v.y = u.y + N->dy[i];
                if ( ValidPixel(tlabel, v.x, v.y) )
                {
                    q = v.x + tlabel->tbrow[v.y];
                    if (Dobj->val[p] < Dobj->val[q])
                    {
                        int vv = (u.x + xmin) + (u.y + ymin)*label->ncols;
                        InsertSet(&Sbkg, vv);
                        break;
                    }
                }
            }
        }
    }
    DestroyAdjRel(&N);
    DestroyAdjRel(&Adj);
    DestroyImage(&(Dobj));
    DestroyImage(&(tlabel));
    SetCPUTime(&ioptions->CPUend);
	WriteClockExecution (clock, "GetBkgSet............", ioptions->CPUstart, ioptions->CPUend, &ioptions->total_time);
    return Sbkg;
}

Set * GetPtCloudObjSet (
    Image* label,
    int xmin,
    int ymin,
    int xmax,
    int ymax,
    float erosion_size,
    int spacing,
    FILE *clock,
    iftrace_options_t ioptions )
{
    SetCPUTime(&ioptions->CPUstart);

    int p;

    Set *Sobj = NULL;

    AdjRel *Adj = NULL;

    Adj = Circular (erosion_size);

    Image *tlabel = CutImage (label, xmin, ymin, xmax, ymax);

    if (ioptions->write_tmp_images)
    {
        WritePGM (tlabel, ioptions->frame_path, "tlabel", 99);
    }

    Image *Dobj = Erode (tlabel, Adj);

    Pixel u;

    AdjRel *N = NULL;
    N = Circular(1.0);

    for (u.y=0; u.y < tlabel->nrows; u.y+=spacing)
    {
        for (u.x=0; u.x < tlabel->ncols; u.x += spacing)
        {
            p = u.x + tlabel->tbrow[u.y];
            if(Dobj->val[p] > 0)
            {
                int uu = (u.x + xmin) + (u.y + ymin)*label->ncols;
                InsertSet(&Sobj, uu);
            }
        }
    }
    DestroyAdjRel(&N);
    DestroyAdjRel(&Adj);
    DestroyImage(&(Dobj));
    DestroyImage(&(tlabel));
    SetCPUTime(&ioptions->CPUend);
    WriteClockExecution (clock, "GetPtCloudObjSet............", ioptions->CPUstart, ioptions->CPUend, &ioptions->total_time);
    return Sobj;
}

void GetMeanDispSObj (int *mean_x, int *mean_y, int ncols, int nrows, KLT_FeatureList featurelist_act, KLT_FeatureList featurelist_prev, FILE *fdebug)
{
    int i;

    float tmean_x = 0.0, tmean_y = 0.0;

    int npoints = 0;

    for (i = 0; i < featurelist_act->nFeatures; i++)
    {
        if (featurelist_act->feature[i]->val == KLT_TRACKED)
        {
            if ( (featurelist_act->feature[i]->x >= 0) &&
                    (featurelist_act->feature[i]->y >= 0) &&
                    (featurelist_act->feature[i]->x < ncols) &&
                    (featurelist_act->feature[i]->y < nrows)
               )
            {
                float disp_x = (featurelist_act->feature[i]->x - featurelist_prev->feature[i]->x);
                float disp_y = (featurelist_act->feature[i]->y - featurelist_prev->feature[i]->y);
                tmean_x += disp_x;
                tmean_y += disp_y;
                npoints++;
            }
        }
    }
    fprintf(fdebug, "sum_mean_x : %f, sum_mean_y : %f, npoints = %d\n", tmean_x, tmean_y, npoints);

    if (npoints != 0)
    {
        *mean_x = (int)(tmean_x / (float)npoints);
        *mean_y = (int)(tmean_y / (float)npoints);
    }
    else
    {
        *mean_x = 0;
        *mean_y = 0;
    }
    fprintf(fdebug, "mean_x : %d, mean_y : %d, npoints = %d\n", *mean_x, *mean_y, npoints);
}



void UpdateSetDisp (Set **S, int mean_x, int mean_y, int ncols, int nrows, FILE *fclock, FILE *fdebug, iftrace_options_t ioptions)
{
    SetCPUTime(&ioptions->CPUstart);

    int elem = NIL;

    Set *newS = NULL;
    Set *aux = *S;
    while (aux != NULL)
    {
        elem = aux->elem;
        int col = elem % ncols;
        int row = elem / ncols;
        col += mean_x;
        row += mean_y;

        if ( row >= 0 && row < nrows && col >=0 && col < ncols )
        {
			elem = row * ncols + col;

			InsertSet(&newS, elem);
        }

		aux = aux->next;
    }

    DestroySet(S);

    *S = newS;

    //fprintf(stdout, "fim do UpdateBkgSet\n");
    SetCPUTime(&ioptions->CPUend);
    WriteClockExecution (fclock, "UpdateSetDisp.........", ioptions->CPUstart, ioptions->CPUend, &ioptions->total_time);
}


FILE * OpenFile (const char *path, const char *name)
{
    FILE *file;
    char *tname = NULL;
    asprintf(&tname, "%s/%s", path, name);
    file = fopen(tname, "w");
    free(tname);
    return file;
}

void CloseFile (FILE *file)
{
    fclose (file);
}

void  WriteFeatPPM (Image *img, KLT_FeatureList featurelist, const char *dir, const char *name, int region)
{
    char *tname = NULL;
    asprintf(&tname, "%s/%s_%02d.ppm", dir, name, region);
    KLTWriteFeatureListToPPM(featurelist, img, tname);
    free(tname);
}

void CopyKLTFeatures (KLT_FeatureList featurelist_target, KLT_FeatureList featurelist_source)
{
    int i;

    featurelist_target->nFeatures = featurelist_source->nFeatures;

    for (i = 0; i < featurelist_source->nFeatures; i++)
    {
        featurelist_target->feature[i]->x   = featurelist_source->feature[i]->x;
        featurelist_target->feature[i]->y   = featurelist_source->feature[i]->y;
        featurelist_target->feature[i]->val = featurelist_source->feature[i]->val;
    }
}

void DrawFeatures (Set *Si, Set *Se, Image* lb, Image* mk)
{
    Set* l = NULL;
    l = Si;

    while(l != NULL)
    {
        lb->val[l->elem] = 1;
        mk->val[l->elem] = 1;
        l = l->next;
    }
    l = Se;
    while(l != NULL)
    {
        lb->val[l->elem] = 0;
        mk->val[l->elem] = 2;
        l = l->next;
    }
}

void CreateDirectory (const char *path)
{
#ifdef WRITE_IMAGES_DEBUG
    fprintf(stderr, "creating directory: %s ...\n", path);
#endif
    mkdir(path, 0777);
#ifdef WRITE_IMAGES_DEBUG
    fprintf(stderr, "directory is done!\n");
#endif
}

char * CreateSubDirectory (const char *path, int frame)
{
    char *name = NULL;
    asprintf(&name, "%s/%05d", path, frame);
    CreateDirectory (name);
    return name;
}


records_t createRecords (int nrecords)
{
    records_t r = (records_t)calloc(1,sizeof(struct _records_t));

    r->pos = 0;

    r->nrecords = nrecords;

    r->framedata = (framedata_t *)calloc(nrecords, sizeof(framedata_t));

    int i;
    for (i = 0; i < nrecords; i++)
    {
        r->framedata[i] = (framedata_t)calloc(1,sizeof(struct _framedata_t));
        r->framedata[i]->isempty = TRUE;
        r->framedata[i]->cimg = NULL;
        r->framedata[i]->regions = NULL;
    }

    return r;
}


void destroyRecords (records_t *r)
{
    int i, j;
    for (i = 0; i < (*r)->nrecords; i++)
    {
		if((*r)->framedata[i]->regions != NULL)
		{
			for(j = 0; j < (*r)->framedata[i]->nregions; j++)
			{
				DestroySet(&(*r)->framedata[i]->regions[j]->Si);
				DestroySet(&(*r)->framedata[i]->regions[j]->Se);
				DestroySubgraph(&(*r)->framedata[i]->regions[j]->Sg);
				DestroySubgraph(&(*r)->framedata[i]->regions[j]->Sg2);
				DestroyImage(&(*r)->framedata[i]->regions[j]->label);

				free((*r)->framedata[i]->regions[j]);
			}

			free((*r)->framedata[i]->regions);
		}
		DestroyCImage(&(*r)->framedata[i]->cimg);
		free((*r)->framedata[i]);
    }

	free((*r)->framedata);
	free(*r);
}

void updateRegion (region_t r, Subgraph *Sg, Subgraph* Sg2, Set *Si, Set *Se, Image *label, int isTrackingOk, FILE *fclock, FILE *fdebug, iftrace_options_t ioptions)
{
    SetCPUTime(&ioptions->CPUstart);

    if (r->Sg == NULL)
    {
        r->Sg = CopySubgraph(Sg);
    }
    else
    {
        DestroySubgraph(&(r->Sg));
        r->Sg = CopySubgraph(Sg);
    }

    if (r->Sg2 == NULL)
    {
        r->Sg2 = CopySubgraph(Sg2);
    }
    else
    {
        DestroySubgraph(&(r->Sg2));
        r->Sg2 = CopySubgraph(Sg2);
    }

    if (r->Si == NULL)
    {
        r->Si = CloneSet(Si);
    }
    else
    {
        DestroySet(&(r->Si));
        r->Si = CloneSet(Si);
    }

    if (r->Se == NULL)
    {
        r->Se = CloneSet(Se);
    }
    else
    {
        DestroySet(&(r->Se));
        r->Se = CloneSet(Se);
    }

    if (r->label == NULL)
    {
        r->label = CopyImage(label);
    }
    else
    {
        DestroyImage(&(r->label));
        r->label = CopyImage(label);
    }

    r->isTrackingOk = isTrackingOk;

    SetCPUTime(&ioptions->CPUend);
    WriteClockExecution (fclock, "updateRegion.........", ioptions->CPUstart, ioptions->CPUend, &ioptions->total_time);

}

void updateVisitedFrameRegion (records_t r, int region, FILE *fclock, FILE *fdebug, iftrace_options_t ioptions)
{

    SetCPUTime(&ioptions->CPUstart);

    int pos = r->pos % r->nrecords;

    int prev = pos - 1;
    if (prev < 0)
    {
        prev = r->nrecords - 1;
    }

    if (!r->framedata[prev]->isempty)
    {
        r->framedata[prev]->regions[region]->visited = FALSE;
    }
    r->framedata[pos]->regions[region]->visited = TRUE;

    fprintf(fdebug, "Printing visited graph region values: \n");
    for (int i = 0; i < r->nrecords; i++)
    {
        if (!r->framedata[i]->isempty)
        {
            fprintf(fdebug, "ind : %d -> %d\n", i, r->framedata[i]->regions[region]->visited);
        }
    }
    fprintf(fdebug, "End printing!\n");

    SetCPUTime(&ioptions->CPUend);

    WriteClockExecution (fclock, "updateVisitedFrameRegion.", ioptions->CPUstart, ioptions->CPUend, &ioptions->total_time);
}

int updateFrameData (records_t r, CImage *cimg, int nregions, FILE *fclock, FILE *fdebug, iftrace_options_t ioptions)
{

    SetCPUTime(&ioptions->CPUstart);

    int pos = r->pos % r->nrecords;

    if (r->framedata[pos]->isempty)
    {

        r->framedata[pos]->nregions = nregions;

        r->framedata[pos]->cimg = CopyCImage(cimg);

        r->framedata[pos]->regions = (region_t *)calloc(nregions, sizeof(region_t));

        int i;
        for (i = 0; i < nregions; i++)
        {
            r->framedata[pos]->regions[i] = (region_t)calloc(1,sizeof(struct _region_t));
            r->framedata[pos]->regions[i]->visited = FALSE;
            r->framedata[pos]->regions[i]->Si = NULL;
            r->framedata[pos]->regions[i]->Se = NULL;
            r->framedata[pos]->regions[i]->Sg = NULL;
            r->framedata[pos]->regions[i]->Sg2 = NULL;
            r->framedata[pos]->regions[i]->label = NULL;
            r->framedata[pos]->regions[i]->isTrackingOk = FALSE;
        }

        r->framedata[pos]->isempty = FALSE;
    }
    else
    {
        DestroyCImage(&(r->framedata[pos]->cimg));
        r->framedata[pos]->cimg = CopyCImage(cimg);
    }

    SetCPUTime(&ioptions->CPUend);
    WriteClockExecution (fclock, "updateFrameData......", ioptions->CPUstart, ioptions->CPUend, &ioptions->total_time);

    return pos;
}

Set * getTrackingImages (
    int *xmin,
    int *ymin,
    int *xmax,
    int *ymax,
    int save_border, /*pixels*/
    Image *label,
    Image *act,
    Image *nxt,
    Image **cact,
    Image **cnxt,
    KLT_TrackingContext tc,
    iftrace_options_t ioptions)
{
    Set *S = NULL;

    BoundingBox (label, xmin, ymin, xmax, ymax);

    TrackFeaturesDim (tc, xmin, ymin, xmax, ymax, act->ncols, act->nrows);

    *cact = CutImage (act, *xmin, *ymin, *xmax, *ymax);

    Image *clabel = CutImage (label, *xmin, *ymin, *xmax, *ymax);

    *cnxt  = CutImage (nxt, *xmin, *ymin, *xmax, *ymax);

    copy_to_wider_image (cact, save_border, 0);
    copy_to_wider_image (&clabel, save_border, 1);
    copy_to_wider_image (cnxt, save_border, 0);

    *xmin -= save_border;
    *ymin -= save_border;
    *xmax += save_border;
    *ymax += save_border;


    S = GetErodeObjSet (clabel, ioptions->erosion_size);

    DestroyImage(&clabel);

    return S;
}


void write_Si_Se (Set* Si, Set *Se, Image *img, int region)
{
    int elem = NIL;

    while (Si != NULL)
    {
        elem = Si->elem;
        img->val[elem] = region;
        Si = Si->next;
    }

    while (Se != NULL)
    {
        elem = Se->elem;
        img->val[elem] = 255;
        Se = Se->next;
    }
}

void highlight_markers(CImage *cimg, Image *LbMap, Image *MkMap, int markerID, int objColor,
						int bkgColor)
{
    int p,n,lb,color;

    n = LbMap->ncols*LbMap->nrows;

    for (p=0; p<n; p++)
    {
        if (MkMap->val[p]>markerID)
        {
            lb = LbMap->val[p];
            if (lb>0)
                color = objColor;
            else
				color = bkgColor;

            cimg->C[0]->val[p] = t0(color);
            cimg->C[1]->val[p] = t1(color);
            cimg->C[2]->val[p] = t2(color);
        }
    }
}

void refreshImages (
	CImage *frame_cur,
	Image *label,
    Set *Si, Set *Se,
    int xmin,
    int ymin,
    int xmax,
    int ymax,
    int region,
    const char *frame_path,
    FILE *fclock, FILE *fdebug,
    iftrace_options_t ioptions )
{
    SetCPUTime(&ioptions->CPUstart);

    Image* lb = CreateImage(label->ncols, label->nrows);
    Image* mk = CreateImage(label->ncols, label->nrows);

    DrawFeatures (Si, Se, lb, mk);

    CImage* cimg_seg = CopyCImage(frame_cur);

	highlight_markers(cimg_seg, lb, mk, 0, ioptions->objColor, ioptions->bkgColor);

    WritePPM(cimg_seg, frame_path, "markers", region);

    CImage* cimg_final = CWideHighlight(cimg_seg, label, 1, ioptions->objColor, true);

    highlight_markers(cimg_final, lb, mk, 0, ioptions->objColor, ioptions->bkgColor);

    CImage* cimg_label = CWideHighlight(frame_cur, label, 1, ioptions->objColor, true);

    if (ioptions->write_tmp_images)
    {
        WritePPM (cimg_final, frame_path, "seg", region);
        WritePPM(cimg_label, frame_path, "seg_label",region);
    }


    DestroyCImage(&(cimg_final));
    DestroyCImage(&(cimg_label));
    DestroyCImage(&(cimg_seg));

    SetCPUTime(&ioptions->CPUend);
    WriteClockExecution (fclock, "Refresh..............", ioptions->CPUstart, ioptions->CPUend, &ioptions->total_time);
}




Set * get_list_from_klt (KLT_FeatureList list, int xmin, int ymin, int width)
{
    int i;
    Set *S = NULL;

    for (i = 0; i < list->nFeatures; i++)
    {
        if (list->feature[i]->val > 0)
        {
            InsertSet(&S, ((list->feature[i]->y + ymin) * width + (list->feature[i]->x + xmin)) );
        }
    }

    return S;
}

void CopyLabels (Image *source, Image *target, int label)
{
    int n, p;

    n = source->ncols * source->nrows;

    for(p = 0; p < n; p++)
    {
        if(target->val[p] > 0)
        {
            source->val[p] = label;
        }
    }
}


Image * getComponentRegion (Image* img, int component, int *isLost, FILE *fclock, FILE *fdebug, iftrace_options_t ioptions)
{
    SetCPUTime(&ioptions->CPUstart);
    int n, p;
    Image *out = CreateImage(img->ncols, img->nrows);

    n = img->ncols * img->nrows;

    for(p = 0; p < n; p++)
    {
        if(img->val[p] == component)
        {
            out->val[p] = 1;
            *isLost = FALSE;
        }
        else
        {
            out->val[p] = 0;
        }
    }

    SetCPUTime(&ioptions->CPUend);
    WriteClockExecution (fclock, "getComponentRegion...", ioptions->CPUstart, ioptions->CPUend, &ioptions->total_time);

    return out;
}

Set * getSetComponentRegion (Image* img, int component)
{
    int n, p;
    Set *S = NULL;

    n = img->ncols * img->nrows;

    for(p = 0; p < n; p++)
    {
        if(img->val[p] == component)
        {
            InsertSet(&S, p);
        }
    }

    return S;
}

Set * getExternalComponentRegion (Set* S, int width, int height, int component, char *frame_path, iftrace_options_t ioptions)
{
    int elem = NIL;

    Image* img = CreateImage(width, height);
    SetImage(img, 0);

    while (S != NULL)
    {
        elem = S->elem;
        img->val[elem] = 1;
        S = S->next;
    }

    int dilation_size = 4;

    Set *Se = NULL;

    Se = GetBkgSet (img, 0, 0, width, height, dilation_size, NULL, ioptions);

    //WritePGM (img, frame_path, "comp", component);
    DestroyImage(&img);
    return Se;
}


Image * Binarize (Image *img, int value)
{
    int p = img->ncols*img->nrows;

    Image *out = CreateImage(img->ncols, img->nrows);

    int i;
    for (i = 0; i < p; i++)
    {
        if (img->val[i] > value)
        {
            out->val[i] = 1;
        }
        else
        {
            out->val[i] = 0;
        }
    }

    return out;
}

void changeImageInterval (Image *img, int min, int max)
{
    int Imin = MinimumValue(img);
    int Imax = MaximumValue(img);

    int n = img->ncols*img->nrows;

    int p;
    for (p = 0; p < n; p++)
    {
        img->val[p] = ( (max - min)*(img->val[p] - Imin) )/(Imax - Imin) + min;
    }
}

void FuzzyOPFLearning(Features *f, Set *Si, Set *Se, Subgraph** pSgTrainObj, Subgraph** pSgTrainBkg)
{
    Subgraph *sg=NULL,*sgtrain,*sgeval;
    float perc;

    if(f == NULL || Si == NULL || Se == NULL) return;

    sg = SubgraphFromMarkers(f,Si,Se);

    if(sg == NULL) return;

    if (sg->nnodes > 200)
        perc = 200.0/sg->nnodes;
    else
        perc = 0.5;

    SplitSubgraph(sg,&sgtrain,&sgeval,perc);

    MSTPrototypes(sgtrain);

    Subgraph* sgtrainobj = SplitSubgraphByTrueLabel(sgtrain, 1);
    Subgraph* sgtrainbkg = SplitSubgraphByTrueLabel(sgtrain, 0);

    PrecomputedDistance = 0;

    FuzzyLearningCompGraph(&sgtrainobj, &sgtrainbkg, &sgeval, 5);

    DestroySubgraph(&sgeval);
    DestroySubgraph(&sgtrain);
    DestroySubgraph(&sg);

    *pSgTrainObj = sgtrainobj;
    *pSgTrainBkg = sgtrainbkg;
}


void ComputeFuzzyClassifier (CImage *cimg, Set *Si, Set *Se, Subgraph** Sg, Subgraph** Sg2,
							FILE *fclock, FILE *fdebug,
							iftrace_options_t ioptions )
{
    SetCPUTime(&ioptions->CPUstart);

    *Sg2 = NULL;

    Features *rgb_smoothed = LMSCImageFeats(cimg,1);
    Features *f = LabFeats(rgb_smoothed);
    DestroyFeatures(&rgb_smoothed);

    FuzzyOPFLearning(f, Si, Se, Sg, Sg2);

    SetCPUTime(&ioptions->CPUend);

    WriteClockExecution (fclock, "Get Subgraph...........", ioptions->CPUstart, ioptions->CPUend, &ioptions->total_time);
}


void Maps (
    Subgraph *Sg,
    Subgraph *Sg2,
    CImage *cimg,
    Image **objMap,
    Features **f,
    int xmin,
    int ymin,
    int xmax,
    int ymax,
    FILE *fclock,
    FILE *fdebug,
    iftrace_options_t ioptions
)
{
    SetCPUTime(&ioptions->CPUstart);

    Features *rgb_smoothed = LMSCImageFeats(cimg,1);
    *f = LabFeats(rgb_smoothed);

    DestroyFeatures(&rgb_smoothed);

	if(Sg != NULL && Sg2 != NULL)
	{
		*objMap = TFOPFMembershipMapSSEBB(Sg, Sg2, *f, 4, xmin, ymin, xmax, ymax);
	}
	else
	{
		*objMap = CreateImage(cimg->C[0]->ncols, cimg->C[0]->nrows);
	}

    SetCPUTime(&ioptions->CPUend);

    WriteClockExecution (fclock, "Maps.................", ioptions->CPUstart, ioptions->CPUend, &ioptions->total_time);

    if (ioptions->frame_path != NULL)
    {

        CImage *ctmp = CopyCImage(cimg);

        DrawCImageLineDDA (ctmp, xmin, ymin, xmax, ymin, 200);
        DrawCImageLineDDA (ctmp, xmin, ymin, xmin, ymax, 200);
        DrawCImageLineDDA (ctmp, xmin, ymax, xmax, ymax, 200);
        DrawCImageLineDDA (ctmp, xmax, ymin, xmax, ymax, 200);

        if (ioptions->write_tmp_images)
        {
			char *framename = NULL;

			asprintf(&framename, "%s/%s.pgm", ioptions->frame_path, "cut");

            WriteCImage(ctmp, framename);
			free(framename);
        }

        DestroyCImage (&ctmp);
    }

}


void Segmentation (
	Image *pred,
	Image *cost,
	Image *root,
	Image *objMap,
	Features *feat,
    Image **label,
    Set *Si,
    Set *Se,
    int xmin,
    int ymin,
    int xmax,
    int ymax,
    FILE *fclock,
    FILE *fdebug,
    iftrace_options_t ioptions
)
{
    SetCPUTime(&ioptions->CPUstart);

	SetImage(pred, NIL);
	SetImage(cost, INT_MAX);
	SetImage(*label, 0);

    DiffIFTBB(*label, cost, pred, root, objMap, feat, ioptions->diftradius, Si, Se, NULL, ioptions->Wobj, xmin, ymin, xmax, ymax);

    SetCPUTime(&ioptions->CPUend);

    WriteClockExecution (fclock, "Segmentation.........", ioptions->CPUstart, ioptions->CPUend, &ioptions->total_time);
}

int verifySegmentation (Image *label, records_t r, int region, FILE *fclock, FILE *fdebug, iftrace_options_t ioptions)
{
    int newest = -1;

    for (int i = 0; i < r->nrecords; i++)
    {
        if (!r->framedata[i]->isempty)
        {
            if (r->framedata[i]->regions[region]->visited)
            {
                newest = i;
            }
        }
    }

    if (newest != -1)
    {
		double distance = DBL_MAX;
		Image *ilabel = r->framedata[newest]->regions[region]->label;

		if(MaximumValue(label) > 0 && MaximumValue(ilabel) > 0)
		{
			FeatureVector1D *f1 = compute_features (label);

			FeatureVector1D *f2 = compute_features (ilabel);

			distance = EuclideanDistance(f1, f2);

			DestroyFeatureVector1D(&f1);

			DestroyFeatureVector1D(&f2);
		}

        if (distance > ioptions->momentInvThreshold)
        {
            return FALSE;
        }
        else
        {
            return TRUE;
        }
    }
    else
    {
        return TRUE;
    }
}

int recoverObject (
    records_t r,
    int posframe,
	Image *pred,
	Image *cost,
	Image *root,
	Image *objMap,
    Image *iregions,
    int posregion,
    FILE *fclock,
    FILE *fdebug,
    iftrace_options_t ioptions
)
{
    SetCPUTime(&ioptions->CPUstart);

    fprintf(fdebug, "Function: recoverObject\n");

    /*Testing the last subgraphs if they exist to find the occluded object*/

    int nprototypes = r->nrecords;

    int *prototypes = (int *)malloc(nprototypes * sizeof(int));

    /*Trying to find the last subgraph updated before the occlusion*/

    int newest = NIL;

    for (int i = 0; i < r->nrecords; i++)
    {
        if (!r->framedata[i]->isempty)
        {
            if (r->framedata[i]->regions[posregion]->visited)
            {
                newest = i;
            }
        }
    }
    fprintf(fdebug, "Newest element : %d\n", newest);

    /*Looking for the {nprototypes} valid (stored in {prototypes}) in the record structure if they exist*/

    int ntries = 0;

    if (newest != NIL)
    {
		int prev = newest - 1;

		// In case the object is lost on the second frame F^2,
		// IFTrace should use the first frame's data (F^1)
		// during object recovery on F^2. Otherwise, since r is a
		// circular buffer we let it go back to the previous F^k,
		// where k = r->nrecords-1.
		if(newest == 0 && r->framedata[r->nrecords-1]->isempty)
		{
			prototypes[ntries++] = newest;
		}
		else
		{
			for (int i = ntries; i < nprototypes; i++)
			{
				if (prev < 0)
				{
					prev = r->nrecords - 1;
				}

				if (!r->framedata[prev]->isempty)
				{
					prototypes[ntries++] = prev;
					prev--;
				}
			}
		}
    }

    for (int t = 0; t < ntries; t++)
    {

        int pgraph = prototypes[t];

        fprintf(fdebug, "Using graph and label image from position : %d\n", pgraph);

        /*Getting the image video frame in order to find the object*/

        CImage *cimg = r->framedata[posframe]->cimg;

        Image *lsObjMap = NULL;
        Features *feat = NULL;

        /*Getting the subgraph and image label of a previous frame of the desired object*/
        Subgraph *Sg = NULL, *Sg2 = NULL;

        Sg = CopySubgraph(r->framedata[pgraph]->regions[posregion]->Sg);

        if(r->framedata[pgraph]->regions[posregion]->Sg2 != NULL)
            Sg2 = CopySubgraph(r->framedata[pgraph]->regions[posregion]->Sg2);

        Image *ilabel = r->framedata[pgraph]->regions[posregion]->label;

        if (Sg == NULL || Sg2 == NULL)
        {
            DestroySubgraph(&Sg);
            DestroySubgraph(&Sg2);
        }
        else
        {
			/*Creating the object and background map of the new image {cimg} according a given subgraph {Sg} (trained to a desired object).*/
			Maps (Sg, Sg2, cimg, &lsObjMap, &feat, 0, 0, cimg->C[0]->ncols,
					cimg->C[0]->nrows, fclock, fdebug, ioptions);

			CopyImageInplace(objMap, lsObjMap);

			/*Binarizing the object map. Only the brighter components (acording the subgraph {Sg}) are kept.*/
			Image *ibin = Binarize (lsObjMap, ioptions->recoveryThreshold*MAXDENS);

			/*Removing small components to save computational time*/
			AdjRel *A = NULL;

			A = Circular (3.0);

			Image *ebin = Open(ibin, A);

			DestroyAdjRel(&A);

			/*Labeling all the remaining regions (considering 8-neighborhood)*/

			AdjRel *B = NULL;

			B = Circular (1.5);

			int nregions;

			Image *labels = Labeling (ebin, B, &nregions);

			DestroyAdjRel(&B);

			/*For each probable object region, do*/
			for (int region = 1; region < nregions; region++)
			{

				/*Transforming the object region in sets of seeds {Si, Se}*/

				Set *Si = NULL;

				Si = getSetComponentRegion (labels, region);

				Set *Se = NULL;

				Se = getExternalComponentRegion (Si, pred->ncols, pred->nrows, region, ioptions->frame_path, ioptions);

				/*Performing the segmentation in the region*/

				Image *label = CreateImage(pred->ncols, pred->nrows);

				Segmentation (pred, cost, root, lsObjMap, feat, &label, Si, Se, 0, 0, cimg->C[0]->ncols, cimg->C[0]->nrows, fclock, fdebug, ioptions);

				/*Computing feature descriptors over the found region*/
				double distance = DBL_MAX;

				if(MaximumValue(label) > 0 && MaximumValue(ilabel) > 0)
				{
					FeatureVector1D *f1 = compute_features (ilabel);
					FeatureVector1D *f2 = compute_features (label);

					/*Computing the distance between the previous image labels of the desired object and the found region*/

					distance = EuclideanDistance(f1, f2);

					DestroyFeatureVector1D(&f1);
					DestroyFeatureVector1D(&f2);
				}

				fprintf(fdebug, "Distance between %d and %d (try : %d) is %f.\n", pgraph, region, t, distance);


				/*Writing the label and segmentation results*/

				CImage *tlbl = CWideHighlight(cimg, label, 1, ioptions->objColor, true);

				char *sname = NULL;

				asprintf(&sname, "recovery_seg_color_try_%02d", t);

				if (ioptions->write_tmp_images)
				{
					WritePPM (tlbl, ioptions->frame_path, sname, region);
				}

				free(sname);

				char *lname = NULL;

				asprintf(&lname, "recovery_seg_lab_try_%02d", t);

				if (ioptions->write_tmp_images)
				{
					WritePGM (label, ioptions->frame_path, lname, region);
				}

				free(lname);

				DestroyCImage(&tlbl);

				/*If the distance is small then probably the object found is the same one that was lost*/

				if (distance <= ioptions->momentInvThreshold)
				{
					/*Copy this object in the {iregions} image with the same label of the one that was lost and return to the main procedure*/
					CopyLabels (iregions, label, posregion);

					DestroyImage(&label);

					DestroySet(&(Si));

					DestroySet(&(Se));

					SetCPUTime(&ioptions->CPUend);

					WriteClockExecution (fclock, "Recover..............", ioptions->CPUstart, ioptions->CPUend, &ioptions->total_time);

					fprintf(fdebug, "The region : %d (try : %d) is very closed to the object %d (distance : %f).\n", region, t, posregion, distance);

					return TRUE;
				}

				/*Destroying images and structures*/

				DestroyImage(&label);

				DestroySet(&(Si));

				DestroySet(&(Se));

			}

			/*Writing debugging recovery images*/

			if (ioptions->write_tmp_images)
			{
				WritePGM (ibin, ioptions->frame_path, "recovery_ibin_try", t);
				WritePGM (ebin, ioptions->frame_path, "recovery_ebin_try", t);
				WritePGM (labels, ioptions->frame_path, "recovery_labels_try", t);
				WritePGM (ilabel, ioptions->frame_path, "recovery_ilabels_try", t);
				WritePGM (lsObjMap, ioptions->frame_path, "recovery_objmap_try", t);
			}

			/*Destroying images and structures*/

			DestroyImage(&lsObjMap);
			DestroyFeatures(&feat);

			DestroyImage(&ibin);

			DestroyImage(&ebin);

			DestroyImage(&labels);

			DestroySubgraph(&Sg);
			DestroySubgraph(&Sg2);
        }
    }

    SetCPUTime(&ioptions->CPUend);

    WriteClockExecution (fclock, "Recover..............", ioptions->CPUstart, ioptions->CPUend, &ioptions->total_time);

    free(prototypes);

    fprintf(fdebug, "No similar object found.\n");

    fprintf(fdebug, "End recoverObject function\n\n\n");

	return FALSE;
}

Set* Tracking (
    Image *img1,
    Image *img2,
    Image *label,
    int *mean_disp_x,
    int *mean_disp_y,
    KLT_TrackingContext tc,
    int region,
    FILE *fclock,
    FILE *fdebug,
    iftrace_options_t ioptions,
    int *isTrackingOk,
    int *xmin,
    int *ymin,
    int *xmax,
    int *ymax,
    Image *seeds_before_klt,
    Image *seeds_after_klt

)
{
    SetCPUTime(&ioptions->CPUstart);

    Set *S = NULL, *Si = NULL, *Send = NULL;

    Image *timg1, *timg2;

    int border_size = 30, selectedFeatures, trackedFeatures;

    S = getTrackingImages (xmin, ymin, xmax, ymax, border_size, label,
							img1, img2, &timg1, &timg2, tc, ioptions);

    int cols_a = timg1->ncols;
    int rows_a = timg1->nrows;
    int cols_b = timg2->ncols;
    int rows_b = timg2->nrows;

    assert(cols_a == cols_b);
    assert(rows_a == rows_b);

    KLT_FeatureList featurelist_img1 = KLTCreateFeatureList(ioptions->nFeatures);

    KLT_FeatureList featurelist_img2 = KLTCreateFeatureList(ioptions->nFeatures);

    KLTSelectGoodFeatures (tc, timg1, S, cols_a, rows_a, featurelist_img2);

    Set *Sini = get_list_from_klt (featurelist_img2, *xmin, *ymin, seeds_before_klt->ncols);

    write_Si_Se (Sini, NULL, seeds_before_klt, region);


    selectedFeatures = KLTCountRemainingFeatures(featurelist_img2);

    if (ioptions->write_tmp_images)
    {
        WriteFeatPPM (timg1, featurelist_img2, ioptions->frame_path, "feat1", region);
    }

    CopyKLTFeatures (featurelist_img1, featurelist_img2);

    KLTTrackFeatures (tc, timg1, timg2, cols_a, rows_a, featurelist_img2);

    trackedFeatures = KLTCountRemainingFeatures(featurelist_img2);

    double threshold;

    /*TODO - Strategy to automatic decide this*/
    if (ioptions->isSmallObject)
    {
        threshold = 0.2;
    }
    else
    {
        threshold = ioptions->trackingFailureThreshold;
    }

    if (  ( (double)trackedFeatures / (double)selectedFeatures ) >= threshold  )
    {
        *isTrackingOk = TRUE;
    }
    else
    {
        *isTrackingOk = FALSE;
    }

    if (ioptions->write_tmp_images)
    {
        WriteFeatPPM (timg2, featurelist_img2, ioptions->frame_path, "feat2", region);
    }

    GetMeanDispSObj (mean_disp_x, mean_disp_y, cols_a, rows_a, featurelist_img2, featurelist_img1, fdebug);

	Si = get_new_klt_internal_seeds(featurelist_img2, cols_a, rows_a);

    KLTFreeFeatureList(featurelist_img1);

    KLTFreeFeatureList(featurelist_img2);

    DestroyImage(&(timg1));

    DestroyImage(&(timg2));

    DestroySet(&S);

    Send = UpdateSets (*xmin, *ymin, Si, (*xmax - *xmin), (*ymax - *ymin), img1->ncols, img1->nrows, border_size, stdout);

    write_Si_Se (Send, NULL, seeds_after_klt, region);

    SetCPUTime(&ioptions->CPUend);

    WriteClockExecution (fclock, "Tracking.............", ioptions->CPUstart, ioptions->CPUend, &ioptions->total_time);

    *xmin += border_size;
    *ymin += border_size;
    *xmax -= border_size;
    *ymax -= border_size;

    DestroySet(&Si);
    DestroySet(&Sini);

    return Send;
}


void IFTrace(const char* dirname, iftrace_options_t ioptions,
								CImage *cimg_display, Image *label,
								Image *pred, Image *cost,
								Image *root, Image *objMap,
								void (*gui_refresh)(void*, int, iftrace_options_t),
								void *obj)
{
	int isObjTooSmall = FALSE;
    Set *Si = NULL, *Se = NULL;

    if (label == NULL || MaximumValue(label) == 0)
    {
        return;
    }

	srandom(IFTRACE_RANDOM_SEED);

   /*Reading the first image*/

    CImage *frame_start  =  ReadPPM (dirname, ioptions->start_seq);

	if(frame_start == NULL)
		return;

	CopyCImageInplace(cimg_display, frame_start);

    CImage *ycbcr1 = CImageRGBtoYCbCr(frame_start);

    Image  *img1   = CopyImage(ycbcr1->C[0]);

    DestroyCImage(&(ycbcr1));


    /*Initializations of KLT tracking structure*/
    KLT_TrackingContext tc = KLTCreateTrackingContext();

    KLTPrintTrackingContext(tc);

    /*Creating output directory*/

    const char *output_path = "out";

    CreateDirectory (output_path);

    /*Creating structure to store tracking data informations (seeds, subgraph, label images, ...)*/

    records_t r = createRecords (ioptions->nrecords);

    /*Getting all the regions choosed by the user in {labels} to {iregions}*/

    int nregions;

    AdjRel *Adj = NULL;

    Adj = Circular(1.5);

    Image *iregions = Labeling (label, Adj, &nregions);

    DestroyAdjRel(&Adj);

    if (ioptions->isSmallObject)
    {
        ioptions->erosion_size = 2;
    }

	ioptions->frame_path = CreateSubDirectory (output_path, ioptions->start_seq);

	int pos = updateFrameData (r, frame_start, nregions, stdout, stdout, ioptions);

    /* Training the classifier for each region in the first iteration*/
	for (int region = 1; region < nregions && !isObjTooSmall; region++)
	{
		int isLost = TRUE;
		Subgraph *Sg = NULL, *Sg2 = NULL;

		Image *ilabel = getComponentRegion (iregions, region, &isLost, stdout, stdout, ioptions);

		Si = GetErodeObjSet(ilabel, ioptions->erosion_size);
		Se = GetBkgSet (ilabel, 0, 0, ilabel->ncols, ilabel->nrows,
						ioptions->dilation_size, stdout, ioptions);

		if(!isLost && GetSetSize(Si) > 1 && GetSetSize(Se) > 1)
		{
			ComputeFuzzyClassifier (frame_start, Si, Se, &Sg, &Sg2,
									stdout, stdout, ioptions);

			updateRegion (r->framedata[pos]->regions[region], Sg, Sg2, Si, Se, ilabel,
							TRUE, stdout, stdout, ioptions);

			updateVisitedFrameRegion (r, region, stdout, stdout, ioptions);
		}
		else
		{
			fprintf(stderr,"Object too small to track!!!\n");

			isObjTooSmall = TRUE;
		}

		DestroySet(&Si);
		DestroySet(&Se);
		DestroyImage(&ilabel);
	}

	free(ioptions->frame_path);
	r->pos++;

	if(!isObjTooSmall)
	{
		for (int frame = ioptions->start_seq+1; frame <= (ioptions->start_seq + ioptions->number_of_frames); frame++)
		{
			/*Reading all the images of the input video*/
			CImage* frame_cur = ReadPPM (dirname, frame);

			if(frame_cur == NULL)
			{
				break;
			}

			clock_t CPUstart, CPUend;

			SetCPUTime(&CPUstart);

			/*Creating a sub-directory to each {frame} inside the {output_path} directory*/

			ioptions->frame_path = CreateSubDirectory (output_path, frame);

			const char *frame_path = ioptions->frame_path;

			/*Creating files to store time and debug informations about WaterTrack*/

			FILE *fclock = OpenFile (frame_path, "time.txt");

			FILE *fwindow = OpenFile (frame_path, "window.txt");

			FILE *fdebug = OpenFile (frame_path, "debug.txt");

			CImage *ycbcr2 = CImageRGBtoYCbCr(frame_cur);

			Image  *img2   = CopyImage(ycbcr2->C[0]);

			DestroyCImage(&(ycbcr2));

			/*Displaying the read frame*/
			CopyCImageInplace(cimg_display, frame_cur);

			/*Updating the IFTrace structure with the newly read image*/

			pos = updateFrameData (r, frame_cur, nregions, fclock, fdebug, ioptions);

			ioptions->total_time = 0.0;

			/*Copying only the regions that was successfully tracked in previous iterations or founded after oclusions */

			SetImage(label, 0);

			Image *tregions = CopyImage(iregions);

			SetImage(iregions, 0);

			Image *seeds_before_klt = CreateImage(img2->ncols, img2->nrows);
			SetImage(seeds_before_klt, 0);

			Image *seeds_after_klt = CreateImage(img2->ncols, img2->nrows);
			SetImage(seeds_after_klt, 0);


			/*For each region of {tregions} do */

			for (int region = 1; region < nregions; region++)
			{

				int isLost = TRUE;
				int isTrackingOk = FALSE, xmin, xmax, ymin, ymax;
				int isSegmentationOk = FALSE;

				/*Getting the region component {region} from {tregions}, if it does not exists, islost is set as TRUE*/

				Image *ilabel = getComponentRegion (tregions, region, &isLost, fclock, fdebug, ioptions);

				if (!isLost)
				{
					Image *lsObjMap = NULL;
					Features *feat = NULL;
					/* Getting previous classifier **/
					Subgraph *Sg = NULL, *Sg2 = NULL;

					if (ioptions->write_tmp_images)
					{
						WritePGM (ilabel, frame_path, "ilabel", region);
					}

					/*Selecting and Tracking the features given by {ilabel} from {img1} to {img2}*/

					DestroySet(&Si);

					int mean_disp_x, mean_disp_y;

					Si = Tracking (
							 img1, img2,
							 ilabel,
							 &mean_disp_x, &mean_disp_y,
							 tc,
							 region,
							 fclock, fdebug,
							 ioptions,
							 &isTrackingOk,
							 &xmin, &ymin, &xmax, &ymax,
							 seeds_before_klt,
							 seeds_after_klt);

					if (!isTrackingOk)
					{
						fprintf(stderr, "Tracking failure!\n");
					}

					/*Getting the background seeds from a dilation of {ilabel}*/

					DestroySet(&Se);

					Se = GetBkgSet (ilabel, xmin, ymin, xmax, ymax, ioptions->dilation_size, fclock, ioptions);

					write_Si_Se (NULL, Se, seeds_before_klt, region);
					/*Updating the foreground and background seeds with the mean displacement given by the tracked features*/

					UpdateSetDisp (&Se, mean_disp_x, mean_disp_y, frame_cur->C[0]->ncols,
										frame_cur->C[0]->nrows, fclock, fdebug, ioptions);

					/* Getting the previous classifier */
					int prev = pos - 1;

					if (prev < 0)
					{
						prev = r->nrecords - 1;
					}

					Sg = CopySubgraph(r->framedata[prev]->regions[region]->Sg);
					if(r->framedata[prev]->regions[region]->Sg2 != NULL)
						Sg2 = CopySubgraph(r->framedata[prev]->regions[region]->Sg2);

					/*Computing new object and background maps from the subgraph {Sg} */
					write_Si_Se (NULL, Se, seeds_after_klt, region);

					Maps (Sg, Sg2, frame_cur, &lsObjMap, &feat, xmin, ymin, xmax, ymax, fclock, fdebug, ioptions);

					CopyImageInplace(objMap, lsObjMap);

					if (ioptions->write_tmp_images)
					{
						WritePGM (lsObjMap, ioptions->frame_path, "objMap", region);
					}

					/*Segmenting the desired object given by the tracked seeds {Si, Se} **/

					Segmentation (pred, cost, root, lsObjMap, feat, &ilabel,
								Si, Se, xmin, ymin, xmax, ymax, fclock, fdebug, ioptions);

					isSegmentationOk = verifySegmentation (ilabel, r, region, fclock, fdebug, ioptions);

					/*If the tracking is ok or if at least the resulting
						segmentation resembles the object then we just update
						the structures and copy the tracked region. If both
						the segmentation and tracking failed then we
						activate the recoverObject procedure */
					if (isSegmentationOk || isTrackingOk)
					{
						CopyLabels (label, ilabel, 255);

						CopyLabels (iregions, ilabel, region);

						refreshImages (frame_cur, label, Si, Se, xmin, ymin, xmax, ymax,
											region, frame_path, fclock, fdebug, ioptions);

						fprintf(fwindow, "%d %d %d %d\n", xmin, ymin, xmax, ymax);

						WritePGM (ilabel, frame_path, "label", region);

						int retrain = AssessRetraining(lsObjMap, ilabel, Se,
															ioptions->assessRetrainThreshold);

						// Retraining for the first nrecords helps object recovery
						if ((retrain || frame <= ioptions->start_seq+ioptions->nrecords)
//						if ((retrain)
								&& GetSetSize(Si) > 1 && GetSetSize(Se) > 1)
						{
							DestroySubgraph(&Sg);
							DestroySubgraph(&Sg2);

							ComputeFuzzyClassifier (frame_cur, Si, Se, &Sg, &Sg2,
														fclock, fdebug, ioptions);

						}

						/*Saving the subgraph {Sg}, the seeds {Si, Se} and image label {ilabel} of the region*/

						updateRegion (r->framedata[pos]->regions[region], Sg, Sg2, Si, Se, ilabel, isTrackingOk, fclock, fdebug, ioptions);

						/*Saving this region as the newest in structure vector information*/

						updateVisitedFrameRegion (r, region, fclock, fdebug, ioptions);

					}
					else
					{
						Image *iftracklabel = CreateImage (ilabel->ncols, ilabel->nrows);
						WritePGM (iftracklabel, frame_path, "label", region);
						DestroyImage(&(iftracklabel));
						/*If there are problems in the segmentation process due to tracking errors, bad object maps, etc...*/
						fprintf(stderr, "Segmentation failure!\n");
					}

					DestroySubgraph(&(Sg));
					DestroySubgraph(&(Sg2));
					DestroyFeatures(&feat);
					DestroyImage(&lsObjMap);
				}

				if(isLost || (!isSegmentationOk && !isTrackingOk))
				{
					Image *iftracklabel = CreateImage (ilabel->ncols, ilabel->nrows);
					WritePGM (iftracklabel, frame_path, "label", region);
					DestroyImage(&(iftracklabel));

					/*If the object is lost try to find it in the whole image*/
					fprintf(stderr, "Recovering object %d...\n", region);
					recoverObject (r, pos, pred, cost, root, objMap, iregions, region,
										fclock, fdebug, ioptions);
				}

				/*Writing the {ilabel} image which contains one desired region selected by the user*/
				if (ioptions->write_tmp_images)
				{
					WritePGM (ilabel, frame_path, "ilabel", region);
				}

				DestroyImage(&(ilabel));

			}

			DestroyImage(&(tregions));

			/*Writing the {iregions} image which contains all the desired regions selected by the user*/

			if (ioptions->write_tmp_images)
			{
				WritePGM (iregions, frame_path, "iregions", 99);
			}

			/*Updating {img1} and destroying {img2}*/

			DestroyImage(&(img1));

			img1 = CopyImage(img2);

			DestroyImage(&(img2));

			if (ioptions->write_tmp_images)
			{
				WritePGM (seeds_before_klt, frame_path, "si_se_before", 99);

				WritePGM (seeds_after_klt, frame_path, "si_se_after", 99);
			}

			DestroyImage(&(seeds_before_klt));

			DestroyImage(&(seeds_after_klt));


			/*Updating the interface*/

			SetCPUTime(&CPUend);

			WriteClockExecution (fclock, "Execution time .......", CPUstart, CPUend, &ioptions->total_time);

			if(gui_refresh != NULL && obj != NULL)
			{
				gui_refresh(obj, frame, ioptions);
			}

			/*Closing files, getting time execution, memory allocations and destroying the structures*/

			DestroyCImage(&frame_cur);
			DestroySet(&Si);
			DestroySet(&Se);

			CloseFile (fclock);

			CloseFile (fwindow);

			CloseFile (fdebug);

			free(ioptions->frame_path);

			r->pos++;
		}
	}

	destroyRecords(&r);

	DestroyCImage(&frame_start);
    DestroyImage(&(img1));
    DestroyImage(&iregions);

    KLTFreeTrackingContext(tc);
}



