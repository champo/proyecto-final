#include "iftrace.h"

void display_images(void *obj, int frame, iftrace_options_t ioptions)
{
	char *cmd = NULL;
	system("killall display");

	asprintf(&cmd,"display %s/../%05d/seg_label* &", ioptions->frame_path, frame);
	system(cmd);

	free(cmd);
}

int main(int argc, char **argv)
{
	if(argc < 6)
	{
		fprintf(stderr, "Usage: %s [frame directory] [label file] [first frame id] "
				"[number of frames] [is object small {0,1}] <display image {0,1}> "
				"<Wobj [0.0, 1.0]>\n", argv[0]);
		return -1;
	}

	char *dirname = argv[1];
	int first_frame = atoi(argv[3]), nframes = atoi(argv[4]);
	bool display = false;
	char foo;

	CImage *cimg_display = ReadPPM(argv[1], first_frame);
    Image* label = ReadImage(argv[2]);
	Image* bin_label = NULL;

    if(label->ncols != cimg_display->C[0]->ncols
		|| label->nrows != cimg_display->C[0]->nrows)
	{
		fprintf(stderr,"Images with different dimensions!!\n");

		DestroyImage(&label);
		DestroyCImage(&cimg_display);

		return -1;
	}

    Image* pred = CreateImage(label->ncols, label->nrows);
    Image* cost = CreateImage(label->ncols, label->nrows);
    Image* root = CreateImage(label->ncols, label->nrows);
	Image* objMap = CreateImage(label->ncols, label->nrows);

	bin_label = Threshold(label, 1, INT_MAX);
	DestroyImage(&label);
	label = bin_label;

	iftrace_options_t ioptions = GetIFTraceOptions(first_frame, nframes);

	ioptions->isSmallObject = atoi(argv[5]);

	if(argc >= 7)
		display = (bool)atoi(argv[6]);

	if(argc >= 8)
		ioptions->Wobj = atof(argv[7]);

	if(display)
		IFTrace(dirname, ioptions, cimg_display, label, pred, cost, root, objMap,
				&display_images, &foo);
	else
		IFTrace(dirname, ioptions, cimg_display, label, pred, cost, root, objMap,
				NULL, NULL);

	free(ioptions);

	DestroyImage(&pred);
	DestroyImage(&root);
	DestroyImage(&objMap);
	DestroyImage(&label);
	DestroyCImage(&cimg_display);

	return 0;
}
