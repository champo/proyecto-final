**************************
**** IFTrace software ****
**************************

==== Compilation ====
This Software requires GCC and G++ version 4.3 or higher to compile. It has been implemented and tested exclusively on GNU/Linux.

Type "make" to compile the software.

==== Preparing the videos ====

Obtain our dataset from:

http://www.liv.ic.unicamp.br/~minetto/iftrace/

It includes the ground truths for the videos and some of the video files.

Each video frame should be stored as a PPM image in a separate video folder following the hierarchy below:

<video file name>/frames/%05d/frame.ppm

Example:

v01/frames
v01/frames/00001/frame.ppm
v01/frames/00002/frame.ppm
.
.
.
v01/frames/00100/frame.ppm


There are two scripts included in this package, inside foder util, for transforming a video into images and then storing the frames appropriately for IFTrace. 

==== Running IFTrace ====

Run IFTrace with the following command:

./bin/iftrace-standalone [frame directory] [label file] [first frame id] [number of frames] [is object small {0,1}] <display image {0,1}> <Wobj [0, 1.0]>

Example:

./bin/iftrace-standalone v01/frames v01-label_00001.pgm 1 100 0 1 0.5


The last three parameters indicate, respectively:

1) Value 1 if the object is small (plane and rat videos) (mandatory).
2) Value 1 if the segmentation result should be displayed using the "display" command (optional).
3) The weight to the classification result during segmentation (optional, the default value is 0.5).

*** The results are stored in folder "out." ***

==== Mandatory citation and licensing ====

R. Minetto, T.V. Spina, A.X. Falcão, N.J. Leite, J.P. Papa, J. Stolfi, IFTrace: Video segmentation of deformable objects using the Image Foresting Transform, Computer Vision and Image Understanding, Volume 116, Issue 2, February 2012, Pages 274-291, ISSN 1077-3142, http://dx.doi.org/10.1016/j.cviu.2011.10.003.

See LICENSE.txt for the usage permissions granted by the authors.
