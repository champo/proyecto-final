#ifndef _IFTRACE_H_
#define _IFTRACE_H_

#include <stdio.h>
#include "klt.h"
#include "code_cpp.h"
#include <time.h>
#include <assert.h>
#include <sys/stat.h>
#include <sys/types.h>

// Using static seed to ensure reproducibility
// of OPF's learning algorithm
#define IFTRACE_RANDOM_SEED 13523421
// Uncomment next line to add "true" randomness to OPF's
// learning algorithm
//#define IFTRACE_RANDOM_SEED time(NULL)

#define WRITE_IMAGE_DEBUGS

typedef struct _iftrace_options_t
{
    int nrecords;

    int number_of_frames;
    int nFeatures;
    int start_seq;
    int nscales;
    float Wobj;
    int erosion_size;
    int dilation_size;

    float diftradius;
    int seedspacing;
	float trackingFailureThreshold;
	int momentInvThreshold;
	float assessRetrainThreshold;
	float recoveryThreshold;

    int isSmallObject;

    double total_time;
    clock_t CPUstart;
    clock_t CPUend;

    int write_tmp_images;
	int objColor;
	int bkgColor;

    char *frame_path;

} *iftrace_options_t;

typedef struct _region_t {
    int visited;
    int isTrackingOk;
    Set *Si;
    Set *Se;
    Subgraph *Sg; // For opf Sg stores the object forest
    Subgraph* Sg2;// whereas Sg2 stores the background forest.
                  // For knn only Sg stores something.
    Image *label;
} *region_t;

typedef struct _framedata_t {
   int isempty;
   int nregions;
   CImage *cimg;
   region_t *regions;
} *framedata_t;

typedef struct _records_t {
   int pos;
   int nrecords;
   framedata_t *framedata;
} *records_t;

iftrace_options_t GetIFTraceOptions (int frame0, int framen);

void IFTrace(const char* dirname, iftrace_options_t ioptions,
				CImage *cimg_display, Image *label,
				Image *pred, Image *cost,
				Image *root, Image *objMap,
				void (*gui_refresh)(void*, int, iftrace_options_t),
				void *obj);

#endif
