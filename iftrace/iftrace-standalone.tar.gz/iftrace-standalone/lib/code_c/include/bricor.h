#ifndef _BRICOR_H_
#define _BRICOR_H_

#include "ift.h"
#include "lab.h"

CImage* LevelLightnessByMin(Features* lab, Image* regions, Set* markers);

CImage* LevelLightnessByMax(Features* lab, Image* regions, Set* markers);

CImage* LevelLightnessByAvg(Features* lab, Image* regions, Set* markers);

void LLByMinOnMarkers(DImage* lightness, Image* regions, Set* markers);

void LLByMaxOnMarkers(DImage* lightness, Image* regions, Set* markers);

void LLByAvgOnMarkers(DImage* lightness, Image* regions, Set* markers);

CImage* UpdateImageLightness(Features* lab, DImage* lightness);

float* RegionsMinimun(DImage* lightness, Image* regions);

float* RegionsMaximum(DImage* lightness, Image* regions);

float* RegionsAvg(DImage* lightness, Image* regions);

#endif // _BRICOR_H_
