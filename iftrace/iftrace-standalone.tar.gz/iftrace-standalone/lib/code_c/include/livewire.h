
#ifndef _LIVEWIRE_H_
#define _LIVEWIRE_H_

#include "ift.h"
#include "shared.h"
#include "sparsegraph.h"

int *Path2Array(Image *pred, int dst);

int *iftLiveWire(Image *cost, Image *pred,
		 SparseGraph *g, Set **S,
		 int init, int src, int dst);

int *iftOLiveWire(Image *cost, Image *pred,
		  SparseGraph *g, Set **S,
		  Image *oimg, char orient,
		  int init, int src, int dst);


#endif

