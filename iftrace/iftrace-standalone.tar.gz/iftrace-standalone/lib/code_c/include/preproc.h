
#ifndef _PREPROC_H_
#define _PREPROC_H_

#include "ift.h"
#include "shared.h"
#include "featmap.h"
#include "gradient.h" 

typedef struct _parameters {
  RealMatrix *Sx,*Sy,*Sz;
  RealMatrix *Sxy,*Sxz,*Syz;
  RealMatrix *Sx2,*Sy2,*Sz2;
  Image  *n;
} Parameters;

Parameters *CreateParameters(int ncols, int nrows);
void        DestroyParameters(Parameters **par);
void        UpdateParameters(Parameters *par, int root, double *v);
void        CompStatistics(Parameters *par, int root, 
			   double *mean, double *covar);
void        InvZNorm(double *covar, double *invZ);
double      Mahalanobis(double *v, double *mean, double *invZ);
Image      *StatisticalReconstruction(int ncols, int nrows,
				      FeatMap *fmap, Set *S);

#endif

