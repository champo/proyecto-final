
#ifndef _SPARSEGRAPH_H_
#define _SPARSEGRAPH_H_

#include "ift.h"
#include "shared.h"
#include "gradient.h"

#define DISSIMILARITY 0
#define CAPACITY      1

// Image Sparse Graph:
// n-links connect pairs of neighboring pixels.
typedef struct _sparseGraph {
  int type;
  int Wmax;
  int **n_link;
  int ncols, nrows;
  AdjRel *A;
} SparseGraph;


// Extended Sparse Graph:
// Image Sparse Graph + two special nodes called terminals:
// source (S) and sink (T).
// t-links connect pixels with terminals (labels).
// The cost of a t-link connecting a pixel and a terminal
// corresponds to a penalty for assigning the corresponding
// label to the pixel.
typedef struct _exSparseGraph {
  int Wmax;
  Image *t_link_S;
  Image *t_link_T;
  SparseGraph *G;
} ExSparseGraph;


//------ SparseGraph Functions ------------

int            get_edge_index(int p, int q,
			      SparseGraph *g);

void           DestroySparseGraph(SparseGraph **g);
SparseGraph   *CreateSparseGraph(int ncols, int nrows,
				 AdjRel *A);
SparseGraph   *CloneSparseGraph(SparseGraph *g);

SparseGraph   *ReadSparseGraphFromTxt(char *filename);
void           WriteSparseGraph2Txt(SparseGraph *sg,
				    char *filename);



SparseGraph   *ImgObjMaps2SparseGraph(CImage *cimg, Image *objMap, \
				      float Wobj, int type);
SparseGraph   *FeatObjMaps2SparseGraph(Features *f, Image *objMap, \
				       float Wobj);
SparseGraph   *FeatObjVGrads2SparseGraph(Features *Gfeat, Features *Gobj, float Wobj);
SparseGraph   *FeatObjBVGrads2SparseGraph(Features *Gfeat, Features *Gobj, int nbands, float Wobj);
SparseGraph   *Gradient2SparseGraph(Image *grad,
				    AdjRel *A);

SparseGraph   *WeightedSparseGraph(Features *f,
				   Image *objMap,
				   Image *bkgMap,
				   float lambda,
				   AdjRel *A);

void           ChangeSparseGraphType(SparseGraph *g,
				     int type);

SparseGraph   *CombineSparseGraph(SparseGraph *g1,
				  SparseGraph *g2,
				  int method);

SparseGraph   *Convert2SymmetricSparseGraph(SparseGraph *g,
					    int method);

Image *ArcWeightImage(SparseGraph *sg);


//------ ExSparseGraph Functions -----------

void           DestroyExSparseGraph(ExSparseGraph **eg);
ExSparseGraph *CreateExSparseGraph(int ncols, int nrows,
				   AdjRel *A);
ExSparseGraph *CloneExSparseGraph(ExSparseGraph *g);

ExSparseGraph *ReadExSparseGraphFromTxt(char *filename);
void           WriteExSparseGraph2Txt(ExSparseGraph *g,
				      char *filename);

ExSparseGraph *SparseGraph2ExSparseGraph(SparseGraph *g,
					 Image *objMap,
					 Image *bkgMap);

#endif

