#ifndef _METHODS_H_
#define _METHODS_H_

#include "ift.h"
#include "shared.h"
#include "sparsegraph.h"
#include "filelist.h"
#include "view.h"
#include "draw.h"
#include "priorityqueue.h"

#define MEAN_CUT        0
#define NORMALIZED_CUT  1
#define ENERGY_FUNC     2
#define LAST_BOUNDARY   3

#define SOURCE_NODE  -1
#define SINK_NODE    -2


// DIFT
//void DifferentialIFT(Image *label, Image *cost, Image *pred,
//		     SparseGraph *g, Set *Si, Set *Se);

void DifferentialIFT(Image *label, Image *cost, Image *pred, Image* root,
                     Image* grad, float radius, Set *Si, Set *Se, Set* delSet);

void DiffIFT(Image *label, Image *cost, Image *pred, Image* root,
                     Image* objMap, Features* feat, float radius, Set *Si, Set *Se, Set* delSet, float Wobj);

void DiffIFTBB(Image *label, Image *cost, Image *pred, Image* root,
                     Image* objMap, Features* feat, float radius, Set *Si, Set *Se, Set* delSet, float Wobj, int xmin, int ymin, int xmax, int ymax);

void DifferentialIFTBB(Image *label, Image *cost, Image *pred, Image* root,
                       Image* grad, float radius, Set *Si, Set *Se, Set* delSet, int xmin, int ymin, int xmax, int ymax);

void DifferentialIFTByRegions(Image *label, Image *cost, Image *pred, Image* root, Image* handicap,
                              Image* grad,  Image* regions, float radius, Set *Si, Set *Se, Set* delSet);

void DifferentialIFTMultObj(Image *label, Image *cost, Image *pred,
                            SparseGraph *g, Set **SeedsArray, int size);

void IFTTieZones2Bkg(Image *label, Image *cost, Image *pred,
                     Image *g, float radius, Set *Si, Set *Se);

Image *GetTieZones(Image *g, float radius, Set *Si, Set *Se);

// WaterGray

Image *VWaterGray(Image *img, Image *marker, Image* cost, AdjRel *A);

// IFT + GraphCut
void IFTGraphCut(Image *label, ExSparseGraph *cap,
                 Set *Si, Set *Se,
                 int measure, float maxorder,
                 float lambda, bool posproc);

Image *TreeCut(Image *pred, Set *S);
Set   *GetTPObject(Image *pred, Set *B, SparseGraph *g);

Image *DescendantCount(Image *pred, Set *B);
Image *CompleteDescendantCount(Image *pred);

Image *LabelTrees(Image *pred);

//Seed competition with K-connectivity
void KappaConnComp(Image *label, SparseGraph *g,
                   Set *Si, Set *Se, float Th);

/*
void KappaConnComp_Demo(Image *label, SparseGraph *g,
			Set *Si, Set *Se, float Th,
			float maxorder, bool kcutseg);
void KappaConnComp_DemoSlices(Image *img, SparseGraph *g,
			      Set *Si, Set *Se, float Th);
*/


//IFT to create animations
Curve *IFTVideo(Image *label,
                Image *cost,
                Image *pred,
                Image *rank,
                ExSparseGraph *cap,
                Set *Si, Set *Se,
                int measure, float maxorder,
                float lambda);

CImage *IFTVideoFrame(int r, CImage *cimg,
                      Image *label, Image *rank,
                      Set *Si, Set *Se, bool posproc,
                      int objColor, int bkgColor,
                      int w, int h);

void WriteIFTVideoFrames(CImage *cimg,
                         Image *label, Image *rank,
                         Set *Si, Set *Se, bool posproc,
                         int objColor, int bkgColor,
                         int w, int h, FileList *L);

void WriteKCCVideoFrames(CImage *cimg,
                         Image *label, Image *cost,
                         Set *Si, Set *Se, bool posproc,
                         int objColor, int bkgColor,
                         int w, int h, FileList *L);

void WriteTPVideoFrames(CImage *cimg,
                        Image *pred, Set *Si,
                        int objColor, int bkgColor,
                        int w, int h, FileList *L);

void FastWritePlotVideoFrames(Curve *C,
                              char *title,
                              char *xlabel,
                              char *ylabel,
                              int objColor, int plotColor,
                              int w, int h, FileList *L);
#endif

