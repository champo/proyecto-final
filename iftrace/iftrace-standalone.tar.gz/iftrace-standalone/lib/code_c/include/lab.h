#ifndef _LAB_H_
#define _LAB_H_

#include "ift.h"

void PixelRGB2XYZ(float* R, float* G, float* B);

void PixelXYZ2RGB(float* X, float* Y, float* Z);

void PixelXYZ2Lab(float* X, float* Y, float* Z);

void PixelXYZ2RGB(float* X, float* Y, float* Z);

void PixelLab2XYZ(float *L, float *a, float *b);


CImage* gimp_extract_lab (CImage  *src);

#endif
