#ifndef _MYMORPHOLOGY_H_
#define _MYMORPHOLOGY_H_

#include "code_c.h"

Image *CloseLabelHoles(Image *label, Image* root, int deflabel);
Image *LabelSupRec(Image *img, Image *marker, Image* root, int deflabel, AdjRel *A);

#endif


