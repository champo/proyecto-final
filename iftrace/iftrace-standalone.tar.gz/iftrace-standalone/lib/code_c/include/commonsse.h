#ifndef _COMMONSSE_H_
#define _COMMONSSE_H_

#include <xmmintrin.h>

inline float* AllocAlgnFloatArray(int n, int align);
inline int* AllocAlgnIntArray(int n, int align);

inline __m128 Mux2to1(const __m128 x, const __m128 y, const __m128 s);

float MinimumPS(__m128 A);

float MaximumPS(__m128 A);

#endif // _COMMONSSE_H_
