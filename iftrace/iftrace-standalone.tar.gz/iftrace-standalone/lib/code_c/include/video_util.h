#ifndef _VIDEO_UTIL_H_
#define _VIDEO_UTIL_H_

#include "code_c.h"

CImage * ReadPPM (const char *path, int frame);

void  WritePPM (CImage *img, const char *path, const char *name, int region);

void  WritePGM (Image *img, const char *path, const char *name, int region);

#endif // _VIDEO_UTIL_H_
