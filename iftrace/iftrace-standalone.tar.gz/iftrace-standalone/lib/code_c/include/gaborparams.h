#ifndef _GABORPARAMS_H_
#define _GABORPARAMS_H_


  // number of scales during image decomposition.
  const int NSCALES       = 4;

  // number of orientations during image decomposition.
  const int NORIENTATIONS = 6;

  // filter size.
  const int NSZE          = 128;

  // highest frequency.
  const double DUH        = 0.4;

  // lowest frequency.
  const double DUL        = 0.05;

#endif
