
#ifndef _DRAW_H_
#define _DRAW_H_

#include "ift.h"

void    BlendDrawImage(Image *img, Image *draw, Image *alpha);
void    BlendDrawCImage(CImage *cimg, CImage *cdraw, Image *alpha);

inline void DrawCImagePixel(CImage *cdraw, 
			    Image *alpha, 
			    int p, 
			    int color,
			    int a);

inline void DrawImagePixel(Image *draw, 
			   Image *alpha, 
			   int p,
			   int val,
			   int a);

void    DrawCImageFloodFill(CImage *cdraw, Image *alpha, 
			    int s, int color, int a);
void    DrawImageFloodFill(Image *draw, Image *alpha, 
			   int s, int val, int a);

void    DrawCImageLine(CImage *cdraw, Image *alpha, int p, int q, 
		       float r, int color, int a, bool smooth);
void    DrawImageLine(Image *draw, Image *alpha, int p, int q, 
		      float r, int val, int a, bool smooth);

void    DrawCImageCircle(CImage *cdraw, Image *alpha, int c, 
			 float r, int color, int a, bool smooth);
void    DrawImageCircle(Image *draw, Image *alpha, int c, 
			float r, int val, int a, bool smooth);
void    DrawImageCircumference(Image *draw, Image *alpha, int c, 
			       float r, int val, int a);

void    DrawImageFillRectangle(Image *draw, Image *alpha, int p,
			       int q, int val, int a);

void    DrawCImageFillRectangle(CImage *cdraw, Image *alpha, int p,
				int q, int color, int a);

void    DrawCImageArrow(CImage *cdraw, Image *alpha, int p, int q, 
			float r, float w, float h,
			int color, int a, bool smooth);

void    DrawImageArrow(Image *draw, Image *alpha, int p, int q,
		       float r, float w, float h,
		       int val, int a, bool smooth);

void    DrawCImageSet(CImage *cdraw, Image *alpha, Set *S,
		      float r, int color, int a, bool smooth);

void    DrawCImageSimpleDot(CImage *cdraw, Image *alpha, int c,
			    float r, int color, int a);

void    DrawCImageStripedDot(CImage *cdraw, Image *alpha, int c,
			     float r, int color, int a,
			     int n, double angle);

void    DrawCImageGridDot(CImage *cdraw, Image *alpha, int c,
			  float r, int color, int a,
			  int n, double angle);

#endif

