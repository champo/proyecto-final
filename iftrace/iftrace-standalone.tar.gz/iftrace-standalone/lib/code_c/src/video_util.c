#include "video_util.h"

CImage * ReadPPM (const char *path, int frame)
{
    char *name = NULL;
    asprintf(&name, "%s/%05d/frame.ppm", path, frame);
    fprintf(stderr,"\nReading frame %s\n",name);
    CImage *orig = ReadCImage (name);
    free(name);
    return orig;
}


void  WritePPM (CImage *img, const char *path, const char *name, int region)
{
    char *tname = NULL;
    asprintf(&tname, "%s/%s_%02d.ppm", path, name, region);
    WriteCImage(img, tname);
    free(tname);
}

void  WritePGM (Image *img, const char *path, const char *name, int region)
{
    char *tname = NULL;
    asprintf(&tname, "%s/%s_%02d.pgm", path, name, region);
    WriteImage(img, tname);
    free(tname);
}
