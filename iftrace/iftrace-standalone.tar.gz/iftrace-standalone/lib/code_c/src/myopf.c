#include "myopf.h"

Matrix *ImageDDF(Subgraph *sg, Features *f, int label)
{
    CNode  *node=CreateCNode(sg);
    int     i,p;
    Matrix  *ddf=CreateMatrix(f->ncols,f->nrows);

    for (p=0; p<f->nelems; p++)
    {
        for (i=0; i<sg->nfeats; i++)
            node->feat[i]=f->elem[p].feat[i];
        NodeArcsByTrueLabel(sg, node, label);
        NodeDD(sg,node);
        ddf->val[p] = node->dens;
    }
    DestroyCNode(&node);
    return(ddf);
}


Matrix *ImageDDFBB(Subgraph *sg, Features *f, int label, int xmin, int ymin, int xmax, int ymax)
{
    CNode  *node=CreateCNode(sg);
    int     i,p,x,y;
    Matrix  *ddf=CreateMatrix(f->ncols,f->nrows);

    for (y=ymin; y<ymax; y++)
    {
        for (x=xmin; x<xmax; x++)
        {
            p = f->ncols*y + x;

            for (i=0; i<sg->nfeats; i++)
                node->feat[i]=f->elem[p].feat[i];
            NodeArcsByTrueLabel(sg, node, label);
            NodeDD(sg,node);
            ddf->val[p] = node->dens;
        }
    }
    DestroyCNode(&node);
    return(ddf);
}

// Compute node dist density for classification node
void NodeDD(Subgraph *sg, CNode *node)
{
    int     i,nelems;
    float   dist;
    double  value;

    value=0.0;
    nelems=1;
    for (i=0; i < sg->bestk; i++)
    {
        dist = EuclDist(node->feat,sg->node[node->adj[i]].feat,sg->nfeats);
        value += dist;
        nelems++;
    }
    value = value/(float)nelems;

    node->dens = (value);

}

void ClassifyDDF(Subgraph *sgTrain, Subgraph *sg)
{
    CNode  *node=CreateCNode(sgTrain);
    int     i,label,bestlabel,p;
    float   mindist;

    for (p=0; p<sg->nnodes; p++)
    {
        for (i=0; i<sg->nfeats; i++)
            node->feat[i]=sg->node[p].feat[i];
        node->position = sg->node[p].position;
        bestlabel=NIL;
        mindist=FLT_MAX;


        for (label=0; label<sgTrain->nlabels; label++)
        {
        /// Finds and sorts the k-nearest that have label different from
        /// the given node
        NodeArcsByTrueLabel(sgTrain,node,label);
        /// Updates the node density with the estimation
        /// of its probability

            NodeDD(sgTrain,node);
            if (node->dens < mindist)
            {
                mindist = node->dens;
                bestlabel = label;
            }
        }
        sg->node[p].label=bestlabel;
    }
    DestroyCNode(&node);
}


// Compute node dist density for classification node
void NodeDDByTrueLabel(Subgraph *sg, CNode *node, int label)
{
    int     i,nelems;
    float   dist;
    double  value;

    value=0.0;
    nelems=1;
    for (i=0; i < sg->bestk; i++)
    {
        if(sg->node[node->adj[i]].truelabel != label)
        {
            dist = EuclDist(node->feat,sg->node[node->adj[i]].feat,sg->nfeats);
            value += dist;
        }
        nelems++;
    }
    value = value/(float)nelems;
    node->dens = (value);
}

// Estimate the best k
void BestkMinErrorDDF(Subgraph *sgTrain,
                      Subgraph *sgEval, int kmax)
{
    int k;
    float maxacc=FLT_MIN,Acc;

    // Find the best k
    for (k=1; (k <= kmax); k++)
    {
        sgTrain->bestk=k;
        ClassifyDDF(sgTrain,sgEval);
        Acc = Accuracy(sgEval);
        if (Acc >= maxacc)
        {
            maxacc=Acc;
            sgEval->bestk =k;
        }
        //DestroyArcs(sgTrain);
    }
    sgTrain->bestk=sgEval->bestk;
    //CreateArcsByTrueLabel(sgTrain,sgTrain->bestk);
}


float LearningDDF(Subgraph **sgtrain, Subgraph **sgeval,
                 int iterations, int kmax)
{
    int i;
    float Acc,MaxAcc=FLT_MIN;
    Subgraph *sg=NULL;

    for (i=1; (i <= iterations)&&(MaxAcc != 1.0); i++)
    {
        fprintf(stdout, "\n running iteration ... %d \n ", i);
        BestkMinErrorDDF(*sgtrain,*sgeval, kmax);
        //(*sgtrain)->bestk=kmax;
        ClassifyDDF(*sgtrain, *sgeval);
        Acc = Accuracy(*sgeval);
        fprintf(stdout,"Acc: %f\n", Acc);
        if (Acc > MaxAcc)
        {
            MaxAcc = Acc;
            if (sg!=NULL) DestroySubgraph(&sg);
            sg = CopySubgraph(*sgtrain);
        }
        //DestroyArcs(*sgtrain);
        SwapErrorsbySamples(&(*sgtrain), &(*sgeval));
    }
    DestroySubgraph(&(*sgtrain));
    *sgtrain = sg;
    //CreateArcsByTrueLabel(*sgtrain,(*sgtrain)->bestk);
    printf("bestk %d MaxAcc %f\n",(*sgtrain)->bestk,MaxAcc);
    return MaxAcc;
}

Image *ObjProbMap(Matrix *dobj, Matrix *dbkg)
{
    Image *obj;
    float fdo,fdb;
    int p,n;

    obj = CreateImage(dobj->ncols,dobj->nrows);
    n = dobj->ncols*dobj->nrows;
    for (p=0; p<n; p++)
    {
        fdo = (float)dobj->val[p];
        fdb = (float)dbkg->val[p];
        if ((fdb+fdo)<0.00001 || fdb == fdo)
        {
            obj->val[p] = ROUND(MAXDENS*0.5);
        }else
            obj->val[p] = ROUND(MAXDENS*fdb/(fdb+fdo));
    }
    return obj;
}

Image *BkgProbMap(Matrix *dobj, Matrix *dbkg)
{
    Image *bkg;
    float fdo,fdb;
    int p,n;

    bkg = CreateImage(dobj->ncols,dobj->nrows);
    n = dobj->ncols*dobj->nrows;
    for (p=0; p<n; p++)
    {
        fdo = (float)dobj->val[p];
        fdb = (float)dbkg->val[p];

        if ((fdb+fdo)<0.00001 || fdb == fdo)
            bkg->val[p] = ROUND(MAXDENS*0.5);
        else
            bkg->val[p] = ROUND(MAXDENS*fdo/(fdb+fdo));

    }
    return bkg;
}


int FindDDFkmax(Subgraph *sgTrain)
{
    int *label=AllocIntArray(sgTrain->nlabels);
    int i,kmax=INT_MAX;

    for (i=0; i<sgTrain->nnodes; i++)
        label[sgTrain->node[i].truelabel]++;

    for (i=0; i<sgTrain->nlabels; i++)
        kmax = MIN(kmax,label[i]);

    free(label);
    return MAX(kmax/2,1);
}


/** OPF **/

/** Classify nodes of evaluation/test set for CompGraph,
 *  only using nodes labeled with label
 **/

void ImagePVMapsCompGraph(Subgraph* sgtrain, Features* f, Image** objMap, Image** bkgMap)
{
    Matrix* obj, *bkg;

    fprintf(stderr,"Creating object probability map... Please wait... \n");
    obj = ImagePVCompGraph(sgtrain, f, 1);

    fprintf(stderr,"Creating background probability map... Please wait... \n");
    bkg = ImagePVCompGraph(sgtrain, f, 0);

    *objMap = ObjProbMap(obj,bkg);
    *bkgMap = NULL;
//    *bkgMap = BkgProbMap(obj,bkg);

    DestroyMatrix(&obj);
    DestroyMatrix(&bkg);
}


Matrix *ImagePVCompGraph(Subgraph *sg, Features *f, int label)
{
    Matrix *pvalmap=CreateMatrix(f->ncols,f->nrows);
    int p,q,n=f->nelems;
    int tmp,minval,weight;


    for (q=0; q < n; q++)
    {

        minval = INT_MAX;
        for (p=0; p < sg->nnodes; p++)
        {
            if(sg->node[p].label == label)
            {
                weight = ArcWeight(EuclDist(f->elem[q].feat,sg->node[p].feat,sg->nfeats), sg->df);
                tmp  = MAX(sg->node[p].pathval,weight);
                if (tmp < minval)
                {
                    pvalmap->val[q]=(double)tmp;
                    minval = tmp;
                }
            }
        }
    }
    return(pvalmap);
}

Subgraph* SubgraphFromMarkers(Features* f, Set* Si, Set* Se)
{

    Subgraph *sg=NULL;
    Set *aux;
    int ni,ne,i;

    ni = GetSetSize(Si);
    ne = GetSetSize(Se);

    if (ni == 0 || ne == 0) return NULL;

    ///--------CreateSubGraph-----------------

    sg=(Subgraph *)calloc(1,sizeof(Subgraph));
    sg->nnodes  = ni+ne;
    sg->nlabels = 2;
    sg->node    = (SNode *)calloc(sg->nnodes,sizeof(SNode));

    if (sg->node == NULL) Error((char*)"Cannot allocate nodes",(char*)"SubgraphFromMarkers");

    i = 0;
    aux = Si;
    while (aux != NULL)
    {
        sg->node[i].position  = aux->elem;
        sg->node[i].truelabel = 1;
        sg->node[i].adj=NULL;
        sg->node[i].status=0; // training node
        sg->node[i].feat=NULL;
        aux = aux->next;
        i++;
    }
    aux = Se;
    while (aux != NULL)
    {
        sg->node[i].position  = aux->elem;
        sg->node[i].truelabel = 0;
        sg->node[i].adj=NULL;
        sg->node[i].status=0; // training node
        sg->node[i].feat=NULL;
        aux = aux->next;
        i++;
    }

    SetSubgraphFeatures(sg,f);

    return sg;
}

//Executes the learning procedure for CompGraph replacing the
//missclassified samples in the evaluation set by non prototypes from
//training set
void FuzzyLearningCompGraph(Subgraph **sgtrainobj, Subgraph **sgtrainbkg, Subgraph **sgeval, int iterations)
{
    int i;
    float Acc=FLT_MIN,MaxAcc=FLT_MIN;
    Subgraph *sg = NULL;
    Subgraph *sg2 = NULL;

    for (i = 1; i <= iterations && MaxAcc != 1.0; i++)
    {
        fprintf(stdout, "\nrunning iteration ... %d ", i);
        ResetCompGraph(*sgtrainobj);
        FuzzySupTrainCompGraph(*sgtrainobj);

        ResetCompGraph(*sgtrainbkg);
        FuzzySupTrainCompGraph(*sgtrainbkg);

        FuzzyClassifyCompGraph(*sgtrainobj, *sgtrainbkg, *sgeval);
        Acc = Accuracy(*sgeval);
        if (Acc > MaxAcc)
        {
            MaxAcc = Acc;
            if (sg!=NULL) DestroySubgraph(&sg);
            if (sg2!=NULL) DestroySubgraph(&sg2);
            sg = CopySubgraph(*sgtrainobj);
            sg2 = CopySubgraph(*sgtrainbkg);
        }
        SwapErrorsbyLabeledNonPrototypes(&(*sgtrainobj), &(*sgeval));
        SwapErrorsbyLabeledNonPrototypes(&(*sgtrainbkg), &(*sgeval));
        fprintf(stdout,"Acc: %f\n", Acc);
    }

    DestroySubgraph(&(*sgtrainobj));
    DestroySubgraph(&(*sgtrainbkg));
    *sgtrainobj = sg;
    *sgtrainbkg = sg2;

    ResetCompGraph(*sgtrainobj);
    FuzzySupTrainCompGraph(*sgtrainobj);

    ResetCompGraph(*sgtrainbkg);
    FuzzySupTrainCompGraph(*sgtrainbkg);

    printf("Best accuracy %f\n",MaxAcc);
}


// Classify nodes of evaluation/test set for CompGraph
void FuzzyClassifyCompGraph(Subgraph *sgtrainobj, Subgraph* sgtrainbkg, Subgraph *sg)
{
    int i, j;
    int objlabel = sgtrainobj->node[0].truelabel;
    int bkglabel = sgtrainbkg->node[0].truelabel;
    int weight, minCostObj, minCostBkg, cost;

    for (i = 0; i < sg->nnodes; i++)
    {
        minCostObj = INT_MAX;
        for (j = 0; j < sgtrainobj->nnodes; j++)
        {
            if (!PrecomputedDistance)
                weight = (int)ArcWeight(DistFun(sgtrainobj->node[j].feat,sg->node[i].feat,sg->nfeats), sgtrainobj->df);
            else
                weight = (int)ArcWeight(DistanceValue[sgtrainobj->node[j].position][sg->node[i].position], sgtrainobj->df);

            cost = MAX(sgtrainobj->node[j].pathval, weight);

            if (cost < minCostObj)
            {
                minCostObj = cost;
            }
        }

        minCostBkg = INT_MAX;
        for (j = 0; j < sgtrainbkg->nnodes; j++)
        {
            if (!PrecomputedDistance)
                weight = (int)ArcWeight(DistFun(sgtrainbkg->node[j].feat,sg->node[i].feat,sg->nfeats), sgtrainbkg->df);
            else
                weight = (int)ArcWeight(DistanceValue[sgtrainbkg->node[j].position][sg->node[i].position], sgtrainbkg->df);

            cost = MAX(sgtrainbkg->node[j].pathval, weight);

            if (cost < minCostBkg)
            {
                minCostBkg = cost;
            }
        }

        if(minCostObj == minCostBkg)
        {
            /// Forcing error
            if(sg->node[i].truelabel == objlabel)
            {
                sg->node[i].label = bkglabel;
            }else{
                sg->node[i].label = objlabel;
            }

//            fprintf(stderr,"error forced on pixel %d\n", sg->node[i].position);
        }else{
            if(minCostObj < minCostBkg)
            {
                sg->node[i].label = objlabel;
            }else{
                sg->node[i].label = bkglabel;
            }
        }
    }

}


// Replace errors from evaluating set by non prototypes from training set
// Notice that all nodes in this training set have the same label
void SwapErrorsbyLabeledNonPrototypes(Subgraph **sgtrain, Subgraph **sgeval)
{
    int i, j, counter, nprototypes = 0, nerrors = 0;

    for (i = 0; i < (*sgtrain)->nnodes; i++)
        if ((*sgtrain)->node[i].pred != NIL) nprototypes++;

    for (i = 0; i < (*sgeval)->nnodes; i++)
        if ((*sgeval)->node[i].label != (*sgeval)->node[i].truelabel) nerrors++;

    for (i = 0; i < (*sgeval)->nnodes && nprototypes >0 && nerrors > 0; i++)
    {
        /// only nodes labeled incorrectly whose truelabel is the same of
        /// the nodes in sgtrain will be replaced, therefore errors
        /// from other labels will remain
        if ((*sgeval)->node[i].label != (*sgeval)->node[i].truelabel
         && (*sgeval)->node[i].truelabel == (*sgtrain)->node[0].truelabel)
        {
            counter = (*sgtrain)->nnodes;
            while (counter > 0)
            {
                j = RandomInteger(0,(*sgtrain)->nnodes-1);
                if (((*sgtrain)->node[j].status != NIL) && ((*sgtrain)->node[j].pred != NIL))
                {
                    SwapSNode(&((*sgtrain)->node[j]), &((*sgeval)->node[i]));
                    (*sgtrain)->node[j].status = NIL;
                    nprototypes--;
                    nerrors--;
                    counter = 0;
                }else{
                    counter--;
                }
            }
        }
    }
}



void FuzzyImagePVMapsCompGraph(Subgraph* sgtrainobj, Subgraph* sgtrainbkg, Features* f, Image** objMap, Image** bkgMap)
{
    Matrix* obj = NULL, *bkg = NULL;

    fprintf(stderr,"Creating object probability map... Please wait... \n");
    obj = ImagePVCompGraph(sgtrainobj, f, 1);

    fprintf(stderr,"Creating background probability map... Please wait... \n");
    bkg = ImagePVCompGraph(sgtrainbkg, f, 0);

    *objMap = ObjProbMap(obj,bkg);
    *bkgMap = BkgProbMap(obj,bkg);

    DestroyMatrix(&obj);
    DestroyMatrix(&bkg);
}


void FuzzySupTrainCompGraph(Subgraph *sg)
{
    int p,q;
    float tmp,weight;
    RealHeap *Q = NULL;
    float *pathval = NULL;

    // initialization

    pathval = AllocFloatArray(sg->nnodes);

    Q=CreateRealHeap(sg->nnodes, pathval);

    for (p = 0; p < sg->nnodes; p++)
    {
        if (sg->node[p].status==PROTOTYPE)
        {
            pathval[p]         = 0.0;
            sg->node[p].label  = sg->node[p].truelabel;
            sg->node[p].pred   = NIL;
            InsertRealHeap(Q, p);
        }
        else  // non-prototypes
        {
            pathval[p]  = FLT_MAX;
        }
    }

    // IFT with fmax

    while ( !IsEmptyRealHeap(Q) )
    {
        RemoveRealHeap(Q,&p);

        sg->node[p].pathval = pathval[p];

        for (q=0; q < sg->nnodes; q++)
        {
            if (p!=q)
            {
                if (pathval[p] < pathval[q])
                {
                    if (!PrecomputedDistance)
                        weight = ArcWeight(DistFun(sg->node[p].feat,sg->node[q].feat,sg->nfeats), sg->df);
                    else
                        weight = ArcWeight(DistanceValue[sg->node[p].position][sg->node[q].position], sg->df);
                    tmp  = MAX(pathval[p],weight);
                    if ( tmp < pathval[ q ] )
                    {
                        sg->node[q].pred  = p;
                        sg->node[q].label = sg->node[p].label;
                        UpdateRealHeap(Q, q,tmp);
                    }
                }
            }
        }
    }

    DestroyRealHeap( &Q );
    free( pathval );
}


/** Video -- OPF **/

/** Classify nodes of evaluation/test set for CompGraph,
 *  only using nodes labeled with label
 **/

void ImagePVMapsCompGraphBB(Subgraph* sgtrain, Features* f, Image** objMap, Image** bkgMap, int xmin, int ymin, int xmax, int ymax)
{
    Matrix* obj, *bkg;

    fprintf(stderr,"Creating object probability map... Please wait... \n");
    obj = ImagePVCompGraphBB(sgtrain, f, 1, xmin, ymin, xmax, ymax);

    fprintf(stderr,"Creating background probability map... Please wait... \n");
    bkg = ImagePVCompGraphBB(sgtrain, f, 0, xmin, ymin, xmax, ymax);

    *objMap = ProbMapBB(obj,bkg, xmin, ymin, xmax, ymax);
    *bkgMap = NULL;
//    *bkgMap = ProbMapBB(bkg,obj, xmin, ymin, xmax, ymax);

    DestroyMatrix(&obj);
    DestroyMatrix(&bkg);
}


Matrix *ImagePVCompGraphBB(Subgraph *sg, Features *f, int label, int xmin, int ymin, int xmax, int ymax)
{
    Matrix *pvalmap=CreateMatrix(f->ncols,f->nrows);
    int x,y,p,q;
    int tmp,minval,weight;

    for(y = ymin; y < ymax; y++)
    {
        for(x = xmin; x < xmax; x++)
        {
            q = y*f->ncols + x;

            minval = INT_MAX;
            for (p=0; p < sg->nnodes; p++)
            {
                if(sg->node[p].label == label)
                {
                    /** If current node is not part of trainning graph
                     *  find minimum path until it
                     **/
                    if (sg->node[p].position!=q)
                    {
                        weight = ArcWeight(EuclDist(f->elem[q].feat,sg->node[p].feat,sg->nfeats), sg->df);
                        tmp  = MAX(sg->node[p].pathval,weight);
                        if (tmp < minval)
                        {
                            pvalmap->val[q]=(double)tmp;
                            minval = tmp;
                        }
                    }
                    else
                    {
                        pvalmap->val[q] = (double)sg->node[p].pathval;
                        break;
                    }

                }
            }
        }
    }
    return(pvalmap);
}

Image *ProbMapBB(Matrix *dobj, Matrix *dbkg, int xmin, int ymin, int xmax, int ymax)
{
    Image *obj;
    float fdo,fdb;
    int p,n,x,y;

    obj = CreateImage(dobj->ncols,dobj->nrows);
    n = dobj->ncols*dobj->nrows;
    for(y = ymin; y < ymax; y++)
    {
        for(x = xmin; x < xmax; x++)
        {
            p = dobj->tbrow[y] + x;
            fdo = (float)dobj->val[p];
            fdb = (float)dbkg->val[p];
            if ((fdb+fdo)<0.00001 || fdb == fdo)
            {
                obj->val[p] = ROUND(MAXDENS*0.5);
            }else
                obj->val[p] = ROUND(MAXDENS*fdb/(fdb+fdo));
        }
    }
    return obj;
}



void FuzzyImagePVMapsCompGraphBB(Subgraph* sgtrainobj, Subgraph* sgtrainbkg, Features* f, Image** objMap, Image** bkgMap,
    int xmin, int ymin, int xmax, int ymax)
{
    Matrix* obj, *bkg;

    fprintf(stderr,"Creating object probability map... Please wait... \n");
    obj = ImagePVCompGraphBB(sgtrainobj, f, 1, xmin, ymin, xmax, ymax);

    fprintf(stderr,"Creating background probability map... Please wait... \n");
    bkg = ImagePVCompGraphBB(sgtrainbkg, f, 0, xmin, ymin, xmax, ymax);

    *objMap = ProbMapBB(obj,bkg, xmin, ymin, xmax, ymax);
    *bkgMap = NULL;
//    *bkgMap = BkgProbMap(obj,bkg);

    DestroyMatrix(&obj);
    DestroyMatrix(&bkg);
}
