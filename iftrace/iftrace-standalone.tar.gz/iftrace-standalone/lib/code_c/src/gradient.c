#include "gradient.h"


/* Color Gradient */
Image *nDimGradient(CImage *cimg)
{
    Image  *grad=NULL;
    int i,n;
    Image *tmp[3], *aux=NULL;
    int i0, i1, offset;
    int dx[3],dy[3];
    int g11,g12,g22;
    double c;

    tmp[0] = AddFrame(cimg->C[0],1,0);
    tmp[1] = AddFrame(cimg->C[1],1,0);
    tmp[2] = AddFrame(cimg->C[2],1,0);

    grad = CreateImage(tmp[0]->ncols, tmp[0]->nrows);

    n = tmp[0]->ncols * tmp[0]->nrows;
    offset =  tmp[0]->ncols;
    i0 = offset + 1;
    i1 = i0 + n;

    for (i=i0; i<i1; i++)
    {

        dx[0] = (tmp[0]->val[i+1]-tmp[0]->val[i-1])/2;
        dx[1] = (tmp[1]->val[i+1]-tmp[1]->val[i-1])/2;
        dx[2] = (tmp[2]->val[i+1]-tmp[2]->val[i-1])/2;

        dy[0] = (tmp[0]->val[i+offset]-tmp[0]->val[i-offset])/2;
        dy[1] = (tmp[1]->val[i+offset]-tmp[1]->val[i-offset])/2;
        dy[2] = (tmp[2]->val[i+offset]-tmp[2]->val[i-offset])/2;

        g11 = (int)(dx[0] * dx[0] + dx[1] * dx[1] + dx[2] * dx[2]);
        g12 = (int)(dx[0] * dy[0] + dx[1] * dy[1] + dx[2] * dy[2]);
        g22 = (int)(dy[0] * dy[0] + dy[1] * dy[1] + dy[2] * dy[2]);

        c = sqrt ((double)((g11 - g22) * (g11 - g22)) + 4 * g12 * g12 );
        /*
          note:
          lambda_plus = (g11 + g22 + c) / 2;
          lambda_minus = (g11 + g22 - c) / 2;
          lambda_minus = lambda_plus - c;
          c = lamda_plus - lambda_minus
        */
        grad->val[i] = (int)sqrt(c);//(int)sqrt((g11 + g22 + c) / 2);
    }

    aux = RemFrame(grad,1);
    DestroyImage(&grad);
    DestroyImage(&tmp[0]);
    DestroyImage(&tmp[1]);
    DestroyImage(&tmp[2]);

    return(aux);
}


Image *nDimSobel(CImage *cimg)
{
    Image  *grad=NULL;
    int i,n;
    Image *tmp[3], *aux=NULL;
    Image *gradx[3], *grady[3];
    Kernel *Kx,*Ky;
    int i0, i1, offset;
    int dx[3],dy[3];
    int g11,g12,g22;
    double c;

    tmp[0] = AddFrame(cimg->C[0],1,0);
    tmp[1] = AddFrame(cimg->C[1],1,0);
    tmp[2] = AddFrame(cimg->C[2],1,0);

    grad = CreateImage(tmp[0]->ncols, tmp[0]->nrows);

    n = tmp[0]->ncols * tmp[0]->nrows;
    offset =  tmp[0]->ncols;
    i0 = offset + 1;
    i1 = i0 + n;

    Ky = MakeKernel("3,3,-1.0,-2.0,-1.0,0.0,0.0,0.0,1.0,2.0,1.0");
    Kx = MakeKernel("3,3,-1.0,0.0,1.0,-2.0,0.0,2.0,-1.0,0.0,1.0");

    gradx[0] = LinearFilter2(tmp[0],Kx);
    gradx[1] = LinearFilter2(tmp[1],Kx);
    gradx[2] = LinearFilter2(tmp[2],Kx);

    grady[0] = LinearFilter2(tmp[0],Ky);
    grady[1] = LinearFilter2(tmp[1],Ky);
    grady[2] = LinearFilter2(tmp[2],Ky);

    for (i=i0; i<i1; i++)
    {
        dx[0] = gradx[0]->val[i];
        dx[1] = gradx[1]->val[i];
        dx[2] = gradx[2]->val[i];

        dy[0] = grady[0]->val[i];
        dy[1] = grady[1]->val[i];
        dy[2] = grady[2]->val[i];

        g11 = (int)(dx[0] * dx[0] + dx[1] * dx[1] + dx[2] * dx[2]);
        g12 = (int)(dx[0] * dy[0] + dx[1] * dy[1] + dx[2] * dy[2]);
        g22 = (int)(dy[0] * dy[0] + dy[1] * dy[1] + dy[2] * dy[2]);

        c = sqrt ((double)((g11 - g22) * (g11 - g22)) + 4 * g12 * g12 );
        /*
          note:
          lambda_plus = (g11 + g22 + c) / 2;
          lambda_minus = (g11 + g22 - c) / 2;
          lambda_minus = lambda_plus - c;
          c = lamda_plus - lambda_minus
        */
        grad->val[i] = (int)sqrt((g11 + g22 + c) / 2);
    }

    DestroyImage(&gradx[0]);
    DestroyImage(&gradx[1]);
    DestroyImage(&gradx[2]);

    DestroyImage(&grady[0]);
    DestroyImage(&grady[1]);
    DestroyImage(&grady[2]);

    DestroyKernel(&Kx);
    DestroyKernel(&Ky);

    aux = RemFrame(grad,1);
    DestroyImage(&grad);
    DestroyImage(&tmp[0]);
    DestroyImage(&tmp[1]);
    DestroyImage(&tmp[2]);

    return(aux);
}


Image *SimpleGradient(Image *img)
{
    Image *grad;
    Pixel s,u,v,g;
    int s1,u1,v1;

    grad = CreateImage(img->ncols,img->nrows);
    for (u.y=0; u.y < grad->nrows; u.y++)
        for (u.x=0; u.x < grad->ncols; u.x++)
        {
            v.x = ((u.x + 1)==grad->ncols)?u.x:u.x+1;
            v.y = u.y;
            s.x = ((u.x-1)==-1)?u.x:u.x-1;
            s.y = u.y;
            u1  = u.x + grad->tbrow[u.y];
            v1  = v.x + grad->tbrow[v.y];
            s1  = s.x + grad->tbrow[s.y];
            g.x = ((img->val[u1]+img->val[v1])/2 -
                   (img->val[u1]+img->val[s1])/2);
            v.x = u.x;
            v.y = ((u.y + 1)==grad->nrows)?u.y:u.y+1;
            s.x = u.x;
            s.y = ((u.y-1)==-1)?u.y:u.y-1;
            u1  = u.x + grad->tbrow[u.y];
            v1  = v.x + grad->tbrow[v.y];
            s1  = s.x + grad->tbrow[s.y];
            g.y = ((img->val[u1]+img->val[v1])/2 -
                   (img->val[u1]+img->val[s1])/2);
            grad->val[u1] = (int)sqrt(g.x*g.x + g.y*g.y);
        }
    return(grad);
}
//
//Image *FeatureGradient(Image *img, int nfeats)
//{
//    float   dist,gx,gy;
//    int     i,j,p,q,s,n=img->ncols*img->nrows,Imax;
//    Pixel   u,v;
//    AdjRel *A8=Circular(1.5),*A=NULL;
//    float  *mg=AllocFloatArray(A8->n);
//    Image  *grad=CreateImage(img->ncols,img->nrows);
//    float  **feat=(float **)calloc(nfeats,sizeof(float *));
//    Image *img1,*img2;
//
//    /* Compute multiscale features with nfeats scales */
//
//    for (i=0; i < nfeats; i++)
//        feat[i]=AllocFloatArray(n);
//
//    Imax  = MaximumValue(img);
//    img1  = CopyImage(img);
//
//    for (s=1; s <= nfeats; s=s+1)
//    {
//        A  = Circular(s);
//        img2 = AsfOCRec(img1,A);
//        for (i=0; i < n; i++)
//        {
//            feat[s-1][i] = (float)img2->val[i]/(float)Imax;
//        }
//        DestroyImage(&img2);
//        DestroyAdjRel(&A);
//    }
//    DestroyImage(&img1);
//
//    /* Compute Gradient */
//
//    for (i=0; i < A8->n; i++)
//        mg[i]=sqrt(A8->dx[i]*A8->dx[i]+A8->dy[i]*A8->dy[i]);
//
//    for (u.y=0; u.y < img->nrows; u.y++)
//        for (u.x=0; u.x < img->ncols; u.x++)
//        {
//            p = u.x + img->tbrow[u.y];
//            gx = gy = 0.0;
//            for (i=1; i < A8->n; i++)
//            {
//                v.x = u.x + A8->dx[i];
//                v.y = u.y + A8->dy[i];
//                if (ValidPixel(img,v.x,v.y))
//                {
//                    q = v.x + img->tbrow[v.y];
//                    dist = 0;
//                    for (j=0; j < nfeats; j++)
//                        dist += feat[j][q]-feat[j][p];
//                    gx  += dist*A8->dx[i]/mg[i];
//                    gy  += dist*A8->dy[i]/mg[i];
//                }
//            }
//            grad->val[p]=(int)(MAXDENS*sqrt(gx*gx + gy*gy));
//        }
//
//    free(mg);
//    DestroyAdjRel(&A8);
//    for (i=0; i < nfeats; i++)
//        free(feat[i]);
//    free(feat);
//    return(grad);
//}
//

Image *TextGradientNew(Image *img, int rsize)
{
    real    dist,gx,gy;
    int     Imax,i,p,q,n=img->ncols*img->nrows;
    Pixel   u,v;
    AdjRel *A=Circular(1.5);
    Image  *grad=CreateImage(img->ncols,img->nrows);
    FeatMap *fmap;
    real *fv_p,*fv_q,*fv;
    int nfeatures = rsize;
    real *md=AllocRealArray(A->n);
    GQueue *Q=NULL;
    int cst,weight,nv,r;
    Image *cost=CreateImage(img->ncols,img->nrows);
    Imax = MaximumValue(img);
    Set *pts=NULL;

    /* normalize and make other initializations for the local IFT and
       feature computation */

    SetImage(cost, INT_MAX);
    fmap = CreateFeatMap(n, nfeatures);
    Q = CreateGQueue(Imax+1,n,cost->val);

    for (i=0; i<A->n; i++)
        md[i]=sqrt(A->dx[i]*A->dx[i]+A->dy[i]*A->dy[i]);

    /* Compute local IFTs */

    for (r=0; r < n; r++)
    {
        nv=0;
        cost->val[r]=0;
        InsertGQueue(&Q,r);
        InsertSet(&pts,r);

        while (!EmptyGQueue(Q))
        {
            p=RemoveGQueue(Q);

            /* compute features */
            if (nv < rsize)
            {
                fv = fmap->data[r];
                fv[nv] = (real)img->val[p]/(real)Imax;
            }
            else
            {
                /* normalize feature vectors */
                break;
            }
            nv++;

            u.x = p%img->ncols;
            u.y = p/img->ncols;

            for (i=1; i < A->n; i++)
            {
                v.x = u.x + A->dx[i];
                v.y = u.y + A->dy[i];
                if (ValidPixel(img,v.x,v.y))
                {
                    q = v.x + img->tbrow[v.y];
                    if (Q->L.elem[q].color != BLACK)
                    {
                        weight = fabs(img->val[q] - img->val[r]);
                        cst = (cost->val[p]+weight);
                        if (cst < cost->val[q])
                        {
                            if (Q->L.elem[q].color == GRAY)
                                RemoveGQueueElem(Q,q);
                            cost->val[q]  = cst;
                            InsertGQueue(&Q,q);
                            InsertSet(&pts,q);
                        }
                    }
                }
            }
        }

        /* Reset queue manually */
        Q->C.minvalue = INT_MAX;
        Q->C.maxvalue = INT_MIN;
        for (i=0; i < Q->C.nbuckets+1; i++)
            Q->C.first[i]=Q->C.last[i]=NIL;
        while (pts != NULL)
        {
            p=RemoveSet(&pts);
            Q->L.elem[p].next  =  Q->L.elem[p].prev = NIL;
            Q->L.elem[p].color = WHITE;
            cost->val[p]=INT_MAX;
        }
    }

    DestroyGQueue(&Q);
    DestroyImage(&cost);

    for (p=0; p < n; p++)
    {
        u.x = p%img->ncols;
        u.y = p/img->ncols;

        gx = gy = 0.0;
        for (i=1; i < A->n; i++)
        {
            v.x = u.x + A->dx[i];
            v.y = u.y + A->dy[i];
            if (ValidPixel(img,v.x,v.y))
            {
                q    = v.x + img->tbrow[v.y];
                fv_p = fmap->data[p];
                fv_q = fmap->data[q];
                dist = DistanceSub(fv_p, fv_q, nfeatures);
                gx  += dist*A->dx[i]/md[i];
                gy  += dist*A->dy[i]/md[i];
            }
        }
        grad->val[p]=(int)(MAXDENS*sqrt(gx*gx + gy*gy));
    }

    DestroyFeatMap(&fmap);
    DestroyAdjRel(&A);
    free(md);

    return(grad);
}


Image *TextGradient(Image *img,float radius)
{
    real    dist,gx,gy;
    int     Imax,i,p,q,n=img->ncols*img->nrows;
    Pixel   u,v;
    AdjRel *A=Circular(radius),*A8=Circular(1.5);
    real   *md=AllocRealArray(A8->n);
    Image  *grad=CreateImage(img->ncols,img->nrows);
    FeatMap *fmap;
    real *fv_p,*fv_q;

    Imax = MaximumValue(img);
    fmap = CreateFeatMap(n, A->n);

    for (u.y=0; u.y < img->nrows; u.y++)
        for (u.x=0; u.x < img->ncols; u.x++)
        {
            p = u.x + img->tbrow[u.y];
            for (i=0; i < A->n; i++)
            {
                v.x = u.x + A->dx[i];
                v.y = u.y + A->dy[i];
                if (ValidPixel(img,v.x,v.y))
                {
                    q  = v.x + img->tbrow[v.y];
                    fv_p = fmap->data[p];
                    fv_p[i]=(real)img->val[q]/(real)Imax;
                }
            }
        }

    for (i=0; i < A8->n; i++)
        md[i]=sqrt(A8->dx[i]*A8->dx[i]+A8->dy[i]*A8->dy[i]);

    for (p=0; p < n; p++)
    {
        u.x = p%img->ncols;
        u.y = p/img->ncols;

        gx = gy = 0.0;

        for (i=1; i < A8->n; i++)
        {
            v.x = u.x + A8->dx[i];
            v.y = u.y + A8->dy[i];
            if (ValidPixel(img,v.x,v.y))
            {
                q    = v.x + img->tbrow[v.y];
                fv_p = fmap->data[p];
                fv_q = fmap->data[q];
                dist = DistanceSub(fv_p, fv_q, A->n);
                gx  += dist*A8->dx[i]/md[i];
                gy  += dist*A8->dy[i]/md[i];
            }
        }
        grad->val[p]=(int)(MAXDENS*sqrt(gx*gx + gy*gy));
    }

    free(md);
    DestroyAdjRel(&A);
    DestroyAdjRel(&A8);
    DestroyFeatMap(&fmap);

    return(grad);
}


Image *ImageGradient(Image *img,float radius)
{
    real    dist,gx,gy;
    int     Imax,i,p,q,n=img->ncols*img->nrows;
    Pixel   u,v;
    AdjRel *A=Circular(radius);
    real   *md=AllocRealArray(A->n);
    Image  *grad=CreateImage(img->ncols,img->nrows);

    Imax = MaximumValue(img)+1;

    for (i=0; i < A->n; i++)
        md[i]=sqrt(A->dx[i]*A->dx[i]+A->dy[i]*A->dy[i]);

    for (p=0; p < n; p++)
    {
        u.x = p%img->ncols;
        u.y = p/img->ncols;

        gx = gy = 0.0;

        for (i=1; i < A->n; i++)
        {
            v.x = u.x + A->dx[i];
            v.y = u.y + A->dy[i];
            if (ValidPixel(img,v.x,v.y))
            {
                q    = v.x + img->tbrow[v.y];
                dist = ((float)img->val[q]-(float)img->val[p])/(float)Imax;
                gx  += dist*A->dx[i]/md[i];
                gy  += dist*A->dy[i]/md[i];
            }
        }
        grad->val[p]=(int)(MAXDENS*sqrt(gx*gx + gy*gy));
    }

    free(md);
    DestroyAdjRel(&A);

    return(grad);
}

Features *VImageGradient(Image *img,float radius, int frame)
{
    real    dist,gx,gy;
    int     i,p,q,n=img->ncols*img->nrows;
    Pixel   u,v;
    AdjRel *A=Circular(radius);
    real   *md=AllocRealArray(A->n);
    Features *grad=(Features *)calloc(1,sizeof(Features));


    grad->Imax   = MaximumValue(img)+1;
    grad->ncols  = img->ncols;
    grad->nrows  = img->nrows;
    grad->nelems = img->ncols*img->nrows;
    grad->elem   = (FElem *)calloc(grad->nelems,sizeof(FElem));
    for (i=0; i < grad->nelems; i++)
    {
        grad->elem[i].feat = AllocFloatArray(3);
    }
    grad->nfeats       = 3;

    for (i=1; i < A->n; i++)
        md[i]=sqrt(A->dx[i]*A->dx[i]+A->dy[i]*A->dy[i]);

    for (p=0; p < n; p++)
    {
        u.x = p%img->ncols;
        u.y = p/img->ncols;

        gx = gy = 0.0;

        for (i=1; i < A->n; i++)
        {
            v.x = u.x + A->dx[i];
            v.y = u.y + A->dy[i];
            if (ValidPixel(img,v.x,v.y))
            {
                q    = v.x + img->tbrow[v.y];
                dist = ((float)img->val[q]-(float)img->val[p])/(float)grad->Imax;
                gx  += dist*A->dx[i]/md[i];
                gy  += dist*A->dy[i]/md[i];
            }
        }
        grad->elem[p].feat[0]=gx;
        grad->elem[p].feat[1]=gy;
        grad->elem[p].feat[2]=sqrt(gx*gx + gy*gy);
    }

//    DImage* dimg = GetFeature(grad, 2);
//    Image* img1 = ConvertDImage2Image(dimg);
//    char name[100];
//    sprintf(name,"objgrad_frame_%02d.pgm",frame);
//    WriteImage(img1,name);
//    DestroyDImage(&dimg);
//    DestroyImage(&img1);

    free(md);
    DestroyAdjRel(&A);

    return(grad);
}

Features *VFeaturesGradient(Features *f,float radius)
{
    real    dist,gx,gy,mag;
    int     j,i,p,q,n=f->ncols*f->nrows;
    Pixel   u,v;
    AdjRel *A=Circular(radius);
    real   *md=AllocRealArray(A->n);
    Features *grad=(Features *)calloc(1,sizeof(Features));

    grad->Imax   = f->Imax;
    grad->ncols  = f->ncols;
    grad->nrows  = f->nrows;
    grad->nelems = f->ncols*f->nrows;
    grad->elem   = (FElem *)calloc(grad->nelems,sizeof(FElem));
    for (i=0; i < grad->nelems; i++)
    {
        grad->elem[i].feat = AllocFloatArray(3);
    }

//    DImage* dimg[f->nfeats];
//    DImage *featgrad = CreateDImage(f->ncols, f->nrows);
//
//    for(i = 0; i < f->nfeats; i++) dimg[i] = CreateDImage(f->ncols, f->nrows);

    for (i=1; i < A->n; i++)
        md[i]=sqrt(A->dx[i]*A->dx[i]+A->dy[i]*A->dy[i]);

    for (p=0; p < n; p++)
    {
        u.x = p%f->ncols;
        u.y = p/f->ncols;

        grad->elem[p].feat[2] = 0.0;

        for (j=0; j<f->nfeats; j++)
        {
            gx = gy = 0.0;
            for (i=1; i < A->n; i++)
            {
                v.x = u.x + A->dx[i];
                v.y = u.y + A->dy[i];
                if ((v.x>=0 && v.x<f->ncols) && (v.y>=0 && v.y<f->nrows))
                {
                    q    = v.x + v.y*f->ncols;
                    dist = (f->elem[q].feat[j]-f->elem[p].feat[j]);
                    gx  += dist*A->dx[i]/md[i];
                    gy  += dist*A->dy[i]/md[i];
                }
            }
            mag = sqrt(gx*gx + gy*gy);
//            dimg[j]->val[p] = mag;
            if (mag > grad->elem[p].feat[2])
            {
                grad->elem[p].feat[0]=gx;
                grad->elem[p].feat[1]=gy;
                grad->elem[p].feat[2]=mag;
//                featgrad->val[p] = mag;
            }
        }
    }
//    Image* featgradimg = ConvertDImage2Image(featgrad);
//    WriteImage(featgradimg,"featgrad.pgm");
//    DestroyDImage(&featgrad);
//    DestroyImage(&featgradimg);

//    for(j = 0; j < f->nfeats; j++)
//    {
//        DImage* dimg1 = GetFeature(f, j);
//        Image* img = ConvertDImage2Image(dimg1);
//        char name[100];
//        sprintf(name,"feat_%02d.pgm",j);
//        WriteImage(img, name);
//        DestroyImage(&img);
//        DestroyDImage(&dimg1);
//        img = ConvertDImage2Image(dimg[j]);
//        sprintf(name,"grad_feat_%02d.pgm",j);
//        WriteImage(img,name);
//        DestroyDImage(&(dimg[j]));
//        DestroyImage(&img);
//    }

    free(md);
    DestroyAdjRel(&A);

    return(grad);
}


Image *VMaxEdgeGradient(Features* feat, Image *objMap, float Wobj, float radius)
{
    Image *img = CreateImage(feat->ncols, feat->nrows);
    int     i,p,q,n=img->ncols*img->nrows;
    Pixel   u,v;
    AdjRel *A=Circular(radius);
    real   *md=AllocRealArray(A->n);

    for (i=1; i < A->n; i++)
        md[i]=sqrt(A->dx[i]*A->dx[i]+A->dy[i]*A->dy[i]);

    for (p=0; p < n; p++)
    {
        u.x = p%img->ncols;
        u.y = p/img->ncols;

        float max_edge = FLT_MIN;

        for (i=1; i < A->n; i++)
        {
            v.x = u.x + A->dx[i];
            v.y = u.y + A->dy[i];
            q = v.x + v.y*img->ncols;
            if (ValidPixel(img,v.x,v.y))
            {
                const float featdist = sqrtf(EuclDist(feat->elem[p].feat, feat->elem[q].feat, feat->nfeats))*MAXDENS;

                const float mapdist = (float)labs(objMap->val[p] - objMap->val[q]);

                const float weight = (Wobj*mapdist + (1-Wobj)*featdist)/md[i];
                max_edge = MAX(max_edge, weight);
            }
        }
        img->val[p] = (int)max_edge;
    }

    free(md);
    DestroyAdjRel(&A);

    return img;
}

Features *BFeaturesGradient(Features *f, int nbands, int nscales, float radius)
{
    real    dist,gx,gy;
    int     j,i,p,q,n=f->ncols*f->nrows;
    Pixel   u,v;
    AdjRel *A=Circular(radius);
    real   *md=AllocRealArray(A->n);
    Features *grad=(Features *)calloc(1,sizeof(Features));

    grad->Imax   = f->Imax;
    grad->ncols  = f->ncols;
    grad->nrows  = f->nrows;
    grad->nelems = f->ncols*f->nrows;
    grad->elem   = (FElem *)calloc(grad->nelems,sizeof(FElem));
    for (i=0; i < grad->nelems; i++)
    {
        grad->elem[i].feat = AllocFloatArray(2*nbands);
    }
    grad->nfeats = 2*nbands;

    for (i=1; i < A->n; i++)
        md[i]=sqrt(A->dx[i]*A->dx[i]+A->dy[i]*A->dy[i]);

    real band_xgrad[nbands];
    real band_ygrad[nbands];

    for (p=0; p < n; p++)
    {
        u.x = p%f->ncols;
        u.y = p/f->ncols;

        gx = gy = 0.0;

        int k;
        for (k = 0; k < nbands; k++)
        {
            band_xgrad[k] = 0.0;
            band_ygrad[k] = 0.0;
        }

        for (i=1; i < A->n; i++)
        {
            v.x = u.x + A->dx[i];
            v.y = u.y + A->dy[i];
            if ((v.x>=0 && v.x<f->ncols) && (v.y>=0 && v.y<f->nrows))
            {
                q    = v.x + v.y*f->ncols;

                for (j=0; j<f->nfeats; j++)
                {
                    dist = (f->elem[q].feat[j]-f->elem[p].feat[j]);
                    ///(float)grad->Imax;

                    int t = (int)floorf((float)j/(float)(nscales));

                    band_xgrad[t]  += dist*A->dx[i]/md[i];
                    band_ygrad[t]  += dist*A->dy[i]/md[i];

                }
            }
        }

        for (k = 0; k < 2*nbands; k+=2)
        {
            grad->elem[p].feat[k] = MAXDENS*band_xgrad[k/2];
            grad->elem[p].feat[k+1] = MAXDENS*band_ygrad[k/2];
        }
    }

    free(md);
    DestroyAdjRel(&A);

    return(grad);
}

Image *ColorDistGradient(CImage *cimg)
{
    double   dist,gx,gy;
    int     color1, color2;
    int     i,p,q,n;
    Pixel   u,v;
    AdjRel  *A8=Circular(1.5);
    double  *md=AllocDoubleArray(A8->n);
    Image  *grad=CreateImage(cimg->C[0]->ncols,cimg->C[0]->nrows);
    n=grad->ncols*grad->nrows;
    for (i=0; i < A8->n; i++)
        md[i]=sqrt(A8->dx[i]*A8->dx[i]+A8->dy[i]*A8->dy[i]);

    for (p=0; p < n; p++)
    {
        u.x = p%cimg->C[0]->ncols;
        u.y = p/cimg->C[0]->ncols;

        gx = gy = 0.0;

        for (i=1; i < A8->n; i++)
        {
            v.x = u.x + A8->dx[i];
            v.y = u.y + A8->dy[i];
            if (ValidPixel(cimg->C[0],v.x,v.y))
            {
                q    = v.x + cimg->C[0]->tbrow[v.y];
                color1 = triplet(cimg->C[0]->val[p],\
                                 cimg->C[1]->val[p],\
                                 cimg->C[2]->val[p]);
                color2 = triplet(cimg->C[0]->val[q],\
                                 cimg->C[1]->val[q],\
                                 cimg->C[2]->val[q]);
                dist = ColorDistance2(color1, color2);
                gx  += dist*A8->dx[i]/md[i];
                gy  += dist*A8->dy[i]/md[i];
            }
        }
        grad->val[p]=(int)(255.0*sqrt(gx*gx + gy*gy));
    }


    free(md);
    DestroyAdjRel(&A8);
    return(grad);
}

Image *FeatObjVGrads2Image(Features *Gfeat, Features *Gobj, int* Wmax, float Wobj)
{
    int p,n,ncols,nrows;
    int weight;

    ncols     = Gfeat->ncols;
    nrows     = Gfeat->nrows;
    n         = ncols*nrows;

    *Wmax = FLT_MIN;

    Image* img = CreateImage(ncols, nrows);

    for (p=0; p<n; p++)
    {

        weight = ROUND(MAXDENS*(Wobj*Gobj->elem[p].feat[2]+(1.0-Wobj)*Gfeat->elem[p].feat[2]));
        img->val[p] = weight;

        *Wmax = MAX(*Wmax, weight);
    }

    return img;
}

/** Video **/



Features *VImageGradientBB(Image *img,float radius, int xmin, int ymin, int xmax, int ymax)
{
    real    dist,gx,gy;
    int     i,p,q,n=img->ncols*img->nrows, x, y;
    Pixel   u,v;
    AdjRel *A=Circular(radius);
    real   *md=AllocRealArray(A->n);
    Features *grad=(Features *)calloc(1,sizeof(Features));


    grad->Imax   = MaximumValue(img)+1;
    grad->ncols  = img->ncols;
    grad->nrows  = img->nrows;
    grad->nelems = img->ncols*img->nrows;
    grad->elem   = (FElem *)calloc(grad->nelems,sizeof(FElem));
    for (i=0; i < grad->nelems; i++)
    {
        grad->elem[i].feat = AllocFloatArray(3);
    }
    grad->nfeats       = 3;

    for (i=1; i < A->n; i++)
        md[i]=sqrt(A->dx[i]*A->dx[i]+A->dy[i]*A->dy[i]);

    for (y = ymin; y < ymax; y++)
    {
        for (x = xmin; x < xmax; x++)
        {
            p = img->tbrow[y] + x;
            u.x = x;
            u.y = y;

            gx = gy = 0.0;

            for (i=1; i < A->n; i++)
            {
                v.x = u.x + A->dx[i];
                v.y = u.y + A->dy[i];
                if (ValidPixel(img,v.x,v.y))
                {
                    q    = v.x + img->tbrow[v.y];
                    dist = ((float)img->val[q]-(float)img->val[p])/(float)grad->Imax;
                    gx  += dist*A->dx[i]/md[i];
                    gy  += dist*A->dy[i]/md[i];
                }
            }
            grad->elem[p].feat[0]=gx;
            grad->elem[p].feat[1]=gy;
            grad->elem[p].feat[2]=sqrt(gx*gx + gy*gy);
        }
    }
    free(md);
    DestroyAdjRel(&A);

    return(grad);
}

Features *VFeaturesGradientBB(Features *f,float radius, int xmin, int ymin, int xmax, int ymax)
{
    real    dist,gx,gy,mag;
    int     j,i,p,q,n=f->ncols*f->nrows,x,y;
    Pixel   u,v;
    AdjRel *A=Circular(radius);
    real   *md=AllocRealArray(A->n);
    Features *grad=(Features *)calloc(1,sizeof(Features));

    grad->Imax   = f->Imax;
    grad->ncols  = f->ncols;
    grad->nrows  = f->nrows;
    grad->nelems = f->ncols*f->nrows;
    grad->elem   = (FElem *)calloc(grad->nelems,sizeof(FElem));
    for (i=0; i < grad->nelems; i++)
    {
        grad->elem[i].feat = AllocFloatArray(3);
    }
    grad->nfeats = 3;

    for (i=1; i < A->n; i++)
        md[i]=sqrt(A->dx[i]*A->dx[i]+A->dy[i]*A->dy[i]);

    for (y = ymin; y < ymax; y++)
    {
        for (x = xmin; x < xmax; x++)
        {
            p = y*f->ncols + x;
            u.x = x;
            u.y = y;

            grad->elem[p].feat[2] = 0.0;

            for (j=0; j<f->nfeats; j++)
            {
                gx = gy = 0.0;
                for (i=1; i < A->n; i++)
                {
                    v.x = u.x + A->dx[i];
                    v.y = u.y + A->dy[i];
                    if ((v.x>=0 && v.x<f->ncols) && (v.y>=0 && v.y<f->nrows))
                    {
                        q    = v.x + v.y*f->ncols;
                        dist = (f->elem[q].feat[j]-f->elem[p].feat[j]);
                        gx  += dist*A->dx[i]/md[i];
                        gy  += dist*A->dy[i]/md[i];
                    }
                }
                mag = sqrt(gx*gx + gy*gy);
                if (mag > grad->elem[p].feat[2])
                {
                    grad->elem[p].feat[0]=gx;
                    grad->elem[p].feat[1]=gy;
                    grad->elem[p].feat[2]=mag;
                }
            }
        }
    }

    free(md);
    DestroyAdjRel(&A);

    return(grad);
}

Image *FeatObjVGrads2ImageBB(Features *Gfeat, Features *Gobj, int* Wmax, float Wobj, int xmin, int ymin, int xmax, int ymax)
{
    int p,n,ncols,nrows,x,y;
    int weight;

    ncols     = Gfeat->ncols;
    nrows     = Gfeat->nrows;
    n         = ncols*nrows;

    *Wmax = FLT_MIN;

    Image* img = CreateImage(ncols, nrows);

    for (y = ymin; y < ymax; y++)
    {
        for (x = xmin; x < xmax; x++)
        {
            p = y*Gfeat->ncols + x;

            weight = ROUND(MAXDENS*(Wobj*Gobj->elem[p].feat[2]+(1.0-Wobj)*Gfeat->elem[p].feat[2]));
            img->val[p] = weight;

            *Wmax = MAX(*Wmax, weight);
        }
    }

    return img;
}
