
#include "featmap.h"


FeatMap *CreateFeatMap(int n, int nfeat){
  FeatMap *fmap;
  int p;

  fmap = (FeatMap *)calloc(1, sizeof(FeatMap));
  if(fmap == NULL)
    Error(MSG1,"CreateFeatMap");
  fmap->n = n;
  fmap->nfeat = nfeat;

  fmap->data = (real **)calloc(n, sizeof(real *));
  if(fmap->data == NULL)
    Error(MSG1,"CreateFeatMap");
  for(p=0; p<n; p++){
    fmap->data[p] = (real *)calloc(nfeat, sizeof(real));
    if(fmap->data[p] == NULL)
      Error(MSG1,"CreateFeatMap");
  }
  return fmap;
}


void    DestroyFeatMap(FeatMap **fmap){
  FeatMap *aux;
  int p;

  aux = *fmap;
  if(aux != NULL){
    if(aux->data != NULL){
      for(p=0; p<aux->n; p++)
	free((aux->data)[p]);
      free(aux->data);
    }
    free(aux);
    *fmap = NULL;
  }
}


FeatMap *Image2FeatMapByMaxMinVal(Image *img, float radius){
  FeatMap *fmap;
  AdjRel *A=Circular(radius);
  Pixel u,v;
  real *fv;
  int n,p,q,i,val,min,max;
  int ncols,nrows;

  ncols = img->ncols;
  nrows = img->nrows;
  n = ncols*nrows;
  fmap = CreateFeatMap(n, 3);

  for(p=0; p<n; p++){
    u.x = p%ncols;
    u.y = p/ncols;

    min = INT_MAX;
    max = INT_MIN;
    for(i=1; i<A->n; i++){
      v.x = u.x + A->dx[i];
      v.y = u.y + A->dy[i];

      if(ValidPixel(img, v.x, v.y)){
	q = v.x + img->tbrow[v.y];
	val = img->val[q];
	if(val<min) min = val;
	if(val>max) max = val;
      }
    }
    val = img->val[p];
    fv  = fmap->data[p];
    fv[0] = (real)val;
    fv[1] = (real)min;
    fv[2] = (real)max;
  }
  DestroyAdjRel(&A);

  return fmap;
}


FeatMap *CImage2FeatMap(CImage *cimg){
  FeatMap *fmap;
  real *fv;
  int ncols,nrows;
  int n,p;

  ncols = cimg->C[0]->ncols;
  nrows = cimg->C[0]->nrows;
  n = ncols*nrows;
  fmap = CreateFeatMap(n, 3);

  for(p=0; p<n; p++){
    fv = fmap->data[p];
    fv[0] = (real)cimg->C[0]->val[p];
    fv[1] = (real)cimg->C[1]->val[p];
    fv[2] = (real)cimg->C[2]->val[p];
  }

  return fmap;
}


//----- Distance Functions -----------------

inline real DistanceSub(real *fv1, real *fv2, int nfeat){
  real d=0.0;
  int i;

  for(i=0; i<nfeat; i++)
    d += fv2[i] - fv1[i];
  d /= nfeat;
  
  return d;
}


inline real DistanceL1(real *fv1, real *fv2, int nfeat){
  real d=0.0, aux;
  int i;

  for(i=0; i<nfeat; i++){
    aux = fv1[i] - fv2[i];
    if(aux<0)
      d += -aux;
    else
      d += aux;
  }

  return d;
}


inline real DistanceL2(real *fv1, real *fv2, int nfeat){
  real aux, d=0.0;
  int i;

  for(i=0; i<nfeat; i++){
    aux = fv1[i] - fv2[i];
    d += aux*aux;
  }

  return sqrtreal(d);
}



inline real DistanceGRAD(real *fv1, real *fv2, int nfeat){
  real d=0.0;
  int i;

  for(i=0; i<nfeat; i++)
    d += fv1[i]+fv2[i];
  d /= (2.0*nfeat);

  return d;
}



