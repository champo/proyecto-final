#include "lab.h"

static float e = 0.008856;
static float k = 903.3;

float calculaF(float n)
{
    if (n > e)
    {
        return(cbrtf(n));
    }
    else
    {
        return(( (k* n) +16  )/116);
    }
}

/** Replaces the value of *R, *G and *B with values of X, Y, and Z (CIE)**/
void PixelRGB2XYZ(float* R, float* G, float* B)
{
    //*********** RGB para XYZ************//
    /************* Definition************
    [ X Y Z ] = [ r g b] * [M]
    [M] =  0.488718    0.176204    0.000000
           0.310680    0.812985    0.0102048  // CIE matriz com white referece E
                   0.200602     0.0108109  0.989795
    r = R ^y
    g = G ^y
    b = B ^y
    onde y = 2.2 gamma
    */

    // 1. Estandarizar RGB entre 0 e 1
    float R0 = *R / 255.0;
    float G0 = *G / 255.0;
    float B0 = *B / 255.0;
    //printf(" R0 = %f   G0 = %f  B0  = %f \n",R0,G0,B0);

    // 2. RGB elevado a gamma
    float r = pow(R0,2.2);
    float g = pow(G0,2.2);
    float b = pow(B0,2.2);

    // 3. Achando o valor de XYZ
    *R = r * 0.488718 + g * 0.310680 + b * 0.200602;  /// X
    *G = r * 0.176204 + g * 0.812985 + b * 0.0108109; /// Y
    *B = r * 0.000000 + g * 0.0102048 + b * 0.989795; /// Z


}

/** Replaces the value of *X, *Y and *Z with values of R, G, and B **/
void PixelXYZ2RGB(float* X, float* Y, float* Z)
{
    /**************** Definition************
       http://www.brucelindbloom.com/index.html?Eqn_RGB_XYZ_Matrix.html
       (as outras formulas estao tb la)
     [ r g b] = [ X Y Z ] * [M]-1

    [M]-1 =   2.37067    -0.513885    0.00529818
                     -0.900040    1.42530    -0.0146949  // CIE matriz com white referece E
                     -0.470634     0.0885814  1.00940
    R = r ^1/y
    G = g ^1/y
    B = b ^1/y

    onde y = 2.2 gamma
    */

    float r1 = *X * 2.3706726   + *Y * -0.9000386  + *Z * -0.4706343;
    float g1 = *X * -0.5138831  + *Y *  1.4253021  + *Z *  0.0885812;
    float b1 = *X * 0.0052981   + *Y * -0.0146949  + *Z *  1.0093969;

    float Rb = pow(r1,(1.0/2.2)); ///R
    float Gb = pow(g1,(1.0/2.2)); ///G
    float Bb = pow(b1,(1.0/2.2)); ///B

    *X = Rb*255;
    *Y = Gb*255;
    *Z = Bb*255;
}

/** Replaces the value of *X, *Y and *Z with values of L, a, and b **/
void PixelXYZ2Lab(float* X, float* Y, float* Z)
{
    /**************** Definition***************
    Referencial de iluminação
    E  	X: 1.00000  	Y: 1.00000  	Z:1.00000
    Xr = Yr = Zr = 1.00000

    L = 116 fx - 16;
    a = 500(fx - fy);
    b = 200(fy - fz);
    onde :
    fx = raiz3(xr) se xr > e
    fx = (kxr + 16)/116 se xr <= e

    fy = raiz3(yr) se yr > e
    fy = (kyr + 16)/116 se yr <= e

    fz = raiz3(zr) se zr > e
    fx = (kzr + 16)/116 se zr <= e

    xr = X/Xr;
    yr = Y/Yr;
    zr = Z/zR;

    e = 0.008856
    k = 903.3
    */

    float Xr;
    float Yr;
    float Zr;
    Xr = Yr = Zr  = 1.00000; // white reference E

    float xr = *X / Xr;
    float yr = *Y / Yr;
    float zr = *Z / Zr;

    *X =  (116.0 * calculaF(yr)) -16.0;               /// L
    *Y =  (500.0 * ( calculaF(xr) - calculaF(yr) ) ); /// a
    *Z = (200.0 * ( calculaF(yr) - calculaF(zr) ) );  /// b

}

void PixelLab2XYZ(float *L, float *a, float *b)
{

    //***************Lab para XYZ - validacao*********************//
    /***********************Definition****************
    X = xr * Xr
    Y = yr * Yr
    Z = zr * Zr

    xr = fx^3 se fx^3 > e
    xr = (116fx - 16) /k se fx^3 <= e

    yr = ((L + 16)/116)^3 se L > ke
    yr = L/k              se L <= ke

    zr = fz ^ 3         se fz ^ 3 > e
    zr = (116fz - 16)/k se fz ^ 3 <= e

    fx = (a /500 ) + fy
    fz = fy -(b / 200);

    fy = (L + 16)/116 se yr > e
    fy = (kyr + 16)/116  yr < 116
    */

    float X = *L, Y = *a, Z = *b;
    float Xr;
    float Yr;
    float Zr;
    Xr = Yr = Zr  = 1.00000; // white reference E

    float xr = X / Xr;
    float yr = Y / Yr;
    float zr = Z / Zr;

    // calculo de yr
    if (*L > k * e)
    {
        yr = pow( ((*L + 16.0)/116.0)  ,3.0);
    }
    else
    {
        yr = *L / k;
    }

    //se fz ^ 3 > e
    // se fz ^ 3 <= e
    float fy;
    if (yr > e)
    {
        fy = (*L + 16.0) / 116.0;
    }
    else
    {
        fy = ((k * yr) + 16.0) / 116.0;
    }

    // calculo de fx
    float fx;
    fx = (*a / 500.0) + fy;

    //calculo de xr
    if (pow(fx,3.0) > e)
    {
        xr = pow(fx,3.0);
    }
    else
    {
        //xr = (116fx - 16) /k se fx^3 <= e
        xr =  ( (116.0 * fx) - 16.0) / k;
    }

    // valor de X
    X = xr * Xr;

    //calculo de yr
    if (*L > (k * e))
    {
        //yr = ((L + 16)/116)^3 se L > ke
        yr = pow(  (*L + 16.0)/ 116.0   ,3.0);		// yr = L/k             se L <= ke

    }
    else
    {
        yr = *L / k;
    }

    Y = yr * Yr;

    //calculo de fz
    float fz;
    fz = fy - (*b / 200.0) ;

    if (pow(fz,3.0) > e)
    {
        zr = pow(fz,3.0);
    }
    else
    {
        //zr = fz ^ 3         se fz ^ 3 > e
        zr = ( (116.0 * fz) - 16.0)/k;                   //zr = (116fz - 16)/k se fz ^ 3 <= e
    }

    Z = zr * Zr;

    *L = X;
    *a = Y;
    *b = Z;

}

#ifndef CLAMP
#define CLAMP(x,l,u) ((x)<(l)?(l):((x)>(u)?(u):(x)))
#endif

CImage* gimp_extract_lab (CImage  *src)
{
    register int count = src->C[0]->ncols*src->C[0]->nrows;

    CImage* dst = CreateCImage(src->C[0]->ncols,src->C[0]->nrows);

    double red, green, blue;
    double x, y, z;
    double l; /*, a, b; */
    double tx, ty, tz;
    double ftx, fty, ftz;

    double sixteenth = 16.0 / 116.0;

    /* LAB colorspace constants */
#define LAB_Xn 0.951
#define LAB_Yn 1.0
#define LAB_Zn 1.089

    register int i;

    for (i = 0; i < count; i++)
    {
        red   = src->C[0]->val[i] / 255.0;
        green = src->C[1]->val[i] / 255.0;
        blue  = src->C[2]->val[i] / 255.0;

        fprintf(stderr,"r %f g %f b %f\n",red,green,blue);

        x = 0.431 * red + 0.342 * green + 0.178 * blue;
        y = 0.222 * red + 0.707 * green + 0.071 * blue;
        z = 0.020 * red + 0.130 * green + 0.939 * blue;

        if ((ty = y / LAB_Yn) > 0.008856)
        {
            l   = 116.0 * cbrt (ty) - 16.0;
            fty = cbrt (ty);
        }
        else
        {
            l   = 903.3  * ty;
            fty =   7.78 * ty + sixteenth;
        }

        ftx = ((tx = x / LAB_Xn) > 0.008856) ? cbrt (tx) : 7.78 * tx + sixteenth;
        ftz = ((tz = z / LAB_Zn) > 0.008856) ? cbrt (tz) : 7.78 * tz + sixteenth;

        dst->C[0]->val[i] = (unsigned char) CLAMP (l * 2.5599, 0., 256.);
        dst->C[1]->val[i] = (unsigned char) CLAMP (128.0 + (ftx - fty) * 635, 0., 256.);
        dst->C[2]->val[i] = (unsigned char) CLAMP (128.0 + (fty - ftz) * 254, 0., 256.);
    }
    WriteImage(dst->C[0],"lgimp.pgm");

    WriteImage(dst->C[1],"agimp.pgm");
    WriteImage(dst->C[2],"bgimp.pgm");
    return dst;
}

