
#include "preproc.h"


Parameters *CreateParameters(int ncols, int nrows){
  Parameters *par=(Parameters *)calloc(1,sizeof(Parameters));
  
  par->Sx  = CreateRealMatrix(ncols,nrows);
  par->Sy  = CreateRealMatrix(ncols,nrows);
  par->Sz  = CreateRealMatrix(ncols,nrows);
  par->Sxy = CreateRealMatrix(ncols,nrows);
  par->Sxz = CreateRealMatrix(ncols,nrows);
  par->Syz = CreateRealMatrix(ncols,nrows);
  par->Sx2 = CreateRealMatrix(ncols,nrows);
  par->Sy2 = CreateRealMatrix(ncols,nrows);
  par->Sz2 = CreateRealMatrix(ncols,nrows);
  par->n   = CreateImage(ncols,nrows);
  return(par);
}

void DestroyParameters(Parameters **par){
  if (*par != NULL) {
    DestroyRealMatrix(&((*par)->Sx));
    DestroyRealMatrix(&((*par)->Sy));
    DestroyRealMatrix(&((*par)->Sz));
    DestroyRealMatrix(&((*par)->Sxy));
    DestroyRealMatrix(&((*par)->Sxz));
    DestroyRealMatrix(&((*par)->Syz));
    DestroyRealMatrix(&((*par)->Sx2));
    DestroyRealMatrix(&((*par)->Sy2));
    DestroyRealMatrix(&((*par)->Sz2));
    DestroyImage(&((*par)->n));
    free(*par);
    *par = NULL;
  }
}


void UpdateParameters(Parameters *par, int root, double *v){
  par->Sx->val[0][root]  += v[0];
  par->Sy->val[0][root]  += v[1];
  par->Sz->val[0][root]  += v[2];
  par->Sx2->val[0][root] += v[0]*v[0];
  par->Sy2->val[0][root] += v[1]*v[1];
  par->Sz2->val[0][root] += v[2]*v[2];
  par->Sxy->val[0][root] += v[0]*v[1];
  par->Sxz->val[0][root] += v[0]*v[2];
  par->Syz->val[0][root] += v[1]*v[2];
  par->n->val[root]++;
}

void CompStatistics(Parameters *par, int root, double *mean, double *covar){
  mean[0]  = par->Sx->val[0][root]/par->n->val[root];
  mean[1]  = par->Sy->val[0][root]/par->n->val[root];
  mean[2]  = par->Sz->val[0][root]/par->n->val[root];
  
  covar[0] = par->Sx2->val[0][root]/par->n->val[root] - mean[0]*mean[0]; 
  covar[4] = par->Sy2->val[0][root]/par->n->val[root] - mean[1]*mean[1]; 
  covar[8] = par->Sz2->val[0][root]/par->n->val[root] - mean[2]*mean[2];

  covar[1] = par->Sxy->val[0][root]/par->n->val[root] - mean[0]*mean[1]; 
  covar[2] = par->Sxz->val[0][root]/par->n->val[root] - mean[0]*mean[2]; 
  covar[5] = par->Syz->val[0][root]/par->n->val[root] - mean[1]*mean[2]; 
 
  covar[3] = covar[1];
  covar[6] = covar[2];
  covar[7] = covar[5];
}

void InvZNorm(double *covar, double *invZ){
  double detZ;
  int i,j;

  detZ = covar[0]*covar[4]*covar[8]+covar[1]*covar[5]*covar[6]+
    covar[2]*covar[3]*covar[7]-covar[2]*covar[4]*covar[6]-
    covar[0]*covar[5]*covar[7]-covar[1]*covar[3]*covar[8];

  //  printf("detZ %lf\n",detZ);

  invZ[0] = covar[4]*covar[8]-covar[5]*covar[7];
  invZ[1] = -(covar[3]*covar[8]-covar[5]*covar[6]);
  invZ[2] = covar[3]*covar[7]-covar[4]*covar[6];
  invZ[3] = -(covar[1]*covar[8]-covar[2]*covar[7]);
  invZ[4] = covar[0]*covar[8]-covar[2]*covar[6];
  invZ[5] = -(covar[0]*covar[7]-covar[1]*covar[6]);
  invZ[6] = covar[1]*covar[5]-covar[2]*covar[4];
  invZ[7] = -(covar[0]*covar[5]-covar[2]*covar[3]);
  invZ[8] = (covar[0]*covar[4]-covar[1]*covar[3]);
  
  if (detZ < 0.00001)
    for (j=0; j < 3; j++){ 
      for (i=0; i < 3; i++){
	invZ[i+j*3] /= detZ; 
	//printf("%lf ",invZ[i+j*3]);
      }
      //printf("\n");
    }else{
      invZ[0] = 1.0;
      invZ[4] = 1.0;
      invZ[8] = 1.0;
      invZ[1] = 0;
      invZ[2] = 0;
      invZ[3] = 0;
      invZ[5] = 0;
      invZ[6] = 0;
      invZ[7] = 0;
    }
}


double Mahalanobis(double *v, double *mean, double *invZ){
  double x[3];
  int i;

  for (i=0; i < 3; i++) 
    x[i] = (v[i]-mean[i]);

  return((invZ[0]*x[0]+invZ[3]*x[1]+invZ[6]*x[2])*x[0] +
    (invZ[1]*x[0]+invZ[4]*x[1]+invZ[7]*x[2])*x[1] +  
    (invZ[2]*x[0]+invZ[5]*x[1]+invZ[8]*x[2])*x[2]);
}


Image *StatisticalReconstruction(int ncols, int nrows,
				 FeatMap *fmap, Set *S){
  GQueue *Q=NULL;
  int i,p,q,n,cst,weight,Wmax=4095;
  Pixel u,v;
  AdjRel *A;  
  Image *cost,*root;
  Set *seeds;
  double mean[3],covar[9],pval[3],qval[3],invZ[9];
  Parameters *par;
  real *fv;
  BMap *bm;

  n = ncols*nrows;
  if(fmap->n != n)
    Error("Wrong image size","StatisticalReconstruction");
  if(fmap->nfeat != 3)
    Error("Current implementation only supports three features",
	  "StatisticalReconstruction");

  cost = CreateImage(ncols,nrows);
  root = CreateImage(ncols,nrows);
  bm   = BMapNew(n);
  Q    = CreateGQueue(Wmax+1,n,cost->val);

  A = Circular(1.5);
  par  = CreateParameters(ncols,nrows);
  for (p=0; p < n; p++) {
    root->val[p]  = p;
    cost->val[p]  = INT_MAX;
  }

  seeds = S;
  if(seeds != NULL)
    q = seeds->elem;
  while(seeds != NULL){
    p = seeds->elem;
    cost->val[p]  = 0;
    root->val[p]  = q;
    InsertGQueue(&Q,p);

    fv = fmap->data[p];
    pval[0]=(double)fv[0]/Wmax;
    pval[1]=(double)fv[1]/Wmax;
    pval[2]=(double)fv[2]/Wmax;
    UpdateParameters(par,root->val[p],pval);
    _fast_BMapSet1(bm,p);

    seeds = seeds->next;
  }

  while(!EmptyGQueue(Q)) {
    p=RemoveGQueue(Q);
    
    if(_fast_BMapGet(bm,p)==0){
      fv = fmap->data[p];
      pval[0]=(double)fv[0]/Wmax;
      pval[1]=(double)fv[1]/Wmax;
      pval[2]=(double)fv[2]/Wmax;
      UpdateParameters(par,root->val[p],pval);
    }
    CompStatistics(par,root->val[p],mean,covar);
    InvZNorm(covar, invZ);

    u.x = p%ncols;
    u.y = p/ncols;
    for (i=1; i < A->n; i++){
      v.x = u.x + A->dx[i];
      v.y = u.y + A->dy[i];
      if (ValidPixel(cost,v.x,v.y)){
	q = v.x + cost->tbrow[v.y];
	fv = fmap->data[q];
	qval[0]=(double)fv[0]/Wmax;
	qval[1]=(double)fv[1]/Wmax;
	qval[2]=(double)fv[2]/Wmax;
	
	weight = (int)(Wmax*(1.0-exp(-Mahalanobis(qval,mean,invZ)/20.0)));
	if (weight < 0) 
	  weight=0;
	else if (weight > Wmax)
	  weight = Wmax;
	
	cst = MAX(cost->val[p], weight);
	
	if (cst < cost->val[q]){	    
	  if (Q->L.elem[q].color == GRAY)
	    RemoveGQueueElem(Q,q);	    
	  cost->val[q]  = cst;
	  root->val[q]  = root->val[p];
	  InsertGQueue(&Q,q);
	}
      }
    }
  }
  
  DestroyParameters(&par);
  DestroyAdjRel(&A);
  DestroyGQueue(&Q);
  DestroyAdjRel(&A);
  DestroyImage(&root);
  BMapDestroy(bm);

  return(cost);
}
