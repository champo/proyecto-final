#include "sparsegraph.h"

int get_edge_index(int p, int q, SparseGraph *g)
{
    AdjRel *A;
    int ncols,dx,dy,i;

    A = g->A;
    ncols = g->ncols;
    dx = q%ncols - p%ncols;
    dy = q/ncols - p/ncols;

    for (i=1; i<A->n; i++)
    {
        if (dx == A->dx[i] && dy == A->dy[i])
            return i;
    }
    return -1;
}


SparseGraph   *CreateSparseGraph(int ncols, int nrows, AdjRel *A)
{
    SparseGraph *g;
    int p,n;

    n = ncols*nrows;
    g = (SparseGraph *)calloc(1, sizeof(SparseGraph));
    if (g == NULL)
        Error(MSG1,"CreateSparseGraph");
    g->A = A;
    g->ncols = ncols;
    g->nrows = nrows;
    g->n_link = (int **)calloc(n,sizeof(int *));
    if (g->n_link == NULL)
        Error(MSG1,"CreateSparseGraph");
    for (p=0; p<n; p++)
    {
        g->n_link[p] = AllocIntArray(A->n);
    }
    g->Wmax = 0;

    return g;
}

ExSparseGraph *CreateExSparseGraph(int ncols, int nrows, AdjRel *A)
{
    ExSparseGraph *eg;

    eg = (ExSparseGraph *)calloc(1, sizeof(ExSparseGraph));
    if (eg == NULL)
        Error(MSG1,"CreateExSparseGraph");
    eg->G = CreateSparseGraph(ncols, nrows, A);
    eg->t_link_S = CreateImage(ncols, nrows);
    eg->t_link_T = CreateImage(ncols, nrows);
    eg->Wmax = 0;

    return eg;
}


void    DestroySparseGraph(SparseGraph **g)
{
    SparseGraph *aux;
    int p,n;

    aux = *g;
    if (aux != NULL)
    {
        n = aux->ncols*aux->nrows;
        DestroyAdjRel(&(aux->A));
        for (p=0; p<n; p++)
        {
            free(aux->n_link[p]);
        }
        free(aux->n_link);
        free(*g);
        *g = NULL;
    }
}

void    DestroyExSparseGraph(ExSparseGraph **eg)
{
    ExSparseGraph *aux;

    aux = *eg;
    if (aux != NULL)
    {
        DestroyImage(&(aux->t_link_S));
        DestroyImage(&(aux->t_link_T));
        DestroySparseGraph(&(aux->G));
        free(*eg);
        *eg = NULL;
    }
}


SparseGraph   *CloneSparseGraph(SparseGraph *g)
{
    SparseGraph *clone;
    AdjRel *A;
    int ncols,nrows;
    int p,n,i;

    A = g->A;
    ncols = g->ncols;
    nrows = g->nrows;
    clone = CreateSparseGraph(ncols, nrows,
                              CloneAdjRel(A));
    clone->type = g->type;
    clone->Wmax = g->Wmax;
    n = ncols*nrows;
    for (p=0; p<n; p++)
    {
        for (i=1; i<A->n; i++)
        {
            (clone->n_link[p])[i] = (g->n_link[p])[i];
        }
    }

    return clone;
}


ExSparseGraph *CloneExSparseGraph(ExSparseGraph *g)
{
    ExSparseGraph *clone;

    clone = (ExSparseGraph *)calloc(1, sizeof(ExSparseGraph));
    if (clone == NULL)
        Error(MSG1,"CloneExSparseGraph");
    clone->G = CloneSparseGraph(g->G);
    clone->t_link_S = CopyImage(g->t_link_S);
    clone->t_link_T = CopyImage(g->t_link_T);
    clone->Wmax = g->Wmax;

    return clone;
}


SparseGraph *ReadSparseGraphFromTxt(char *filename)
{
    SparseGraph *sg;
    AdjRel *A = Circular(1.0);
    int ncols,nrows,i,j,p,q,k,val,type;
    FILE *fp;

    fp = fopen(filename,"r");
    if (fp == NULL)
        Error("Cannot open file","ReadSparseGraphFromTxt");
    fscanf(fp,"%d %d %d\n",&type,&ncols,&nrows);
    sg = CreateSparseGraph(ncols, nrows, A);
    sg->type = type;
    sg->Wmax = 0;

    for (i=0; i<nrows*2-1; i++)
    {
        if (i%2==0) //Horizontal edges.
            for (j=0; j<ncols-1; j++)
            {
                p = j + ncols*(i/2);
                q = p + 1;
                fscanf(fp,"%d",&val);
                k = get_edge_index(p, q, sg);
                (sg->n_link[p])[k] = val;
                k = get_edge_index(q, p, sg);
                (sg->n_link[q])[k] = val;
                if (val>sg->Wmax)
                    sg->Wmax = val;
            }
        else       //Vertical edges.
            for (j=0; j<ncols; j++)
            {
                p = j + ncols*(i-1)/2;
                q = j + ncols*(i+1)/2;
                fscanf(fp,"%d",&val);
                k = get_edge_index(p, q, sg);
                (sg->n_link[p])[k] = val;
                k = get_edge_index(q, p, sg);
                (sg->n_link[q])[k] = val;
                if (val>sg->Wmax)
                    sg->Wmax = val;
            }
    }

    fclose(fp);

    return sg;
}


void         WriteSparseGraph2Txt(SparseGraph *sg,
                                  char *filename)
{
    int ncols,nrows,i,j,p,q,k,val;
    FILE *fp;

    if (sg->A->n!=5)
        Error("Current implementation only supports adjacency-4",
              "WriteSparseGraph2Txt");

    fp = fopen(filename,"w");
    if (fp == NULL)
        Error("Cannot open file","WriteSparseGraph2Txt");

    ncols = sg->ncols;
    nrows = sg->nrows;
    fprintf(fp,"%d %d %d\n",sg->type,ncols,nrows);

    for (i=0; i<nrows*2-1; i++)
    {
        if (i%2==0) //Horizontal edges.
            for (j=0; j<ncols-1; j++)
            {
                p = j + ncols*(i/2);
                q = p + 1;
                k = get_edge_index(p, q, sg);
                val = (sg->n_link[p])[k];
                fprintf(fp,"%d ",val);
            }
        else       //Vertical edges.
            for (j=0; j<ncols; j++)
            {
                p = j + ncols*(i-1)/2;
                q = j + ncols*(i+1)/2;
                k = get_edge_index(p, q, sg);
                val = (sg->n_link[p])[k];
                fprintf(fp,"%d ",val);
            }
        fprintf(fp,"\n");
    }

    fclose(fp);
}

SparseGraph   *WeightedSparseGraph(Features *f, Image *objMap, Image *bkgMap, float lambda, AdjRel *A)
{
    SparseGraph *sg;
    int i,p,q,n,ncols,nrows;
    int weight;
    Pixel u,v;
    Image *aux=objMap;

    ncols = f->ncols;
    nrows = f->nrows;
    n     = ncols*nrows;
    sg    = CreateSparseGraph(ncols, nrows, A);
    sg->type  = DISSIMILARITY;
    sg->Wmax  = 0;

    for (p=0; p<n; p++)
    {
        u.x = p%ncols;
        u.y = p/ncols;
        for (i=1; i<A->n; i++)
        {
            v.x = u.x + A->dx[i];
            v.y = u.y + A->dy[i];
            if (ValidPixel(aux,v.x,v.y))
            {
                q = v.x + aux->tbrow[v.y];
                weight = (int)(
                             lambda*(fabs(objMap->val[q]-objMap->val[p])+
                                     fabs(bkgMap->val[q]-bkgMap->val[p])) +
                             (1.0-lambda)*
                             ArcWeight(EuclDist(f->elem[p].feat,f->elem[q].feat,f->nfeats),10000));

                (sg->n_link[p])[i] = weight;
                if (weight>sg->Wmax)
                    sg->Wmax = weight;
            }
        }
    }

    return sg;
}


SparseGraph   *Gradient2SparseGraph(Image *grad,
                                    AdjRel *A)
{
    SparseGraph *sg;
    int i,p,q,n,ncols,nrows;
    int weight;
    Pixel u,v;

    ncols = grad->ncols;
    nrows = grad->nrows;
    n     = ncols*nrows;
    sg    = CreateSparseGraph(ncols, nrows, A);
    sg->type = DISSIMILARITY;
    sg->Wmax  = 0;

    for (p=0; p<n; p++)
    {
        u.x = p%ncols;
        u.y = p/ncols;
        for (i=1; i<A->n; i++)
        {
            v.x = u.x + A->dx[i];
            v.y = u.y + A->dy[i];
            if (ValidPixel(grad,v.x,v.y))
            {
                q = v.x + grad->tbrow[v.y];

                weight = (grad->val[p] + grad->val[q]);
                (sg->n_link[p])[i] = weight;
                if (weight>sg->Wmax)
                    sg->Wmax = weight;
            }
        }
    }

    return sg;
}

Image *ArcWeightImage(SparseGraph *sg)
{
    int i,p,n;
    Image *img=CreateImage(sg->ncols,sg->nrows);
    AdjRel *A=Circular(1.5);
    n=sg->ncols*sg->nrows;
    for (p=0; p<n; p++)
    {
        for (i=1; i<A->n; i++)
        {
            img->val[p]=MAX((sg->n_link[p])[i],img->val[p]);
        }
    }

    DestroyAdjRel(&A);

    return(img);
}
//
//SparseGraph   *ImgObjMaps2SparseGraph(CImage *cimg, Image *objMap, \
//                                      float Wobj, int type)
//{
//    SparseGraph *sg;
//    int i,j,p,q,n,ncols,nrows, GoMax;
//    int weight;
//    Pixel u,v;
//    Features *Gred,*Ggreen,*Gblue,*grad, *Gobj;
//    AdjRel   *A=Circular(1.5);
//    float     gx[4],gy[4],mg[4];
//
//    ncols     = cimg->C[0]->ncols;
//    nrows     = cimg->C[0]->nrows;
//
//    GoMax     = MaximumValue(objMap);
//
//    n         = ncols*nrows;
//    sg        = CreateSparseGraph(ncols, nrows, A);
//    sg->type  = DISSIMILARITY;
//    sg->Wmax  = 0;
//
//    Gobj = VImageGradient(objMap,1.5);
//
//    if (type==0)  // grayscale image
//    {
//
//        grad = VImageGradient(cimg->C[0],1.5);
//        for (p=0; p<n; p++)
//        {
//            u.x = p%ncols;
//            u.y = p/ncols;
//            weight = 0;
//            for (i=1; i<A->n; i++)
//            {
//                v.x = u.x + A->dx[i];
//                v.y = u.y + A->dy[i];
//                if (ValidPixel(cimg->C[0],v.x,v.y))
//                {
//                    q     = v.x + cimg->C[0]->tbrow[v.y];
//                    gx[0] = (Gobj->elem[p].feat[0]+Gobj->elem[q].feat[0])/2.0;
//                    gy[0] = (Gobj->elem[p].feat[1]+Gobj->elem[q].feat[1])/2.0;
//                    gx[1] = (grad->elem[p].feat[0]+grad->elem[q].feat[0])/2.0;
//                    gy[1] = (grad->elem[p].feat[1]+grad->elem[q].feat[1])/2.0;
//                    for (j=0; j < 2; j++)
//                        mg[j] = sqrt(gx[j]*gx[j]+gy[j]*gy[j]);
//                    if (GoMax == 0)
//                        weight = ROUND(mg[1]);
//                    else
//                        weight = ROUND(Wobj*mg[0]+(1.0-Wobj)*mg[1]);
//                }
//                (sg->n_link[p])[i] = weight;
//                if (weight>sg->Wmax)
//                    sg->Wmax = weight;
//            }
//        }
//        DestroyFeatures(&grad);
//    }
//    else  // color image
//    {
//
//        Gred   = VImageGradient(cimg->C[0],1.5);
//        Ggreen = VImageGradient(cimg->C[1],1.5);
//        Gblue  = VImageGradient(cimg->C[2],1.5);
//
//        for (p=0; p<n; p++)
//        {
//            u.x = p%ncols;
//            u.y = p/ncols;
//            weight = 0;
//            for (i=1; i<A->n; i++)
//            {
//                v.x = u.x + A->dx[i];
//                v.y = u.y + A->dy[i];
//                if (ValidPixel(cimg->C[0],v.x,v.y))
//                {
//                    q     = v.x + cimg->C[0]->tbrow[v.y];
//                    gx[0] = (Gobj->elem[p].feat[0]+Gobj->elem[q].feat[0])/2.0;
//                    gy[0] = (Gobj->elem[p].feat[1]+Gobj->elem[q].feat[1])/2.0;
//                    gx[1] = (Gred->elem[p].feat[0]+Gred->elem[q].feat[0])/2.0;
//                    gy[1] = (Gred->elem[p].feat[1]+Gred->elem[q].feat[1])/2.0;
//                    gx[2] = (Ggreen->elem[p].feat[0]+Ggreen->elem[q].feat[0])/2.0;
//                    gy[2] = (Ggreen->elem[p].feat[1]+Ggreen->elem[q].feat[1])/2.0;
//                    gx[3] = (Gblue->elem[p].feat[0]+Gblue->elem[q].feat[0])/2.0;
//                    gy[3] = (Gblue->elem[p].feat[1]+Gblue->elem[q].feat[1])/2.0;
//                    for (j=0; j < 4; j++)
//                        mg[j] = sqrt(gx[j]*gx[j]+gy[j]*gy[j]);
//                    if (GoMax == 0)
//                        weight = ROUND(MAX(MAX(mg[2],mg[3]),mg[4]));
//                    else
//                        weight = ROUND(Wobj*mg[0]+(1.0-Wobj)*MAX(MAX(mg[1],mg[2]),mg[3]));
//                }
//                (sg->n_link[p])[i] = weight;
//                if (weight>sg->Wmax)
//                    sg->Wmax = weight;
//            }
//        }
//        DestroyFeatures(&Gred);
//        DestroyFeatures(&Ggreen);
//        DestroyFeatures(&Gblue);
//    }
//    DestroyFeatures(&Gobj);
//    return sg;
//}

//
//SparseGraph   *FeatObjMaps2SparseGraph(Features *f, Image *objMap, \
//                                       float Wobj)
//{
//    SparseGraph *sg;
//    int i,j,p,q,n,ncols,nrows, GoMax;
//    int weight;
//    Pixel u,v;
//    Features *grad, *Gobj;
//    AdjRel   *A=Circular(1.5);
//    float     gx[4],gy[4],mg[4];
//
//    ncols     = f->ncols;
//    nrows     = f->nrows;
//
//    GoMax     = MaximumValue(objMap);
//
//    n         = ncols*nrows;
//    sg        = CreateSparseGraph(ncols, nrows, A);
//    sg->type  = DISSIMILARITY;
//    sg->Wmax  = 0;
//
////    Gobj = VImageGradient(objMap,1.5);
//    grad = VFeaturesGradient(f,1.5);
//
//    for (p=0; p<n; p++)
//    {
//        u.x = p%ncols;
//        u.y = p/ncols;
//        weight = 0;
//        for (i=1; i<A->n; i++)
//        {
//            v.x = u.x + A->dx[i];
//            v.y = u.y + A->dy[i];
//            if (ValidPixel(objMap,v.x,v.y))
//            {
//                q     = v.x + objMap->tbrow[v.y];
//                gx[0] = (Gobj->elem[p].feat[0]+Gobj->elem[q].feat[0])/2.0;
//                gy[0] = (Gobj->elem[p].feat[1]+Gobj->elem[q].feat[1])/2.0;
//                gx[1] = (grad->elem[p].feat[0]+grad->elem[q].feat[0])/2.0;
//                gy[1] = (grad->elem[p].feat[1]+grad->elem[q].feat[1])/2.0;
//                for (j=0; j < 2; j++)
//                    mg[j] = sqrt(gx[j]*gx[j]+gy[j]*gy[j]);
//                if (GoMax == 0)
//                    weight = ROUND(mg[1]);
//                else
//                    weight = ROUND(Wobj*mg[0]+(1.0-Wobj)*mg[1]);
//            }
//            (sg->n_link[p])[i] = weight;
//            if (weight>sg->Wmax)
//                sg->Wmax = weight;
//        }
//    }
//    DestroyFeatures(&grad);
//    DestroyFeatures(&Gobj);
//    return sg;
//}


SparseGraph *FeatObjVGrads2SparseGraph(Features *Gfeat, Features *Gobj,
                                       float Wobj)
{
    SparseGraph *sg;
    int i,j,p,q,n,ncols,nrows;
    int weight;
    Pixel u,v;
    AdjRel   *A=Circular(1.5);
    float     gx[4],gy[4],mg[4];

    ncols     = Gfeat->ncols;
    nrows     = Gfeat->nrows;
    n         = ncols*nrows;
    sg        = CreateSparseGraph(ncols, nrows, A);
    sg->type  = DISSIMILARITY;
    sg->Wmax  = 0;

    for (p=0; p<n; p++)
    {
        u.x = p%ncols;
        u.y = p/ncols;
        weight = 0;
        for (i=1; i<A->n; i++)
        {
            v.x = u.x + A->dx[i];
            v.y = u.y + A->dy[i];
            if (v.x>=0 && v.y>=0 && v.x<ncols && v.y<nrows)
            {
                q     = v.x + v.y*ncols;
                gx[0] = (Gobj->elem[p].feat[0]+Gobj->elem[q].feat[0])/2.0;
                gy[0] = (Gobj->elem[p].feat[1]+Gobj->elem[q].feat[1])/2.0;
                gx[1] = (Gfeat->elem[p].feat[0]+Gfeat->elem[q].feat[0])/2.0;
                gy[1] = (Gfeat->elem[p].feat[1]+Gfeat->elem[q].feat[1])/2.0;
                for (j=0; j < 2; j++)
                    mg[j] = sqrt(gx[j]*gx[j]+gy[j]*gy[j]);

                weight = ROUND(Wobj*mg[0]+(1.0-Wobj)*mg[1]);
            }
            (sg->n_link[p])[i] = weight;
            if (weight>sg->Wmax)
                sg->Wmax = weight;
        }
    }
    return sg;
}

SparseGraph *FeatObjBVGrads2SparseGraph(Features *Gfeat, Features *Gobj,
                                       int nbands, float Wobj)
{
    SparseGraph *sg;
    int i,j,p,q,n,ncols,nrows;
    int weight;
    Pixel u,v;
    AdjRel   *A=Circular(1.5);
    float     o_gx,o_gy,f_gx,f_gy,mg[4];

    ncols     = Gfeat->ncols;
    nrows     = Gfeat->nrows;
    n         = ncols*nrows;
    sg        = CreateSparseGraph(ncols, nrows, A);
    sg->type  = DISSIMILARITY;
    sg->Wmax  = 0;

    for (p=0; p<n; p++)
    {
        u.x = p%ncols;
        u.y = p/ncols;
        weight = 0;
        for (i=1; i<A->n; i++)
        {
            v.x = u.x + A->dx[i];
            v.y = u.y + A->dy[i];
            if (v.x>=0 && v.y>=0 && v.x<ncols && v.y<nrows)
            {
                q     = v.x + v.y*ncols;
                o_gx = (Gobj->elem[p].feat[0]+Gobj->elem[q].feat[0])/2.0;
                o_gy = (Gobj->elem[p].feat[1]+Gobj->elem[q].feat[1])/2.0;

                mg[1] = FLT_MIN;

                for(j = 0; j < nbands*2; j+=2)
                {
                    f_gx = (Gfeat->elem[p].feat[j]+Gfeat->elem[q].feat[j])/2.0;
                    f_gy = (Gfeat->elem[p].feat[j+1]+Gfeat->elem[q].feat[j+1])/2.0;

                    mg[1] = MAX(mg[1], sqrt(f_gx*f_gx + f_gy*f_gy));
                }

                mg[0] = sqrt(o_gx*o_gx+o_gy*o_gy);

                weight = ROUND(Wobj*mg[0]+(1.0-Wobj)*mg[1]);
            }
            (sg->n_link[p])[i] = weight;
            if (weight>sg->Wmax)
                sg->Wmax = weight;
        }
    }
    return sg;
}

ExSparseGraph *SparseGraph2ExSparseGraph(SparseGraph *g,
        Image *objMap,
        Image *bkgMap)
{
    Image *aux;
    AdjRel *A;
    ExSparseGraph *cap;
    int p,n,i,ncols,nrows,Omax,Bmax,Wmax;
    double w;

    Omax = MaximumValue(objMap);
    Bmax = MaximumValue(bkgMap);
    Wmax = MAX(g->Wmax, MAX(Omax, Bmax));

    A      = g->A;
    ncols  = g->ncols;
    nrows  = g->nrows;
    n      = ncols*nrows;

    cap = (ExSparseGraph *)calloc(1, sizeof(ExSparseGraph));
    cap->G = g;

    for (p=0; p<n; p++)
    {
        for (i=1; i<A->n; i++)
        {
            w = (double)(g->n_link[p])[i];
            (g->n_link[p])[i] = ROUND(Wmax*(w/g->Wmax));
        }
    }

    aux = LinearStretch(objMap, 0, Omax, 0, Wmax);
    cap->t_link_S = aux;

    aux = LinearStretch(bkgMap, 0, Bmax, 0, Wmax);
    cap->t_link_T = aux;

    cap->Wmax = Wmax;
    g->Wmax = Wmax;

    return cap;
}



void ChangeSparseGraphType(SparseGraph *g,
                           int type)
{
    int i,p,n;
    AdjRel *A;

    if (g->type==type)
        return;

    A = g->A;
    n = g->ncols*g->nrows;
    for (p=0; p<n; p++)
    {
        for (i=1; i<A->n; i++)
            (g->n_link[p])[i] = g->Wmax - (g->n_link[p])[i];
    }
    if (g->type==DISSIMILARITY)
        g->type = CAPACITY;
    else
        g->type = DISSIMILARITY;
}


SparseGraph   *CombineSparseGraph(SparseGraph *g1,
                                  SparseGraph *g2,
                                  int method)
{
    SparseGraph *g;
    AdjRel *A;
    int i,p,n,g1_val,g2_val,val=0;

    if (g1->ncols!=g2->ncols ||
            g1->nrows!=g2->nrows ||
            (g1->A)->n!=(g2->A)->n)
        Error("Incompatible sparse graphs",
              "CombineSparseGraph");


    if (g1->type!=g2->type)
        Error("Sparse graphs of different types",
              "CombineSparseGraph");

    A = g1->A;
    n = g1->ncols*g1->nrows;

    g = CreateSparseGraph(g1->ncols, g1->nrows,
                          CloneAdjRel(A));
    g->type = g1->type;
    g->Wmax = 0;
    for (p=0; p<n; p++)
    {
        for (i=1; i<A->n; i++)
        {
            g1_val = (g1->n_link[p])[i];
            g2_val = (g2->n_link[p])[i];
            switch (method)
            {
            case 0:
                val = (g1_val + g2_val)/2;
                break;
            case 1:
                val = MAX(g1_val, g2_val);
                break;
            case 2:
                val = MIN(g1_val, g2_val);
                break;
            }
            (g->n_link[p])[i] = val;
            if (val>g->Wmax)
                g->Wmax = val;
        }
    }

    return g;
}


SparseGraph   *Convert2SymmetricSparseGraph(SparseGraph *g,
        int method)
{
    SparseGraph *sg;
    AdjRel *A;
    int i,k,p,q,n,valpq,valqp,val=0;
    int ncols,nrows;
    Pixel u,v;

    A     = g->A;
    ncols = g->ncols;
    nrows = g->nrows;
    n = ncols*nrows;

    sg = CreateSparseGraph(ncols, nrows,
                           CloneAdjRel(A));
    sg->type = g->type;
    sg->Wmax = 0;
    for (p=0; p<n; p++)
    {
        u.x = p%ncols;
        u.y = p/ncols;
        for (i=1; i<A->n; i++)
        {
            v.x = u.x + A->dx[i];
            v.y = u.y + A->dy[i];
            if (v.x>=0 && v.x<ncols &&
                    v.y>=0 && v.y<nrows)
            {
                q = v.x + v.y*ncols;
                k = get_edge_index(q, p, g);

                valpq = (g->n_link[p])[i];
                valqp = (g->n_link[q])[k];
                switch (method)
                {
                case 0:
                    val = (valpq + valqp)/2;
                    break;
                case 1:
                    val = MAX(valpq, valqp);
                    break;
                case 2:
                    val = MIN(valpq, valqp);
                    break;
                }
                (sg->n_link[p])[i] = val;
                (sg->n_link[q])[k] = val;
                if (val>sg->Wmax)
                    sg->Wmax = val;
            }
        }
    }

    return sg;
}




ExSparseGraph *ReadExSparseGraphFromTxt(char *filename)
{
    ExSparseGraph *g;
    SparseGraph *sg;
    AdjRel *A = Circular(1.0);
    int ncols,nrows,n,i,j,p,q,k,val,type;
    FILE *fp;

    fp = fopen(filename,"r");
    if (fp == NULL)
        Error("Cannot open file","ReadExSparseGraphFromTxt");
    fscanf(fp,"%d %d %d\n",&type,&ncols,&nrows);
    g  = CreateExSparseGraph(ncols, nrows, A);
    g->Wmax = 0;
    sg = g->G;
    sg->type = type;
    n = ncols*nrows;

    for (i=0; i<nrows*2-1; i++)
    {
        if (i%2==0) //Horizontal edges.
            for (j=0; j<ncols-1; j++)
            {
                p = j + ncols*(i/2);
                q = p + 1;
                fscanf(fp,"%d",&val);
                k = get_edge_index(p, q, sg);
                (sg->n_link[p])[k] = val;
                k = get_edge_index(q, p, sg);
                (sg->n_link[q])[k] = val;
                if (val>g->Wmax)
                    g->Wmax = val;
            }
        else       //Vertical edges.
            for (j=0; j<ncols; j++)
            {
                p = j + ncols*(i-1)/2;
                q = j + ncols*(i+1)/2;
                fscanf(fp,"%d",&val);
                k = get_edge_index(p, q, sg);
                (sg->n_link[p])[k] = val;
                k = get_edge_index(q, p, sg);
                (sg->n_link[q])[k] = val;
                if (val>g->Wmax)
                    g->Wmax = val;
            }
    }

    for (p=0; p<n; p++)
    {
        fscanf(fp,"%d",&val);
        (g->t_link_S)->val[p] = val;
        if (val>g->Wmax)
            g->Wmax = val;
    }

    for (p=0; p<n; p++)
    {
        fscanf(fp,"%d",&val);
        (g->t_link_T)->val[p] = val;
        if (val>g->Wmax)
            g->Wmax = val;
    }
    sg->Wmax = g->Wmax;
    fclose(fp);

    return g;
}


void WriteExSparseGraph2Txt(ExSparseGraph *g,
                            char *filename)
{
    int ncols,nrows,n,i,j,p,q,k,val;
    SparseGraph *sg;
    FILE *fp;

    sg = g->G;
    if (sg->A->n!=5)
        Error("Current implementation only supports adjacency-4",
              "WriteExSparseGraph2Txt");

    fp = fopen(filename,"w");
    if (fp == NULL)
        Error("Cannot open file","WriteExSparseGraph2Txt");

    ncols = sg->ncols;
    nrows = sg->nrows;
    fprintf(fp,"%d %d %d\n",sg->type,ncols,nrows);
    n = ncols*nrows;

    for (i=0; i<nrows*2-1; i++)
    {
        if (i%2==0) //Horizontal edges.
            for (j=0; j<ncols-1; j++)
            {
                p = j + ncols*(i/2);
                q = p + 1;
                k = get_edge_index(p, q, sg);
                val = (sg->n_link[p])[k];
                fprintf(fp,"%2d ",val);
            }
        else       //Vertical edges.
            for (j=0; j<ncols; j++)
            {
                p = j + ncols*(i-1)/2;
                q = j + ncols*(i+1)/2;
                k = get_edge_index(p, q, sg);
                val = (sg->n_link[p])[k];
                fprintf(fp,"%2d ",val);
            }
        fprintf(fp,"\n");
    }

    for (p=0; p<n; p++)
    {
        if (p%ncols==0)
            fprintf(fp,"\n");

        val = (g->t_link_S)->val[p];
        fprintf(fp,"%2d ",val);
    }

    for (p=0; p<n; p++)
    {
        if (p%ncols==0)
            fprintf(fp,"\n");

        val = (g->t_link_T)->val[p];
        fprintf(fp,"%2d ",val);
    }

    fclose(fp);
}


