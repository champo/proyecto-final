#include "mslowpass.h"


void ApplyMSLowPass_orig(DImage* img, Features* f, int startingnfeat, int scales)
{
    if(img == NULL)
    {
        Error("DImage* NULL", "ApplyMSLowPass");
    }

    int s;
    int featindex = startingnfeat;
    Spectrum*  smoothedDImg;
    DImage* scaled = img;
    Image* origimg = ConvertDImage2Image(img);

    float Sx = 0.5, Sy = 0.5;

    for(s = 0; s < scales; s++)
    {
        /// Applying low-pass filter
        smoothedDImg = SmoothDImage(scaled, 2.0);

        DImage* filtered = DInvFFT2D(smoothedDImg);

        DImage* filteredscl = filtered;

        /** If scale is greater than 0, resample the image
         *  to its original size
         **/
        if(s > 0)
        {
            /** Returning image to original size
             *  if s > 0 then Sx < 0.5, so considering
             *  s == 1 for example, Sx will be 0.25 which implies
             *  1/(0.25+0.25) == 1/0.5 == 2
             **/
            filteredscl = DScale(filtered,1/(Sx+Sx),1/(Sy+Sy));
        }

        /// Leveling image
        Image* ifilteredscl = ConvertDImage2Image(filteredscl);
        Image* result = Leveling(origimg,ifilteredscl);
        DImage* dresult = ConvertImage2DImage(result);

        /// Sets the rescaled image to the proper feature index
        SetFeature(f,featindex++,dresult);

        /// Cleaning up
        if(filtered != filteredscl)
        {
            DestroyDImage(&filtered);
        }

        DestroyDImage(&filteredscl);
        DestroyDImage(&dresult);
        DestroyImage(&ifilteredscl);
        DestroyImage(&result);

        if(scaled != img) DestroyDImage(&scaled);

        /// Downscaling image for next iteration
        scaled = DScale(img,Sx,Sy);
        Sx = Sx/2;
        Sy = Sy/2;

    }

}


/** Filterbank creation **/
//
//void ApplyMSLowPass(DImage* img, Features* f, int startingnfeat, int scales)
//{
//    if(img == NULL)
//    {
//        Error("DImage* NULL", "ApplyMSLowPass");
//    }
//
//    int s;
//    int featindex = startingnfeat;
//    Spectrum*  smoothedDImg;
//    Image* origimg = ConvertDImage2Image(img);
//
//    for(s = 0; s < scales; s++)
//    {
//        /// Applying low-pass filter
//        /// The result of "pow(2.0,s+1)" guarantees that the filter radius will be
//        /// reduced by half in each scale
//        smoothedDImg = SmoothDImage(img, pow(2.0,s+1));
//
//        DImage* filtered = DInvFFT2D(smoothedDImg);
//
//        DImage* filteredscl = filtered;
//
//        /// Leveling image
//        Image* ifilteredscl = ConvertDImage2Image(filteredscl);
//        Image* result = Leveling(origimg,ifilteredscl);
//
//        /// Sets the rescaled image to the proper feature index
//        int j;
//        for(j = 0; j < img->ncols*img->nrows; j++)
//            f->elem[j].feat[featindex] = (float)result->val[j];
//
//        featindex++;
//
//
//        /// Cleaning up
//        DestroySpectrum(&smoothedDImg);
//        DestroyDImage(&filteredscl);
//        DestroyImage(&ifilteredscl);
//        DestroyImage(&result);
//    }
//
//    DestroyImage(&origimg);
//}
//
//Features* MSLowPassFeats(Features* feats)
//{
//    if(feats == NULL)
//    {
//        Error("Features null","MSLowPassFeats");
//    }
//    if(feats->nfeats == 0)
//    {
//        Error("The must be at least one feat. Features->nfeats == 0!!","SteerablePyramidFeats");
//    }
//
//    int i;
//    bool fillwzeroes = false;
//    int nfeats = feats->nfeats;
//    DImage* featsArray[feats->nfeats];
//
//    /// Getting all image Features and turning them into power-of-2 sided DImages
//    for( i = 0; i < nfeats; i++)
//    {
//        DImage* feat = GetFeature(feats,i);
//        if(!isPowerOf2(feats->ncols) || !isPowerOf2(feats->nrows))
//        {
//            featsArray[i] = DImagePower2(feat);
//            DestroyDImage(&feat);
//            fillwzeroes = true;
//        }else{
//            featsArray[i] = feat;
//        }
//    }
//
//    int index = 0;
//    int ncols = featsArray[0]->ncols;
//    int nrows = featsArray[0]->nrows;
//    int totalnfeats = nfeats*MSLPSCALES;
//
//
//    Features* f = CreateFeatures(ncols, nrows, totalnfeats);
//
//    for( i = 0; i < nfeats; i++)
//    {
//        ApplyMSLowPass(featsArray[i], f, index, MSLPSCALES);
//
//        /** Updates the index where the features should be placed in f,
//         *  i.e 0, 3, 6, etc.
//         **/
//        index += MSLPSCALES;
//    }
//
//    Features* result = f;
//
//    /// If image was filled with zeroes, remove zeroes **/
//    if(fillwzeroes)
//    {
//        result = RemoveZeroes(f,feats->ncols, feats->nrows);
//        DestroyFeatures(&f);
//    }
//
//    result->Imax = feats->Imax;
//
//    int j;
//
//    /// "Normalizing" features
//    for( i = 0; i < result->nelems; i++)
//        for(j = 0; j < result->nfeats; j++)
//            result->elem[i].feat[j] /= result->Imax;
//
//    for( i = 0; i < nfeats; i++)
//            DestroyDImage(&(featsArray[i]));
//
//    return result;
//}
