
#include "shared.h"

int MaximumNotInfinityValue(Image *img){
  int p,n,Imax=INT_MIN;

  n = img->ncols*img->nrows;
  for(p=0; p<n; p++){
    if(img->val[p]!=INT_MAX && img->val[p]>Imax)
      Imax = img->val[p];
  }
  return Imax;
}


Set *ImageBorder(Image *img){
  Set *B=NULL;
  int x,y,p;

  for (x=0, y=0; x < img->ncols; x++){
    p = x + img->tbrow[y];
    InsertSet(&B,p);
  }
  for (x=img->ncols-1, y=1; y < img->nrows; y++){
    p = x + img->tbrow[y];
    InsertSet(&B,p);
  }
  for (x=img->ncols-2, y=img->nrows-1; x >= 0; x--){
    p = x + img->tbrow[y];
    InsertSet(&B,p);
  }
  for (x=0, y=img->nrows-2; y > 0; y--){
    p = x + img->tbrow[y];
    InsertSet(&B,p);
  }
  return(B);
}


Set    *ImageWideBorder(Image *img, int size){
  Set *B=NULL;
  int x,y,p;

  for (x=0; x < img->ncols; x++){
    for (y=0; y<size; y++){
      p = x + img->tbrow[y];
      InsertSet(&B,p);
    }
  }
  for (y=1; y < img->nrows; y++){
    for (x=img->ncols-1; x>=img->ncols-size; x--){
      p = x + img->tbrow[y];
      InsertSet(&B,p);
    }
  }
  for (x=img->ncols-2; x >= 0; x--){
    for (y=img->nrows-1; y>=img->nrows-size; y--){
      p = x + img->tbrow[y];
      InsertSet(&B,p);
    }
  }
  for (y=img->nrows-2; y > 0; y--){
    for (x=0; x<size; x++){
      p = x + img->tbrow[y];
      InsertSet(&B,p);
    }
  }
  return(B);
}


Set *ObjectBorder2Set(Image *label){
  AdjRel *A=Circular(1.5);
  Pixel u,v;
  int p,q,i;
  Set *B=NULL;

  for (u.y=0; u.y < label->nrows; u.y++){
    for (u.x=0; u.x < label->ncols; u.x++){
      p = u.x + label->tbrow[u.y];
      if (label->val[p]>=1){
	for (i=1; i < A->n; i++){
	  v.x = u.x + A->dx[i];
	  v.y = u.y + A->dy[i];
	  if (ValidPixel(label,v.x,v.y)){
	    q = v.x + label->tbrow[v.y];
	    if (label->val[q]==0){
	      InsertSet(&B,p);
	      break;
	    }
	  }
	  else{
	    InsertSet(&B,p);
	    break;
	  }
	}
      }
    }
  }
  DestroyAdjRel(&A);
  return(B);
}



CImage *CopyCImageMask(CImage *cimg, Image *mask, int bkgcolor){
  CImage *obj;
  int p,n;

  obj = CopyCImage(cimg);

  n = mask->ncols*mask->nrows;
  for(p=0; p<n; p++){
    if( mask->val[p]==0 ){
      obj->C[0]->val[p] = t0(bkgcolor);
      obj->C[1]->val[p] = t1(bkgcolor);
      obj->C[2]->val[p] = t2(bkgcolor);
    }
  }

  return obj;
}



CImage *CopySubCImage(CImage *cimg, int j1, int i1, int j2, int i2){
  int i,j,p,q,ncols,nrows;
  CImage *sub=NULL;

  ncols = cimg->C[0]->ncols;
  nrows = cimg->C[0]->nrows;
  if( j1>=0 && i1 >=0 && j2<ncols && i2<nrows && j1<=j2 && i1<=i2 ){
    sub = CreateCImage(j2-j1+1, i2-i1+1);
    p=0;
    for(i=i1; i<=i2; i++){
      for(j=j1; j<=j2; j++){
	q = j + i*ncols;
	sub->C[0]->val[p] = cimg->C[0]->val[q];
	sub->C[1]->val[p] = cimg->C[1]->val[q];
	sub->C[2]->val[p] = cimg->C[2]->val[q];
	p++;
      }
    }
  }
  
  return sub;
}


void    MyPasteSubCImage(CImage *cimg, CImage *sub, int bkgcolor, int j, int i){
  int ncols,nrows,sncols,snrows;
  int B0,B1,B2,C0,C1,C2;
  int x,y,u,v,p,q;

  ncols  = cimg->C[0]->ncols;
  nrows  = cimg->C[0]->nrows;
  sncols = sub->C[0]->ncols;
  snrows = sub->C[0]->nrows;

  B0 = t0(bkgcolor);
  B1 = t1(bkgcolor);
  B2 = t2(bkgcolor);

  for(y=0; y<snrows; y++){
    for(x=0; x<sncols; x++){
      u = x+j;
      v = y+i;
      if( ValidPixel(cimg->C[0], u, v) ){
	p  = x + y*sncols;
	C0 = sub->C[0]->val[p];
	C1 = sub->C[1]->val[p];
	C2 = sub->C[2]->val[p];

	if(C0!=B0 || C1!=B1 || C2!=B2){
	  q = u + v*ncols; 
	  cimg->C[0]->val[q] = C0;
	  cimg->C[1]->val[q] = C1;
	  cimg->C[2]->val[q] = C2;
	}
      }
    }
  }
}

Image *MyAdd(Image *img, int value){
  Image *add;
  int p,n;

  add  = CopyImage(img);
  n = img->ncols*img->nrows;
  for (p=0; p < n; p++)
    add->val[p] += value;
  return(add);
}

void    DrawSet2Image(Image *img, Set *S, 
		      int value){
  Set *aux;
  int p;

  aux = S;
  while(aux != NULL){
    p = aux->elem;
    img->val[p] = value;
    aux = aux->next;
  }
}


void    DrawSet2CImage(CImage *cimg, Set *S, 
		       int color){
  Set *aux;
  int p;

  aux = S;
  while(aux != NULL){
    p = aux->elem;
    cimg->C[0]->val[p] = t0(color);
    cimg->C[1]->val[p] = t1(color);
    cimg->C[2]->val[p] = t2(color);
    aux = aux->next;
  }
}


void    ComputeMBB(CImage *cimg, int bkgcolor, int *j1, int *i1, int *j2, int *i2){
  int ncols,nrows,p,i,j,color,R,G,B;
  
  ncols = cimg->C[0]->ncols;
  nrows = cimg->C[0]->nrows;
  *j1 = ncols - 1;
  *i1 = nrows - 1;
  *j2 = 0;
  *i2 = 0;
  
  for(i=0; i<nrows; i++){
    for(j=0; j<ncols; j++){
      p = j + i*ncols;
      R = cimg->C[0]->val[p];
      G = cimg->C[1]->val[p];
      B = cimg->C[2]->val[p];
      color = triplet(R,G,B);
      if(color!=bkgcolor){
	if(j < *j1) *j1 = j;
	if(i < *i1) *i1 = i;
	if(j > *j2) *j2 = j;
	if(i > *i2) *i2 = i;
      }
    }
  }
}


void    ConvertCImageList2jpeg(FileList *L){
  char command[5000],file[2000];
  int i;

  for(i=0; i<L->n; i++){
    strcpy(file,GetFile(L, i));
    RemoveFileExtension(file);
    sprintf(command,"convert %s %s.jpg",GetFile(L, i),file);
    system(command);
  }
}

void    ConvertCImageList2ppm(FileList *L){
  char command[5000],file[2000];
  int i;

  for(i=0; i<L->n; i++){
    strcpy(file,GetFile(L, i));
    RemoveFileExtension(file);
    sprintf(command,"convert %s %s.ppm",GetFile(L, i),file);
    system(command);
  }
}


CImage *MergeCImages(CImage *A, CImage *B){
  int ncols,nrows;
  CImage *C;
  
  ncols = A->C[0]->ncols+B->C[0]->ncols;
  nrows = MAX(A->C[0]->nrows, B->C[0]->nrows);
  C = CreateCImage(ncols, nrows);
  PasteSubCImage(C, A,
		 0, nrows/2-A->C[0]->nrows/2);
  PasteSubCImage(C, B,
		 A->C[0]->ncols,
		 nrows/2-A->C[0]->nrows/2);
  return C;
}


void    MergeCImageList(FileList *in1,
			FileList *in2,
			FileList *out){
  CImage *A,*B,*C;
  int i;

  if(in1->n!=in2->n || in1->n!=out->n)
    Error("Incompatible FileLists",
	  "MergeCImageList");

  for(i=0; i<in1->n; i++){
    A = ReadCImage(GetFile(in1, i));
    B = ReadCImage(GetFile(in2, i));
    C = MergeCImages(A, B);
    WriteCImage(C, GetFile(out, i));
    DestroyCImage(&A);
    DestroyCImage(&B);
    DestroyCImage(&C);
  }
}


int     GetMinimumCurveIndex(Curve *C){
  double y_min = DBL_MAX;
  int i,i_min=0;

  for(i=0; i<C->n; i++){
    if(C->Y[i]<y_min){
      y_min = C->Y[i];
      i_min = i;
    }
  }
  return i_min;
}



Curve  *RemoveEmptyBins(Curve *hist){
  Curve *C;
  int n,i,j;

  n = 0;
  for(i=0; i<hist->n; i++){
    if(hist->Y[i]>0.0) n++;
  }
  j = 0;
  C = CreateCurve(n);
  for(i=0; i<hist->n; i++){
    if(hist->Y[i]>0.0){
      C->Y[j] = hist->Y[i];
      C->X[j] = hist->X[i];      
      j++;
    }
  }

  return C;
}



