#include "lbp.h"

Features* LBPFeats(Features* feats)
{
	// Cria uma nova feature para cada feature que já existe
	Features* lpFeats = CreateFeatures(feats->ncols,feats->nrows,feats->nfeats);
	int nCols = lpFeats->ncols;
	int nFeat;
	int c,i,j;
	int deltai[8] = {-1,-1,-1,0,+1,+1,+1,0};
	int deltaj[8] = {-1,0,+1,+1,+1,0,-1,-1};
	int lbp;
	int ni, nj;
	float fCurVal;
	
	// -------------       -------------    -----------------
	// | 4 | 5 | 1 |       | 1 | 1 | 0 |    | 1   | 2  | 4  |
	// | 0 | 3 | 6 |   ->  | 0 | 3 | 1 | *  | 128 | 3  | 8  | = 1 + 2 + 8 + 16 + 32 = 59
	// | 1 | 3 | 7 |       | 0 | 1 | 1 |    | 64  | 32 | 16 |
	// -------------       -------------    -----------------
	
	// itera pelas "nfeats" camadas
	for (nFeat=0;nFeat<lpFeats->nfeats;++nFeat)
	{
	    // itera pelos pixels
	    for (i=0;i<lpFeats->nrows;++i)
	    {
	        for (j=0;j<lpFeats->ncols;++j)
	        {
	            lbp = 0;
	            fCurVal = feats->elem[i*nCols+j].feat[nFeat];
                for (c=0;c<8;++c)
                {
                    ni = i+deltai[c];
                    nj = j+deltaj[c];
                    if (ni >= 0 && ni < lpFeats->nrows && nj >= 0 && nj < lpFeats->ncols) // fora da imagem não faz nada
                    {
                        lbp += ((feats->elem[ni*nCols+nj].feat[nFeat] >= fCurVal ? 1 : 0) << c);
                    }
                }

    	        lpFeats->elem[i*nCols+j].feat[nFeat] = lbp;
	        }
	    }
	}

	return lpFeats;
}




