#include "bricor.h"

void LLByMinOnMarkers(DImage* lightness, Image* regions, Set* markers)
{
    if (lightness == NULL || regions == NULL || markers == NULL) return;

    int ncols = regions->ncols;
    int nrows = regions->nrows;

    Image* visited_map = CreateImage(ncols, nrows);

    int VISITED = 1;

    AdjRel* A = FastCircular(1.5);

    Set* aux = markers;

    while (aux != NULL)
    {
        int p = aux->elem;

        if (visited_map->val[p] != VISITED)
        {
            visited_map->val[p] = VISITED;

            Set* aux2 = NULL;
            Set* pixels = NULL;

            InsertSet(&aux2, p);

            float min_value = FLT_MAX;

            /// Searching for minimum value
            while (aux2 != NULL)
            {
                int q = RemoveSet(&aux2);

                InsertSet(&pixels, q);

                float value = (float)lightness->val[q];

                if (value < min_value)
                {
                    min_value = value;

                }


                int i;

                for (i = 0; i < A->n; i++)
                {
                    int x = q%ncols + A->dx[i];
                    int y = q/ncols + A->dy[i];

                    if (ValidPixel(regions, x, y))
                    {
                        int t = x + y*ncols;

                        if (regions->val[t] == regions->val[q] && visited_map->val[t] != VISITED)
                        {
                            visited_map->val[t] = VISITED;

                            InsertSet(&aux2,t);
                        }
                    }
                }
            }

            float val = min_value;

            fprintf(stderr,"min_value == %f\n",min_value);

            /// Applying minimum value
            while (pixels != NULL)
            {
                int k = RemoveSet(&pixels);

                lightness->val[k] = val;
            }

        }

        aux = aux->next;
    }

    DestroyImage(&visited_map);
}

void LLByMaxOnMarkers(DImage* lightness, Image* regions, Set* markers)
{
    if (lightness == NULL || regions == NULL || markers == NULL) return;

    int ncols = regions->ncols;
    int nrows = regions->nrows;

    Image* visited_map = CreateImage(ncols, nrows);

    int VISITED = 1;

    AdjRel* A = FastCircular(1.5);

    Set* aux = markers;

    while (aux != NULL)
    {
        int p = aux->elem;

        if (visited_map->val[p] != VISITED)
        {
            visited_map->val[p] = VISITED;

            Set* aux2 = NULL;
            Set* pixels = NULL;

            InsertSet(&aux2, p);

            float max_value = FLT_MIN;

            /// Searching for minimum value
            while (aux2 != NULL)
            {
                int q = RemoveSet(&aux2);

                InsertSet(&pixels, q);

                float value = (float)lightness->val[q];

                if (value > max_value)
                {
                    max_value = value;

                }


                int i;

                for (i = 0; i < A->n; i++)
                {
                    int x = q%ncols + A->dx[i];
                    int y = q/ncols + A->dy[i];

                    if (ValidPixel(regions, x, y))
                    {
                        int t = x + y*ncols;

                        if (regions->val[t] == regions->val[q] && visited_map->val[t] != VISITED)
                        {
                            visited_map->val[t] = VISITED;

                            InsertSet(&aux2,t);
                        }
                    }
                }
            }

            float val = max_value;

            fprintf(stderr,"max_value == %f\n",max_value);

            /// Applying minimum value
            while (pixels != NULL)
            {
                int k = RemoveSet(&pixels);

                lightness->val[k] = val;
            }

        }

        aux = aux->next;
    }


    DestroyImage(&visited_map);
}

void LLByAvgOnMarkers(DImage* lightness, Image* regions, Set* markers)
{
    if (lightness == NULL || regions == NULL || markers == NULL) return;

    int ncols = regions->ncols;
    int nrows = regions->nrows;

    Image* visited_map = CreateImage(ncols, nrows);

    int VISITED = 1;

    AdjRel* A = FastCircular(1.5);

    Set* aux = markers;

    while (aux != NULL)
    {
        int p = aux->elem;

        if (visited_map->val[p] != VISITED)
        {
            visited_map->val[p] = VISITED;

            Set* aux2 = NULL;
            Set* pixels = NULL;

            InsertSet(&aux2, p);

            float avg_value = 0;
            int n = 0;

            /// Searching for minimum value
            while (aux2 != NULL)
            {
                int q = RemoveSet(&aux2);

                InsertSet(&pixels, q);

                float value = (float)lightness->val[q];

                avg_value += value;
                n++;


                int i;

                for (i = 0; i < A->n; i++)
                {
                    int x = q%ncols + A->dx[i];
                    int y = q/ncols + A->dy[i];

                    if (ValidPixel(regions, x, y))
                    {
                        int t = x + y*ncols;

                        if (regions->val[t] == regions->val[q] && visited_map->val[t] != VISITED)
                        {
                            visited_map->val[t] = VISITED;

                            InsertSet(&aux2,t);
                        }
                    }
                }
            }

            float val = avg_value/(float)n;

            fprintf(stderr,"avg_value == %f\n",val);

            /// Applying minimum value
            while (pixels != NULL)
            {
                int k = RemoveSet(&pixels);

                lightness->val[k] = val;
            }

        }

        aux = aux->next;
    }

    DestroyImage(&visited_map);
}

CImage* LevelLightnessByMin(Features* lab, Image* regions, Set* markers)
{
    if (lab == NULL || regions == NULL) return NULL;

    if (lab->nfeats < 3) return NULL;

    DImage* lightness = GetFeature(lab,0);

    if (markers == NULL)
    {

        int min = MinimumValue(regions);
        int max = MaximumValue(regions);

        int size = max - min + 1;

        float regions_min[size];

        int i;

        for (i = 0; i < size; i++)
            regions_min[i] = FLT_MAX;

        for (i = 0; i < regions->ncols*regions->nrows; i++)
        {
            int r = regions->val[i];
            float val = (float)lightness->val[i];
            regions_min[r] = (val < regions_min[r]) ? val : regions_min[r];
        }

        for (i = 0; i < regions->ncols*regions->nrows; i++)
        {
            int r = regions->val[i];
            lightness->val[i] = (double)regions_min[r];
        }

    }
    else
    {
        LLByMinOnMarkers(lightness, regions, markers);
    }


    return UpdateImageLightness(lab, lightness);
}

CImage* LevelLightnessByMax(Features* lab, Image* regions, Set* markers)
{
    if (lab == NULL || regions == NULL) return NULL;

    if (lab->nfeats < 3) return NULL;

    DImage* lightness = GetFeature(lab,0);

    if (markers == NULL)
    {

        int min = MinimumValue(regions);
        int max = MaximumValue(regions);

        int size = max - min + 1;

        float regions_max[size];

        int i;

        for (i = 0; i < size; i++)
            regions_max[i] = FLT_MIN;

        for (i = 0; i < regions->ncols*regions->nrows; i++)
        {
            int r = regions->val[i];
            float val = (float)lightness->val[i];
            regions_max[r] = (val > regions_max[r]) ? val : regions_max[r];
        }

        for (i = 0; i < regions->ncols*regions->nrows; i++)
        {
            int r = regions->val[i];
            lightness->val[i] = (double)regions_max[r];
        }

    }
    else
    {

        LLByMaxOnMarkers(lightness, regions, markers);
    }

    return UpdateImageLightness(lab, lightness);
}


CImage* LevelLightnessByAvg(Features* lab, Image* regions, Set* markers)
{
    if (lab == NULL || regions == NULL) return NULL;

    if (lab->nfeats < 3) return NULL;

    DImage* lightness = GetFeature(lab,0);


    if (markers == NULL)
    {
        int min = MinimumValue(regions);
        int max = MaximumValue(regions);

        int size = max - min + 1;

        float regions_avg[size];
        int regions_count[size];

        int i;

        for (i = 0; i < size; i++)
        {
            regions_avg[i] = 0;
            regions_count[i] = 0;
        }
        for (i = 0; i < regions->ncols*regions->nrows; i++)
        {
            int r = regions->val[i];
            float val = (float)lightness->val[i];
            regions_avg[r] += val;
            regions_count[r]++;
        }

        for (i = 0; i < size; i++)
            regions_avg[i] = regions_avg[i]/(float)regions_count[i];

        for (i = 0; i < regions->ncols*regions->nrows; i++)
        {
            int r = regions->val[i];
            lightness->val[i] = (double)regions_avg[r];
        }

    }
    else
    {
        LLByAvgOnMarkers(lightness, regions, markers);
    }

    return UpdateImageLightness(lab, lightness);
}

CImage* UpdateImageLightness(Features* feat, DImage* lightness)
{
    if (feat == NULL || lightness == NULL) return NULL;

    if (feat->nfeats < 3) return NULL;

    CImage* cimg = CreateCImage(lightness->ncols, lightness->nrows); /// Lab
//    CImage* cimg; //YCbCr
//    CImage* img = CreateCImage(lightness->ncols, lightness->nrows);//YCbCr

    int i;

    Image* l = ConvertDImage2Image(lightness);

    WriteImage(l,"lightness_corrected.pgm");

    DestroyImage(&l);

    for (i = 0; i < feat->nelems; i++)
    {

//        img->C[0]->val[i] = lightness->val[i];    //YCbCr
//        img->C[1]->val[i] = feat->elem[i].feat[1];
//        img->C[2]->val[i] = feat->elem[i].feat[2];

        float L, a , b;

        L = (float)lightness->val[i];   // Lab
        a = feat->elem[i].feat[1];
        b = feat->elem[i].feat[2];

        Lab2RGB(&L,&a,&b);

        cimg->C[0]->val[i] = (int)L;
        cimg->C[1]->val[i] = (int)a;
        cimg->C[2]->val[i] = (int)b;
    }

//    cimg = CImageYCbCrtoRGB(img); // YCbCr

    int min = INT_MAX;
    int max = INT_MIN;
    int imax = -1;
    int imin = -1;
    int n = feat->nelems;
    for (i=0; i < n; i++)
    {
        if (cimg->C[0]->val[i] > max)
        {
            imax = i;
            max = cimg->C[0]->val[i];
        }
        if (cimg->C[0]->val[i] < min)
        {
            imin = i;
            min = cimg->C[0]->val[i];
        }
    }
    fprintf(stderr,"C[0] min %d imin %d max %d imax %d\n",min,imin, max,imax);
    min = INT_MAX;
    max = INT_MIN;
    for (i=0; i < n; i++)
    {
        if (cimg->C[1]->val[i] > max)
        {
            imax = i;
            max = cimg->C[1]->val[i];
        }
        if (cimg->C[1]->val[i] < min)
        {
            imin = i;
            min = cimg->C[1]->val[i];
        }
    }
    fprintf(stderr,"C[1] min %d imin %d max %d imax %d\n",min,imin, max,imax);
    min = INT_MAX;
    max = INT_MIN;

    for (i=0; i < n; i++)
    {
        if (cimg->C[2]->val[i] > max)
        {
            imax = i;
            max = cimg->C[2]->val[i];
        }
        if (cimg->C[2]->val[i] < min)
        {
            imin =i;
            min = cimg->C[2]->val[i];
        }
    }
    fprintf(stderr,"C[2] min %d imin %d max %d imax %d\n",min,imin, max,imax);
    fprintf(stderr,"C[0] pixel %d value %d\n",32062, cimg->C[0]->val[32062]);
    fprintf(stderr,"C[1] pixel %d value %d\n",31761, cimg->C[1]->val[31761]);
    fprintf(stderr,"C[2] pixel %d value %d\n",30562, cimg->C[2]->val[30562]);
    return cimg;
}

float* RegionsMinimun(DImage* lightness, Image* regions)
{
    if (regions == NULL) return NULL;

    int min = MinimumValue(regions);
    int max = MaximumValue(regions);

    int size = max - min + 1;

    float* regions_min = AllocFloatArray(size);

    int i;

    for (i = 0; i < size; i++)
        regions_min[i] = FLT_MAX;

    for (i = 0; i < regions->ncols*regions->nrows; i++)
    {
        int r = regions->val[i];
        float val = (float)lightness->val[i];
        regions_min[r] = (val < regions_min[r]) ? val : regions_min[r];
    }

    return regions_min;
}

float* RegionsMaximum(DImage* lightness, Image* regions)
{
    if (regions == NULL) return NULL;

    int min = MinimumValue(regions);
    int max = MaximumValue(regions);

    int size = max - min + 1;

    float* regions_max = AllocFloatArray(size);

    int i;

    for (i = 0; i < size; i++)
        regions_max[i] = DBL_MIN;

    for (i = 0; i < regions->ncols*regions->nrows; i++)
    {
        int r = regions->val[i];
        float val = (float)lightness->val[i];
        regions_max[r] = (val > regions_max[r]) ? val : regions_max[r];
    }

    return regions_max;
}

float* RegionsAvg(DImage* lightness, Image* regions)
{
    if (regions == NULL) return NULL;

    int min = MinimumValue(regions);
    int max = MaximumValue(regions);

    int size = max - min + 1;

    float* regions_avg = AllocFloatArray(size);
    int regions_count[size];

    int i;

    for (i = 0; i < size; i++)
    {
        regions_avg[i] = 0;
        regions_count[i] = 0;
    }
    for (i = 0; i < regions->ncols*regions->nrows; i++)
    {
        int r = regions->val[i];
        float val = (float)lightness->val[i];
        regions_avg[r] += val;
        regions_count[r]++;
    }

    for (i = 0; i < size; i++)
        regions_avg[i] = regions_avg[i]/(float)regions_count[i];

    return regions_avg;
}

