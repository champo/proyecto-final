
#ifndef _CODE_CPP_H_
#define _CODE_CPP_H_

#include <iostream>
#include <sstream>
#include <string>

#include "appdata.h"
#include "softwareversion.h"

#endif

