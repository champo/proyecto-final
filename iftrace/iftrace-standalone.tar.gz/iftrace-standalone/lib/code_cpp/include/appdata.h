#ifndef _APPDATA_H_
#define _APPDATA_H_

#include <iostream>
#include <map>
#include <string>

extern "C"
{
    #include "ift.h"
    #include "code_c.h"
}

using namespace std;

/// holds the statistics for one segmentations process
class APPStatistics
{
    public:

        APPStatistics(const string& imgname = "", const string& cvsfilename = "", const string& gtfilename = "");
        ~APPStatistics();

        bool AddIntStat(const string& key , int val = 1);
        bool SetIntStat(const string& key, int val);

        bool AddFloatStat(const string& key, float val);
        bool SetFloatStat(const string& key, float val);

        /// Will append the statistics to a csv file
        bool AppendToCSV(const string& filename = "");

        bool CreateNewCSVFile(const string& filename);

        void ResetData();

        void SetCSVFilename(const string& name)
        {
            mFilename = string(name);
        }

        string GetCSVFilename()
        {
            return mFilename;
        }

        void SetImgname(const string& name)
        {
            mImgname = string(name);
        }

        void SetGTFilename(const string& name)
        {
            mGTFilename = string(name);
            mExpFinished = false;
            mDataSet = true;
        }

        bool IsFinished()
        {
            return mExpFinished;
        }

        bool IsDataSet()
        {
            return mDataSet;
        }

        void Finish(bool exp, bool data_set = false)
        {
            mExpFinished = exp;
            mDataSet = data_set;
        }

        string DisplayInfo();

        void SetWidth(int w)
        {
            mWidth = w;

        }

        void SetHeight(int h)
        {
            mHeight = h;
        }

    private:

        string mImgname;
        string mFilename;
        string mGTFilename;

        bool mExpFinished;
        bool mDataSet;

        char date[100];

        map<string, int> mIntStats;

        map<string, float> mFloatStats;

        int mWidth;
        int mHeight;
};

class APPData{

    public:

        /** Attributes **/

        /// GREY_IMAGE, COLOR_IMAGE, TXT_GRAPH
        int type;

        int bpp;

        int	markerID;
        int checkpoint;
//        int	colormap[256];
        /// Object label color
        int	objColor;
        /// Background label color
        int bkgColor;

        Subgraph      	*sg;

        /// LiveWire propagation front.
        Set *frontier;

        bool closed;
        float mWobj;
        bool single_img_flag;
        APPStatistics* stats;

        /** Methods **/

        /** Constructors/destructor **/
        APPData();
        virtual ~APPData();

        bool IsLoaded();
        void SetLoaded(bool);

        void CreateData(CImage* img, int type, AdjRel* adj);
        void CreateData(int cols, int rows, int type);
        void UnloadData();

        void DrawBorderMarker(const string& opname, int markerID);

        /// For methods below opname should be AWE (arc-weight estimation),
        /// SEG (segmentation), PRE (pre-processing) or whatever other
        /// suffix previously defined
        void HighlightMarkers(CImage *cimg, const string& opname, int markerID = 0);
        void HighlightMarkersAndRemForests(CImage *cimg, int markerID = 0);
        void CleanMarkers(const string& opname);

        bool IsInternalSeed(int p, const string& opname);
        bool IsExternalSeed(int p, const string& opname);
        Set *GetInternalSeeds(const string& opname, int label = -1);
        Set *GetExternalSeeds(const string& opname);
        Set *GetNewObjSeeds(int checkpoint, int objlabel, const string& opname);
        Set *GetNewInternalSeeds(int checkpoint, const string& opname, int label = -1);
        Set *GetNewExternalSeeds(int checkpoint, const string& opname);
        Set *GetAllSeeds(const string& opname);
        int  GetFirstInternalSeed(const string& opname);
        int  GetLastInternalSeed(const string& opname);

        void AddSeed(Pixel p, int label, const string& opname);
        void NewSeed();
        int GetSeedId(Pixel p, const string& opname);
        bool IsSeedMarkedForRemoval(Pixel p,  const string& opname);
        void MarkSeedForRemoval(Pixel p, const string& opname);
        void UnmarkSeedForRemoval(Pixel p, const string& opname);
        Set* GetSeedsMarkedForRemoval(const string& opname);
        void RemoveMarkedSeeds(const string& opname);
        void RepeatSeeds(const string& opdest, const string& opsrc);

        /// DIFT with multiple objects
        Set** GetSeeds(const string& opname);
        Set** GetNewSeeds(int checkpoint, const string& opname);

        Set** GetInternalSeedsByMarkers(const string& opname, int* len);
        Set** GetExternalSeedsByMarkers(const string& opname, int* len);

        int GetInternalSeedsCount(const string& opname);
        int GetExternalSeedsCount(const string& opname);
        void GetIntExtMkCount(const string& opname, int* int_count, int* ext_count, int checkpoint = 0);

        void LoadImage(CImage* cimg, const string& filename, const string& dirname);
        void LoadLabel(Image* img, const string& filename, const string& dirname);
        void LoadGT(Image* img, const string& filename, const string& dirname);

        void SetImageInfo(const string& filename, const string& dirname);
        void SetGTInfo(const string& filename, const string& dirname);

        int GetHeight();
        int GetWidth();

        string GetFilename();
        string GetDirname();

        string GetGTFilename();
        string GetGTDirname();

        /// CImage list methods
        CImage* GetCImage(const string&);
        void SetCImage(const string&, CImage*);
        bool SetCurCImage(const string&);
        CImage* GetCurCImage();

        /// Image list methods
        Image* GetImg(const string&);
        void SetImg(const string&, Image*);
        void SetCurImg(const string&);
        Image* GetCurImg();

        /// Features list methods
        Features* GetFeature(const string&);
        void SetFeature(const string&, Features*);
        void SetCurFeat(const string&);
        Features* GetCurFeat();

        float GTDiceSim();

        float GTFMeasure(int* truepos = NULL, int* trueneg = NULL, int* falsepos = NULL, int* falseneg = NULL);

        void SetCurLabel(const string& labelname);
        Image* GetCurLabel();

    protected:

        int mWidth;
        int mHeight;

        /// Attributes
        string  filename;

        /// Stores the file original directory name,
        /// used for interface purposes, not essential
        string	dirname;

        string gt_filename;

        string gt_dirname;

        /// Stores all Images possible (probability maps, original image, etc.)
        map<string, CImage*> mCImageList;
        string mCImageList_cur; /// key of the current CImage* to be used

        /// Stores all Images possible (probability maps, original image, etc.)
        map<string, Image*> mImageList;
        string mImageList_cur; /// key of the current Image* to be used

        /// Stores all Images possible (probability maps, original image, etc.)
        map<string, Features*> mFeatList;
        string mFeatList_cur; /// key of the current Fatures* to be used

        Set* mRemAWESeedsSet;
        Set* mRemSEGSeedsSet;

        /// Tells if the image is loaded or not
        bool mLoaded;

        string mCurLabel;

};

class APPDataContainer
{
    public:

        /// Constructor
        APPDataContainer();
        APPDataContainer(const string&, APPData*);

        /// Destructor
        ~APPDataContainer();

        /// Methods
        void SetAPPData(const string&, APPData*);

        APPData* GetAPPData(const string&);

        APPData* GetCurAPPData();

        void SetCurAPPData(const string&);

        int Size();

    private:

        /// APPData container, used to store multiple image data
        map<string, APPData*> mAPPArray;

        /// Stores the key of the current data
        string current_key;

};

void app_reset_frame();

void app_draw_frame(int plane);

void app_draw_frames();

/// Sets APPData for debug mode (on == 1, 0 for off)
void APPData_debug_mode(bool on_off);
#endif // _APP_H_
