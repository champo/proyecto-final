#include "appvideodata.h"

APPVideoData::APPVideoData() : APPData()
{
//    mAVFormatCtx = NULL;
//    mAVCodecCtx = NULL;
    mVideoStream = 0;
    mFlag = 0;
}

APPVideoData::~APPVideoData()
{
//    UnloadVideo();
}

void APPVideoData :: LoadVideo(CImage* cimg, const string& pVideoDir, const string& pVideoName)
{
    UnloadVideo();
    CImage* frame0 = NULL;
//    if(pVideoName.rfind(".avi") != std::string::npos || pVideoName.rfind(".AVI") != std::string::npos)
//    {
//        _LoadAVI(pVideoDir, pVideoName);
//        frame0 = GetNextFrame();
//    }else{
        _LoadVideoFolder(pVideoDir);
        frame0 = GetNextFrame(mCurFrame);
        DestroyCImage(&frame0);
//    }
    single_img_flag = false;
    this->LoadImage(cimg, pVideoDir, pVideoName);
//
//    std::cerr << "Loading video " << pVideoDir + "/" + pVideoName << "...\n";
}

void APPVideoData :: UnloadVideo()
{
//    if(mAVCodecCtx != NULL)
//    {
//        /* Closing the codec */
//        avcodec_close(mAVCodecCtx);
//    }
//    if(mAVFormatCtx != NULL)
//    {
//        /* Closing the video file */
//        av_close_input_file(mAVFormatCtx);
//    }
    single_img_flag = false;
}

bool APPVideoData :: IsVideoOver()
{
    if(mType == APPVideoData::AVI)
        return mFlag < 0;
    else
        return mCurFrame >= mNFrames;
}

CImage* APPVideoData :: GetNextFrame(int pFrame)
{
//    if(mType == APPVideoData::AVI)
//        return _NextAVIFrame();
//    else
//        return _NextVideoFolderFrame(pFrame);


    if(single_img_flag)
        return CopyCImage(GetCurCImage());

    return _NextVideoFolderFrame(pFrame);
}

void APPVideoData :: _LoadAVI(const string& pVideoDir, const string& pVideoName)
{
//    mAVFormatCtx = pFormat((char*)((pVideoDir + "/" + pVideoName).c_str()));
//
//    mVideoStream = Stream(mAVFormatCtx);
//
//    mAVCodecCtx = codecContext(mAVFormatCtx, mVideoStream);
//
//    mCurFrame = 1;
//
//    mType = APPVideoData::AVI;
}


CImage* APPVideoData :: _NextAVIFrame()
{
//    CImage* cimg;
//
//    int flag;
//
//    int finishedFrame = 0;
//    cimg = NextFrame (mAVCodecCtx, mAVFormatCtx, mVideoStream, &flag, &finishedFrame);
//
//    if (!finishedFrame) {
//        DestroyCImage(&cimg);
//        cimg = NULL;
//    }else{
//        mFlag = flag;
//        mCurFrame++;
//    }
    return NULL;
//    return cimg;
}


void APPVideoData :: _LoadVideoFolder(const string& pVideoDir)
{
    int count, index;
    struct dirent **files;

    mVideoDir = pVideoDir;

    count = scandir((pVideoDir+"/../").c_str(), &files, NULL, alphasort)- 2;
    fprintf(stderr,"\nNumber of frames: %d\n",count);

    index = atoi((pVideoDir.substr(pVideoDir.rfind("/") + 1)).c_str());

    fprintf(stderr,"Initial frame number: %d\n",index);

    if(count <= 0)
    {
        char msg[300];
        sprintf(msg, "No video files to load in folder %s\n",pVideoDir.c_str());
        Error(msg, "APPVideoData::_LoadVideoFolder");
    }

    mType = APPVideoData::FOLDER;
    mCurFrame = index;
    mNFrames = count;
}

CImage* APPVideoData :: _NextVideoFolderFrame(int pFrame)
{
    CImage* frame = NULL;
    string frame_str = (mVideoDir+"/..");
    if(pFrame > 0)
    {
        frame = ReadPPM (frame_str.c_str(), pFrame);
        mCurFrame = pFrame;
    }else{
        frame = ReadPPM (frame_str.c_str(), mCurFrame++);
    }
//    return NULL;
    return frame;
}
