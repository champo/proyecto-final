
#include "softwareversion.h"


SoftwareVersion :: SoftwareVersion(int major,
				   int minor,
				   int revision){
  this->major = major;
  this->minor = minor;
  this->revision = revision;
}

SoftwareVersion :: SoftwareVersion(const SoftwareVersion& ver){
  this->major = ver.major;
  this->minor = ver.minor;
  this->revision = ver.revision;
}

string* SoftwareVersion :: GetVersion(){
    ostringstream v;
    v << major << "," << minor << "," <<revision;
    return new string(v.str());

}

int SoftwareVersion :: GetMajor(){
  return major;
}

int SoftwareVersion :: GetMinor(){
  return minor;
}

int SoftwareVersion :: GetRevision(){
  return revision;
}


