#include "appdata.h"

#include <algorithm>

bool _APPDATA_DEBUG_ = false;

APPData::APPData()
{
    this->closed = false;
    this->markerID = 1;
    this->checkpoint = 0;
    this->objColor = 0xffff00;
    this->bkgColor = 0x0000ff; //0xffffff;

    mCurLabel = string("label");

    mCImageList["orig"] = NULL;
    mCImageList_cur = string("orig");

    mImageList["grad"] = NULL;
    mImageList["pred"] = NULL;
    mImageList["cost"] = NULL;
    mImageList["label"] = NULL;
    mImageList["chlabel"] = NULL;
    mImageList["root"] = NULL;
    mImageList["regions"] = NULL;
    mImageList["objMap"] = NULL;
    mImageList["bkgMap"] = NULL;

    /// seed label maps, AWE = arc-weight estimation
    /// SEG = segmentation
    mImageList["seedLbMapAWE"] = NULL;
    mImageList["seedLbMapSEG"] = NULL;
    mImageList["seedLbMapPRE"] = NULL;
    mImageList["seedMkMapAWE"] = NULL;
    mImageList["seedMkMapSEG"] = NULL;
    mImageList["seedMkMapPRE"] = NULL;

    mFeatList["feat"] = NULL;
    mFeatList["normfeats"] = NULL;
    mFeatList_cur = string("feat");

    mRemAWESeedsSet = NULL;
    mRemSEGSeedsSet = NULL;

    this->sg = NULL;

    this->frontier = NULL;
    this->mLoaded = false;

    stats = new APPStatistics();
}

APPData::~APPData()
{
    UnloadData();
    delete stats;
}

bool APPData::IsLoaded()
{
    return this->mLoaded;
}

void APPData::SetLoaded(bool l)
{
    this->mLoaded = l;
}

void APPData::UnloadData()
{
    if(_APPDATA_DEBUG_) std::cerr << "\nUnloading data of file \"" << filename << "\"!!\n\n";

    map<string, CImage*>::iterator c_iter;
    for(c_iter = mCImageList.begin(); c_iter != mCImageList.end(); c_iter++)
        if(c_iter->second != NULL) DestroyCImage(&(c_iter->second));

    map<string, Image*>::iterator iter;
    for(iter = mImageList.begin(); iter != mImageList.end(); iter++)
        if(iter->second != NULL) DestroyImage(&(iter->second));

    map<string, Features*>::iterator f_iter;
    for(f_iter = mFeatList.begin(); f_iter != mFeatList.end(); f_iter++)
        if(f_iter->second != NULL) DestroyFeatures(&(f_iter->second));

    if(this->sg != NULL) DestroySubgraph(&(sg));

    mCImageList_cur = string("orig");
    mFeatList_cur = string("feat");

    this->markerID = 1;
    this->checkpoint = 0;

    this->frontier = NULL;
    this->mLoaded = false;
    this->single_img_flag = false;

    stats->ResetData();

    DestroySet(&mRemAWESeedsSet);
    DestroySet(&mRemSEGSeedsSet);
}

void APPData::CreateData(int cols, int rows, int type)
{
    map<string, CImage*>::iterator c_iter;
    for(c_iter = mCImageList.begin(); c_iter != mCImageList.end(); c_iter++)
        c_iter->second = CreateCImage(cols, rows);

    /// Creating Images
    map<string, Image*>::iterator iter;
    for(iter = mImageList.begin(); iter != mImageList.end(); iter++)
        iter->second = CreateImage(cols, rows);

    this->mHeight = rows;
    this->mWidth = cols;

    this->type = type;

    mCImageList_cur = string("orig");
    mFeatList_cur = string("feat");
}


void APPData::CreateData(CImage* img, int type, AdjRel* adj)
{

    if(img == NULL || img->C[0] == NULL || adj == NULL) return;

    if(this->mLoaded == true) UnloadData();

    int cols = img->C[0]->ncols;
    int rows = img->C[0]->nrows;

    mCImageList["orig"] = img;

    /// Creating Images
    map<string, Image*>::iterator iter;
    for(iter = mImageList.begin(); iter != mImageList.end(); iter++)
        iter->second = CreateImage(cols, rows);

    this->mHeight = rows;
    this->mWidth = cols;

    this->type = type;

}

void APPData :: LoadImage(CImage* cimg, const string& filename, const string& dirname)
{
    if(cimg != NULL)
    {
        std::cerr << "Loading image \"" << dirname << "/" << filename << "\"\n";

        int C0max = MaximumValue(cimg->C[0]);
        int C1max = MaximumValue(cimg->C[1]);
        int C2max = MaximumValue(cimg->C[2]);
        int maxval = MAX(C0max, MAX(C1max, C2max));

        int imgtype = COLOR_IMAGE;

        if(IsCImageGray(cimg)) imgtype = GREY_IMAGE;

        CreateData(cimg, imgtype, Circular(1.0));

        ///Computing the radiometric resolution.
        bpp = 0;
        while (maxval > 0)
        {
            maxval >>= 1;
           bpp++;
        }

        SetImageInfo(filename, dirname);
        SetLoaded(true);

        SetImg("groundtruth",NULL);
    }
}

void APPData :: LoadLabel(Image* img, const string& filename, const string& dirname)
{
    if(img == NULL) return;

    if(img->ncols != GetWidth() || img->nrows != GetHeight()) return;

    std::cerr << "Loading label \"" << dirname << "/" << filename << "\"\n";
	Image *lb = GetCurLabel();

	for(int p = 0; p < img->ncols*img->nrows; p++)
		if(img->val[p] > 0)
			lb->val[p] = 1;

	DestroyImage(&img);
}

void APPData :: LoadGT(Image* img, const string& filename, const string& dirname)
{
    if(img == NULL) return;

    if(img->ncols != GetWidth() || img->nrows != GetHeight()) return;

    std::cerr << "Loading groundtruth \"" << dirname << "/" << filename << "\"\n";

    SetImg("groundtruth",img);

    SetGTInfo(filename, dirname);
}

int APPData::GetHeight()
{
    return this->mHeight;
}

int APPData::GetWidth()
{
    return this->mWidth;
}

string APPData::GetFilename()
{
    return filename;
}

string APPData::GetDirname()
{
    return dirname;
}

string APPData::GetGTFilename()
{
    return gt_filename;
}

string APPData::GetGTDirname()
{
    return gt_dirname;
}

void APPData::DrawBorderMarker(const string& opname, int markerID)
{
    Set *B=NULL,*seeds=NULL;
    int p;

    string op = opname;
    std::transform(op.begin(), op.end(), op.begin(), ::toupper);

    Image* seedLbMap = GetImg("seedLbMap" + op);
    Image* seedMkMap = GetImg("seedMkMap" + op);

    if(seedLbMap == NULL || seedMkMap == NULL) return;

    B = ImageWideBorder(seedLbMap, 4);

    seeds = B;
    while (seeds != NULL)
    {
        p = seeds->elem;


        if (markerID>0)
        {
            if (seedMkMap->val[p]==0)
            {
                seedMkMap->val[p] = markerID;
                seedLbMap->val[p] = 0;
            }
        }
        else if (markerID==0)
        {
            if (seedLbMap->val[p]==0)
            {
                seedMkMap->val[p] = 0;
            }
        }

        seeds = seeds->next;
    }

    DestroySet(&B);
}

void APPData::HighlightMarkers(CImage *cimg, const string& opname, int markerID)
{
    string op = opname;
    std::transform(op.begin(), op.end(), op.begin(), ::toupper);

    Image *LbMap = GetImg("seedLbMap" + op);
    Image *MkMap = GetImg("seedMkMap" + op);

    if(LbMap == NULL || MkMap == NULL) return;

    int p,n,lb,color;

    n = cimg->C[0]->ncols*cimg->C[0]->nrows;

    for (p=0; p<n; p++)
    {
        int x = p%MkMap->ncols;
        int y = p/MkMap->ncols;
        Pixel u;
        u.x = x;
        u.y = y;
        if (MkMap->val[p]>markerID)
        {
            lb = LbMap->val[p];
            if (lb>0)
                if(!IsSeedMarkedForRemoval(u,op))
                {
                    color = this->objColor;
                }
                else
                {
                    color = inverseColor(this->objColor);
                    if(color == this->bkgColor) color++;
                }
            else
                if(!IsSeedMarkedForRemoval(u,op))
                {
                    color = this->bkgColor;
                }
                else
                {
                    color = inverseColor(this->bkgColor);
                    if(color == this->objColor) color++;
                }
            cimg->C[0]->val[p] = t0(color);
            cimg->C[1]->val[p] = t1(color);
            cimg->C[2]->val[p] = t2(color);
        }
    }
}

void APPData::HighlightMarkersAndRemForests(CImage *cimg, int markerID)
{
    const string op = "SEG";
    Image *LbMap = GetImg("seedLbMapSEG");
    Image *MkMap = GetImg("seedMkMapSEG");
    Image *label = GetImg("label");
    Image *root = GetImg("root");

    if(LbMap == NULL || MkMap == NULL) return;

    int p,n,lb,color;

    n = cimg->C[0]->ncols*cimg->C[0]->nrows;

    for (p=0; p<n; p++)
    {
        int x = p%MkMap->ncols;
        int y = p/MkMap->ncols;
        Pixel u;
        u.x = x;
        u.y = y;
        if (MkMap->val[p]>markerID)
        {
            lb = LbMap->val[p];
            if (lb>0)
                if(!IsSeedMarkedForRemoval(u,op))
                {
                    color = this->objColor;
                }
                else
                {
                    color = inverseColor(this->objColor);
                    if(color == this->bkgColor) color++;
                }
            else
                if(!IsSeedMarkedForRemoval(u,op))
                {
                    color = this->bkgColor;
                }
                else
                {
                    color = inverseColor(this->bkgColor);
                    if(color == this->objColor) color++;
                }
            cimg->C[0]->val[p] = t0(color);
            cimg->C[1]->val[p] = t1(color);
            cimg->C[2]->val[p] = t2(color);
        }else{
            color = (label->val[p] == 1) ? objColor:bkgColor;
            color = inverseColor(color);

            int r = MkMap->val[root->val[p]];

            if(IsInSet(mRemSEGSeedsSet,r))
            {
                cimg->C[0]->val[p] = ROUND(0.3*t0(color) + 0.7*cimg->C[0]->val[p]);
                cimg->C[1]->val[p] = ROUND(0.3*t1(color) + 0.7*cimg->C[1]->val[p]);
                cimg->C[2]->val[p] = ROUND(0.3*t2(color) + 0.7*cimg->C[2]->val[p]);
            }
        }
    }
}

void APPData::CleanMarkers(const string& opname)
{
    string op = opname;
    std::transform(op.begin(), op.end(), op.begin(), ::toupper);

    Image *LbMap = GetImg("seedLbMap" + op);
    Image *MkMap = GetImg("seedMkMap" + op);

    if(LbMap == NULL || MkMap == NULL) return;

    SetImage(LbMap, 0);
    SetImage(MkMap, 0);

    if(op == "AWE") DestroySet(&mRemAWESeedsSet);
    if(op == "SEG") DestroySet(&mRemSEGSeedsSet);
}

/// Seeds handling

bool APPData::IsInternalSeed(int p, const string& opname)
{
    string op = opname;
    std::transform(op.begin(), op.end(), op.begin(), ::toupper);

    Image *LbMap = GetImg("seedLbMap" + op);
    Image *MkMap = GetImg("seedMkMap" + op);

    if(LbMap == NULL || MkMap == NULL) return false;

    if (MkMap->val[p] > 0 && LbMap->val[p]>0)
            return true;

    return false;
}


bool APPData::IsExternalSeed(int p, const string& opname)
{
    string op = opname;
    std::transform(op.begin(), op.end(), op.begin(), ::toupper);

    Image *LbMap = GetImg("seedLbMap" + op);
    Image *MkMap = GetImg("seedMkMap" + op);

    if(LbMap == NULL || MkMap == NULL) return false;

    if (MkMap->val[p] > 0 && LbMap->val[p]==0)
            return true;

    return false;
}


Set *APPData::GetInternalSeeds(const string& opname, int label)
{
    string op = opname;
    std::transform(op.begin(), op.end(), op.begin(), ::toupper);

    Image *LbMap = GetImg("seedLbMap" + op);
    Image *MkMap = GetImg("seedMkMap" + op);

    if(LbMap == NULL || MkMap == NULL) return NULL;

    Set *S=NULL;
    Set *rem = NULL;

    if(op == "AWE")
        rem = mRemAWESeedsSet;
    else if(op == "SEG")
        rem = mRemSEGSeedsSet;

    if(IsInSet(rem, label)) return NULL;

    int p,n;

    n = LbMap->ncols*LbMap->nrows;
    for (p=0; p<n; p++)
    {
        if (MkMap->val[p]>0)
        {
            if(label > 0)
            {
                if (LbMap->val[p] == label)
                {
                    InsertSet(&S, p);
                }
            }else if (LbMap->val[p] > 0 && !IsInSet(rem,MkMap->val[p]))
            {
                InsertSet(&S, p);
            }
        }
    }

    return S;
}


Set *APPData::GetExternalSeeds(const string& opname)
{
    string op = opname;
    std::transform(op.begin(), op.end(), op.begin(), ::toupper);

    Image *LbMap = GetImg("seedLbMap" + op);
    Image *MkMap = GetImg("seedMkMap" + op);

    if(LbMap == NULL || MkMap == NULL) return NULL;

    Set *S=NULL;
    Set *rem = NULL;

    if(op == "AWE")
        rem = mRemAWESeedsSet;
    else if(op == "SEG")
        rem = mRemSEGSeedsSet;

    int p,n;

    n = LbMap->ncols*LbMap->nrows;
    for (p=0; p<n; p++)
    {
        if (MkMap->val[p]>0)
        {
            if (LbMap->val[p]==0 && !IsInSet(rem, MkMap->val[p]))
                InsertSet(&S, p);
        }
    }

    return S;
}


Set *APPData::GetNewInternalSeeds(int checkpoint, const string& opname, int label)
{
    string op = opname;
    std::transform(op.begin(), op.end(), op.begin(), ::toupper);

    Image *LbMap = GetImg("seedLbMap" + op);
    Image *MkMap = GetImg("seedMkMap" + op);

    if(LbMap == NULL || MkMap == NULL) return NULL;

    Set *S=NULL;
    Set *rem = NULL;

    if(op == "AWE")
        rem = mRemAWESeedsSet;
    else if(op == "SEG")
        rem = mRemSEGSeedsSet;

    if(IsInSet(rem, label)) return NULL;

    int p,n;

    n = LbMap->ncols*LbMap->nrows;
    for (p=0; p<n; p++)
    {
        if (MkMap->val[p]>checkpoint)
        {
            if (label > 0)
            {
                if(LbMap->val[p] == label)
                {
                    InsertSet(&S,p);
                }
            }else if (LbMap->val[p] > 0 && !IsInSet(rem, MkMap->val[p])){
                InsertSet(&S, p);
            }
        }

    }

    return S;
}


Set *APPData::GetNewExternalSeeds(int checkpoint,const string& opname)
{
    string op = opname;
    std::transform(op.begin(), op.end(), op.begin(), ::toupper);

    Image *LbMap = GetImg("seedLbMap" + op);
    Image *MkMap = GetImg("seedMkMap" + op);

    if(LbMap == NULL || MkMap == NULL) return NULL;

    Set *S=NULL;
    Set *rem = NULL;

    if(op == "AWE")
        rem = mRemAWESeedsSet;
    else if(op == "SEG")
        rem = mRemSEGSeedsSet;

    int p,n;

    n = LbMap->ncols*LbMap->nrows;
    for (p=0; p<n; p++)
    {
        if (MkMap->val[p] > checkpoint)
        {
            if (LbMap->val[p] == 0 && !IsInSet(rem, MkMap->val[p]))
                InsertSet(&S, p);
        }
    }

    return S;
}


Set *APPData::GetAllSeeds(const string& opname)
{
    string op = opname;
    std::transform(op.begin(), op.end(), op.begin(), ::toupper);

    Image *MkMap = GetImg("seedMkMap" + op);

    if(MkMap == NULL) return NULL;

    Set *S=NULL;
    Set *rem = NULL;

    if(op == "AWE")
        rem = mRemAWESeedsSet;
    else if(op == "SEG")
        rem = mRemSEGSeedsSet;

    int p,n;

    n = MkMap->ncols*MkMap->nrows;
    for (p=0; p<n; p++)
    {
        if (MkMap->val[p] > 0 && !IsInSet(rem, MkMap->val[p]))
            InsertSet(&S, p);
    }

    return S;
}

int  APPData::GetFirstInternalSeed(const string& opname)
{
    string op = opname;
    std::transform(op.begin(), op.end(), op.begin(), ::toupper);

    Image *LbMap = GetImg("seedLbMap" + op);
    Image *MkMap = GetImg("seedMkMap" + op);

    if(LbMap == NULL || MkMap == NULL) return NIL;

    Set *rem = NULL;

    if(op == "AWE")
        rem = mRemAWESeedsSet;
    else if(op == "SEG")
        rem = mRemSEGSeedsSet;

    int p,n,pmin=NIL,min=INT_MAX;

    n = LbMap->ncols*LbMap->nrows;
    for (p=0; p<n; p++)
    {
        if (MkMap->val[p] > 0 && LbMap->val[p] > 0 && !IsInSet(rem, MkMap->val[p]))
        {
            if (MkMap->val[p]<min)
            {
                pmin = p;
                min = MkMap->val[p];
            }
        }
    }
    return pmin;
}

int  APPData::GetLastInternalSeed(const string& opname)
{
    string op = opname;
    std::transform(op.begin(), op.end(), op.begin(), ::toupper);

    Image *LbMap = GetImg("seedLbMap" + op);
    Image *MkMap = GetImg("seedMkMap" + op);

    if(LbMap == NULL || MkMap == NULL) return NIL;

    Set *rem = NULL;

    if(op == "AWE")
        rem = mRemAWESeedsSet;
    else if(op == "SEG")
        rem = mRemSEGSeedsSet;

    int p,n,pmax=NIL,max=0;

    n = LbMap->ncols*LbMap->nrows;
    for (p=0; p<n; p++)
    {
        if (MkMap->val[p]>0 && LbMap->val[p] > 0  && !IsInSet(rem, MkMap->val[p]))
        {
            if (MkMap->val[p]>max)
            {
                pmax = p;
                max = MkMap->val[p];
            }
        }
    }
    return pmax;
}

void APPData :: AddSeed(Pixel p, int label, const string& opname)
{
    string op = opname;
    std::transform(op.begin(), op.end(), op.begin(), ::toupper);

    Image *LbMap = GetImg("seedLbMap" + op);
    Image *MkMap = GetImg("seedMkMap" + op);

    if(ValidPixel(LbMap, p.x, p.y))
    {
        int u = p.x + LbMap->tbrow[p.y];
        if(MkMap->val[u] == 0 )
        {
            MkMap->val[u] = this->markerID;
            LbMap->val[u] = label;
        }
    }
}

void APPData :: NewSeed()
{
    this->markerID++;
}

int APPData :: GetSeedId(Pixel p, const string& opname)
{
    string op = opname;
    std::transform(op.begin(), op.end(), op.begin(), ::toupper);

    Image* MkMap = GetImg("seedMkMap" + op);

    if(MkMap == NULL || !ValidPixel(MkMap, p.x, p.y)) return -1;

    return MkMap->val[p.x + MkMap->tbrow[p.y]];
}

bool APPData :: IsSeedMarkedForRemoval(Pixel p, const string& opname)
{
    string op = opname;
    std::transform(op.begin(), op.end(), op.begin(), ::toupper);

    Set* rem = NULL;

    if(op == "AWE")
        rem = mRemAWESeedsSet;
    else if(op == "SEG")
        rem = mRemSEGSeedsSet;
    else
        return false;

    int id = GetSeedId(p, op);

    if(id <= 0) return false;

    if(rem == NULL || !IsInSet(rem, id) ) return false;

    return true;
}

void APPData :: MarkSeedForRemoval(Pixel p, const string& opname)
{
    string op = opname;
    std::transform(op.begin(), op.end(), op.begin(), ::toupper);

    Set** rem;

    if(op == "AWE")
        rem = &mRemAWESeedsSet;
    else if(op == "SEG")
        rem = &mRemSEGSeedsSet;
    else
        return;

    int id = GetSeedId(p, op);

    if(id <= 0) return;

    InsertSet(rem, id);
}

void APPData :: UnmarkSeedForRemoval(Pixel p, const string& opname)
{
    string op = opname;
    std::transform(op.begin(), op.end(), op.begin(), ::toupper);

    Set** rem;

    if(op == "AWE")
        rem = &mRemAWESeedsSet;
    else if(op == "SEG")
        rem = &mRemSEGSeedsSet;
    else
        return;

    int id = GetSeedId(p, op);

    if(id <= 0) return;

    if(*rem != NULL) RemoveSetElem(rem, id);
}

Set* APPData :: GetSeedsMarkedForRemoval(const string& opname)
{
    string op = opname;
    std::transform(op.begin(), op.end(), op.begin(), ::toupper);

    Set* rem = NULL;

    if(op == "AWE")
        rem = mRemAWESeedsSet;
    else if(op == "SEG")
        rem = mRemSEGSeedsSet;
    else
        return NULL;

    Image* MkMap = GetImg("seedMkMap" + op);

    if(MkMap == NULL || rem == NULL) return NULL;

    Set* rem_set = NULL;

    int i;

    for(i = 0; i < MkMap->ncols*MkMap->nrows; i++)
        if(MkMap->val[i] > 0 && IsInSet(rem, MkMap->val[i]))
            InsertSet(&rem_set, i);

    return rem_set;
}

void APPData :: RemoveMarkedSeeds(const string& opname)
{
    string op = opname;
    std::transform(op.begin(), op.end(), op.begin(), ::toupper);

    Set** rem;

    if(op == "AWE")
        rem = &mRemAWESeedsSet;
    else if(op == "SEG")
        rem = &mRemSEGSeedsSet;
    else
        return;

    Image* MkMap = GetImg("seedMkMap" + op);

    if(MkMap == NULL) return;

    int i;

    for(i = 0; i < MkMap->ncols*MkMap->nrows; i++)
        if(MkMap->val[i] > 0 && IsInSet(*rem, MkMap->val[i]))
            MkMap->val[i] = 0;

    DestroySet(rem);

}

void APPData :: RepeatSeeds(const string& opdest, const string& opsrc)
{
    string op1 = opdest;
    std::transform(op1.begin(), op1.end(), op1.begin(), ::toupper);
    string op0 = opsrc;
    std::transform(op0.begin(), op0.end(), op0.begin(), ::toupper);

    Image* LbMap = GetImg("seedLbMap" + op0);
    Image* MkMap = GetImg("seedMkMap" + op0);

    SetImg("seedLbMap"+op1, CopyImage(LbMap));
    SetImg("seedMkMap"+op1, CopyImage(MkMap));

    markerID = MaximumValue(MkMap)+1;
    checkpoint = 0;
}

int  APPData::GetInternalSeedsCount(const string& opname)
{
    string op = opname;
    std::transform(op.begin(), op.end(), op.begin(), ::toupper);

    Image *LbMap = GetImg("seedLbMap" + op);
    Image *MkMap = GetImg("seedMkMap" + op);

    if(LbMap == NULL || MkMap == NULL) return NIL;

    int p,n,min=MinimumValue(MkMap), max = MaximumValue(MkMap);
    int count = 0;

    bool used[max - min + 1];

    n = LbMap->ncols*LbMap->nrows;
    for (p=0; p<n; p++)
    {
        if (MkMap->val[p]>0 && LbMap->val[p]>0)
        {
            used[MkMap->val[p] - 1] = true;
        }
    }

    for(p = 0; p < max - min + 1; p++)
    {
        if(used[p]) count++;
    }

    return count;
}

int  APPData::GetExternalSeedsCount(const string& opname)
{
    string op = opname;
    std::transform(op.begin(), op.end(), op.begin(), ::toupper);

    Image *LbMap = GetImg("seedLbMap" + op);
    Image *MkMap = GetImg("seedMkMap" + op);

    if(LbMap == NULL || MkMap == NULL) return NIL;

    int p,n,min=MinimumValue(MkMap), max = MaximumValue(MkMap);
    int count = 0;

    bool used[max - min + 1];

    n = LbMap->ncols*LbMap->nrows;
    for (p=0; p<n; p++)
    {
        if (MkMap->val[p]>0 && LbMap->val[p]==0)
        {
            used[MkMap->val[p] - 1] = true;
        }
    }

    for(p = 0; p < max - min + 1; p++)
    {
        if(used[p]) count++;
    }

    return count;
}

void  APPData::GetIntExtMkCount(const string& opname, int* int_count, int* ext_count, int checkpoint)
{
    string op = opname;
    std::transform(op.begin(), op.end(), op.begin(), ::toupper);

    Image *LbMap = GetImg("seedLbMap" + op);
    Image *MkMap = GetImg("seedMkMap" + op);

    if(LbMap == NULL || MkMap == NULL) return;

    int p,n,min=MinimumValue(MkMap), max = MaximumValue(MkMap);

    int used[max - min + 1];

    for(p = 0; p < max - min + 1; p++)
        used[p] = NIL;

    n = LbMap->ncols*LbMap->nrows;
    for (p=0; p<n; p++)
    {
        if (MkMap->val[p] > checkpoint)
        {
            if(LbMap->val[p] > 0)
            {
                used[MkMap->val[p] - 1] = 1;
            }else if(LbMap->val[p] == 0){
                used[MkMap->val[p] - 1] = 0;
            }
        }
    }

    (*int_count) = 0;
    (*ext_count) = 0;
    for(p = 0; p < max - min + 1; p++)
    {
        if(used[p] == 1)
            (*int_count)++;
        else if(used[p] == 0)
            (*ext_count)++;
    }

}

Set** APPData :: GetSeeds(const string& opname)
{
    string op = opname;
    std::transform(op.begin(), op.end(), op.begin(), ::toupper);

    Image *LbMap = GetImg("seedLbMap" + op);
    Image *MkMap = GetImg("seedMkMap" + op);

    if(LbMap == NULL || MkMap == NULL) return NULL;

    int max = MaximumValue(LbMap);
    int min = MinimumValue(LbMap);
    int size = max - min + 1;

    Set** S = (Set**)calloc(size,sizeof(Set*));

    if(S == NULL)
        Error((char*)"Could not allocate memory for Set**", (char*)"APPData::GetSeeds");

    int p,n;

    for(p = 0; p < size; p++)
        S[p] = NULL;

    n = LbMap->ncols*LbMap->nrows;
    for (p=0; p<n; p++)
    {
        if (MkMap->val[p]>0)
        {
            int lb = LbMap->val[p];
            InsertSet(&(S[lb]), p);
        }
    }

    return S;
}

Set** APPData :: GetNewSeeds(int checkpoint, const string& opname)
{
    string op = opname;
    std::transform(op.begin(), op.end(), op.begin(), ::toupper);

    Image *LbMap = GetImg("seedLbMap" + op);
    Image *MkMap = GetImg("seedMkMap" + op);

    if(LbMap == NULL || MkMap == NULL) return NULL;

    int max = MaximumValue(LbMap);
    int min = MinimumValue(LbMap);
    int size = max - min + 1;

    Set** S = (Set**)calloc(size,sizeof(Set*));

    if(S == NULL)
        Error((char*)"Could not allocate memory for Set**", (char*)"APPData::GetSeeds");

    int p,n;

    for(p = 0; p < size; p++)
        S[p] = NULL;

    n = LbMap->ncols*LbMap->nrows;
    for (p=0; p<n; p++)
    {
        if (MkMap->val[p]>checkpoint)
        {
            int lb = LbMap->val[p];
            InsertSet(&(S[lb]), p);
        }
    }

    return S;
}

Set** APPData :: GetInternalSeedsByMarkers(const string& opname, int* len)
{
    string op = opname;
    std::transform(op.begin(), op.end(), op.begin(), ::toupper);

    Image *LbMap = GetImg("seedLbMap" + op);
    Image *MkMap = GetImg("seedMkMap" + op);

    if(LbMap == NULL || MkMap == NULL) return NULL;

    int min = MinimumValue(MkMap);
    int max = MaximumValue(MkMap);
    int size = max - min + 1;

    Set* S[size];

    if(S == NULL)
        Error((char*)"Could not allocate memory for Set**", (char*)"APPData::GetInternalSeedsByMarkers");

    int p,n, count = 0;

    for(p = 0; p < size; p++)
        S[p] = NULL;

    n = LbMap->ncols*LbMap->nrows;
    for (p=0; p<n; p++)
    {
        if (MkMap->val[p] > 0 && LbMap->val[p] > 0)
        {
            /// subtracting by min so that it will fit
            /// in the array, when min != 0
            int mk = MkMap->val[p] - min;

            if(S[mk] == NULL) count++;

            InsertSet(&(S[mk]), p);
        }
    }

    Set** R = (Set**)calloc(count,sizeof(Set*));

    int p0 = 0;

    for(p = 0; p < size; p++)
    {
        if(S[p] != NULL)
        {
            R[p0] = S[p];
            p0++;
        }
    }

    *len = count;

    return R;
}

Set** APPData :: GetExternalSeedsByMarkers(const string& opname, int* len)
{
    string op = opname;
    std::transform(op.begin(), op.end(), op.begin(), ::toupper);

    Image *LbMap = GetImg("seedLbMap" + op);
    Image *MkMap = GetImg("seedMkMap" + op);

    if(LbMap == NULL || MkMap == NULL) return NULL;

    int min = MinimumValue(MkMap);
    int max = MaximumValue(MkMap);
    int size = max - min + 1;

    Set* S[size];

    if(S == NULL)
        Error((char*)"Could not allocate memory for Set**", (char*)"APPData::GetExternalSeedsByMarkers");

    int p,n, count = 0;

    for(p = 0; p < size; p++)
        S[p] = NULL;

    n = LbMap->ncols*LbMap->nrows;
    for (p=0; p<n; p++)
    {
        if (MkMap->val[p] > 0 && LbMap->val[p] == 0)
        {
            /// subtracting by min so that it will fit
            /// in the array, when min != 0
            int mk = MkMap->val[p] - min;

            if(S[mk] == NULL) count++;

            InsertSet(&(S[mk]), p);
        }
    }

    Set** R = (Set**)calloc(count,sizeof(Set*));

    int p0 = 0;

    for(p = 0; p < size; p++)
    {
        if(S[p] != NULL)
        {
            R[p0] = S[p];
            p0++;
        }
    }

    *len = count;

    return R;
}

/// End of Seeds handling

void APPData::SetImageInfo(const string& filename, const string& dirname)
{
    this->filename = filename;
    this->dirname = dirname;

    stats->SetImgname(filename);

    stats->SetWidth(GetWidth());
    stats->SetHeight(GetHeight());
}

void APPData::SetGTInfo(const string& filename, const string& dirname)
{
    this->gt_filename = filename;
    this->gt_dirname = dirname;

    stats->SetGTFilename(filename);
}
/** Image container methods **/

Image* APPData::GetImg(const string& key)
{
    map<string, Image*>::iterator iter = mImageList.find(key);
    if(iter != mImageList.end())
        return mImageList[key];

    return NULL;
}

void APPData::SetImg(const string& key, Image* img)
{
    map<string, Image*>::iterator iter = mImageList.find(key);
    if(iter != mImageList.end() && iter->second != NULL)
    {
        DestroyImage(&(mImageList[key]));
        if(_APPDATA_DEBUG_)
        {
            char msg[300];
            sprintf (msg,"Deleting Image %s for file \"%s\"",key.c_str(),filename.c_str());
            Warning(msg,(char*)"SetImg*");

        }
    }
    else if(_APPDATA_DEBUG_ && iter == mImageList.end())
    {
        /// Warns when new data is created, useful for debugging
        char msg[300];
        sprintf(msg,"Creating new Image* named \"%s\" for file \"%s\"",key.c_str(),filename.c_str());
        Warning(msg,(char*)"SetImage");
    }

    mImageList[key] = img;
}

void APPData::SetCurImg(const string& key)
{
    mImageList_cur = key;
    if(_APPDATA_DEBUG_) std::cerr << "Setting new current Image for file \"" << this->filename << "\" named \"" << key << "\"\n";
}

Image* APPData::GetCurImg()
{
    return GetImg(mImageList_cur);
}

/** CImage container methods **/
CImage* APPData::GetCImage(const string& key)
{
    map<string, CImage*>::iterator iter = mCImageList.find(key);
    if(iter != mCImageList.end())
        return mCImageList[key];

    return NULL;
}

void APPData::SetCImage(const string& key, CImage* cimg)
{
    map<string, CImage*>::iterator iter = mCImageList.find(key);
    if(iter != mCImageList.end() && iter->second != NULL)
    {
        DestroyCImage(&(mCImageList[key]));
        if(_APPDATA_DEBUG_)
        {
            char msg[300];
            sprintf (msg,"Deleting CImage %s for file \"%s\"",key.c_str(),filename.c_str());
            Warning(msg,(char*)"SetCImage*");

        }
    }
    else if(_APPDATA_DEBUG_ && iter == mCImageList.end())
    {
        /// Warns when new data is created, useful for debugging
        char msg[300];
        sprintf(msg,"Creating new CImage* named \"%s\" for file \"%s\"",key.c_str(),filename.c_str());
        Warning(msg,(char*)"SetCImage");
    }

    mCImageList[key] = cimg;
}

bool APPData::SetCurCImage(const string& key)
{
    CImage* cimg = GetCImage(key);

    if(cimg == NULL) return false;

    mCImageList_cur = key;

        ///Computing the radiometric resolution.
    int C0max = MaximumValue(cimg->C[0]);
    int C1max = MaximumValue(cimg->C[1]);
    int C2max = MaximumValue(cimg->C[2]);
    int maxval = MAX(C0max, MAX(C1max, C2max));

    bpp = 0;

    while (maxval > 0)
    {
        maxval >>= 1;
        bpp++;
    }

    if(_APPDATA_DEBUG_) std::cerr << "Setting new current CImage for file \"" << this->filename << "\" named \"" << key << "\"\n";
    cerr << "\nbpp " << bpp << " " << key << "\n";
    return true;
}

CImage* APPData::GetCurCImage()
{
    return GetCImage(mCImageList_cur);
}

/** Features container methods **/

Features* APPData::GetFeature(const string& key)
{
    map<string, Features*>::iterator iter = mFeatList.find(key);
    if(iter != mFeatList.end())
        return mFeatList[key];

    return NULL;
}

void APPData::SetFeature(const string& key, Features* feat)
{
    char msg[300];

    map<string, Features*>::iterator iter = mFeatList.find(key);
    if(iter != mFeatList.end() && iter->second != NULL)
    {
        if(iter->second != NULL) DestroyFeatures(&(iter->second));
        if(_APPDATA_DEBUG_)
        {
            sprintf (msg,"Deleting Feature %s for file \"%s\"",key.c_str(),filename.c_str());
            Warning(msg,(char*)"SetFeature*");

        }
    }
    else if(_APPDATA_DEBUG_ && iter == mFeatList.end())
    {
        /// Warns when new data is created, useful for debugging
        sprintf(msg,"Creating new Feature* named \"%s\" for file \"%s\"",key.c_str(),filename.c_str());
        Warning(msg,(char*)"SetFeature");
    }
    mFeatList[key] = feat;
}

void APPData::SetCurFeat(const string& key)
{
    mFeatList_cur = key;
    if(_APPDATA_DEBUG_) std::cerr << "Setting new current Feature for file \"" << this->filename << "\" named \"" << key << "\"\n";
}

Features* APPData::GetCurFeat()
{
    return GetFeature(mFeatList_cur);
}

float APPData :: GTDiceSim()
{
    Image* label = GetImg(mCurLabel);
    Image* gt = GetImg("groundtruth");

    if(label == NULL || gt == NULL) return -1;

    return DiceSimilarity(label, gt);
}

float APPData :: GTFMeasure(int* truepos, int* trueneg, int* falsepos, int* falseneg)
{
    Image* label = GetImg(mCurLabel);
    Image* gt = GetImg("groundtruth");

    if(label == NULL || gt == NULL) return -1;

    int tp = 0, tn = 0, fp = 0, fn = 0;

    if(!ConfMatrix(label, gt, &tp, &tn, &fp, &fn)) return -1;

    if(truepos != NULL) *truepos = tp;
    if(trueneg != NULL) *trueneg = tn;
    if(falsepos != NULL) *falsepos = fp;
    if(falseneg != NULL) *falseneg = fn;

    return FMeasure(Precision(tp, fp), Recall(tp, fn));
}

void APPData :: SetCurLabel(const string& labelname)
{
    mCurLabel = string(labelname);

    stats->Finish(false, true);
}

Image* APPData :: GetCurLabel()
{
    return GetImg(mCurLabel);
}

/** ------------------------------------------------------- **/

APPStatistics :: APPStatistics(const string& imgname, const string& cvsfilename, const string& gtfilename)
{
    mIntStats["runAWE"] = 0;
    mIntStats["runSEG"] = 0;

    mFloatStats["runtimeAWE"] = 0.0;
    mFloatStats["runtimeGrad"] = 0.0;
    mFloatStats["runtimeOPF"] = 0.0;
    mFloatStats["runtimeWater"] = 0.0;
    mFloatStats["runtimeSEG"] = 0.0;

    mIntStats["SiAWE"] = 0;
    mIntStats["SeAWE"] = 0;

    mIntStats["SiSEG"] = 0;
    mIntStats["SeSEG"] = 0;

    mIntStats["SiAWECount"] = 0;
    mIntStats["SeAWECount"] = 0;
    mIntStats["SiSEGCount"] = 0;
    mIntStats["SeSEGCount"] = 0;

    mIntStats["volume"] = 0;

    mFloatStats["Wobj"] = 0.0;
    mFloatStats["DiceSimilarity"] = 0.0;
    mFloatStats["FMeasure"] = 0.0;
    mFloatStats["ErodedFMeasure"] = 0.0;
    mFloatStats["DilatedFMeasure"] = 0.0;
    mFloatStats["DilEroFMeasure"] = 0.0;
    mFloatStats["BinFMeasure"] = 0.0;

    mIntStats["tp"] = 0;
    mIntStats["tn"] = 0;
    mIntStats["fp"] = 0;
    mIntStats["fn"] = 0;

    mIntStats["tpbin"] = 0;
    mIntStats["tnbin"] = 0;
    mIntStats["fpbin"] = 0;
    mIntStats["fnbin"] = 0;

    mImgname = string(imgname);
    mFilename = string(cvsfilename);
    mGTFilename = string(gtfilename);

    mExpFinished = false;
    mDataSet = true;

    mWidth = 0;
    mHeight = 0;
}

APPStatistics :: ~APPStatistics()
{
}

bool APPStatistics :: AddIntStat(const string& key , int val)
{
    map<string, int>::iterator iter = mIntStats.find(key);

    if(iter != mIntStats.end())
    {
        mIntStats[key] += val;

        mExpFinished = false;
        mDataSet = true;
        return true;

    }


    return false;
}

bool APPStatistics :: SetIntStat(const string& key , int val)
{
    map<string, int>::iterator iter = mIntStats.find(key);

    if(iter != mIntStats.end())
    {
        mIntStats[key] = val;
        mExpFinished = false;
        mDataSet = true;
        return true;
    }

    return false;
}

bool APPStatistics :: AddFloatStat(const string& key, float val)
{
    map<string, float>::iterator iter = mFloatStats.find(key);

    if(iter != mFloatStats.end())
    {
        mFloatStats[key] += val;
        mExpFinished = false;
        mDataSet = true;
        return true;
    }

    return false;
}

bool APPStatistics :: SetFloatStat(const string& key, float val)
{
    map<string, float>::iterator iter = mFloatStats.find(key);

    if(iter != mFloatStats.end())
    {
        mFloatStats[key] = val;
        mExpFinished = false;
        mDataSet = true;
        return true;
    }

    return false;
}

bool APPStatistics :: AppendToCSV(const string& filename)
{
    string fopenname, fname;

    if(filename != "")
    {
        fopenname = "out/" + filename;
        fname = filename;
    }else if(mFilename != "")
    {
        fopenname = "out/" + mFilename;
        fname = mFilename;
    }else{
        return false;
    }

    FILE* f = fopen(fopenname.c_str(),"r");

    if(f == NULL)
    {
        if(!CreateNewCSVFile(fname)) return false;
    }else{
        fclose(f);
    }

    f = fopen(fopenname.c_str(),"a");

    time_t theTime;

    time(&theTime);

    tm* tt = localtime(&theTime);

    strftime(date,100,"%d:%m:%Y %H:%M:%S",tt);

    fprintf(f,"%s; %s; %s; %d; %d;", mImgname.c_str(),date, mGTFilename.c_str(),mWidth,mHeight);

    string info = "";

    int size = mWidth*mHeight;

    size = (size == 0) ? 1 : size;

    char n[50];
    sprintf(n,"%d; ",mIntStats["runAWE"]);
    info += n;
//    sprintf(n,"%f; ",mFloatStats["runtimeAWE"]);
//    info += n;
    sprintf(n,"%f; ",mFloatStats["runtimeGrad"]);
    info += n;
    sprintf(n,"%f; ",mFloatStats["runtimeOPF"]);
    info += n;
    sprintf(n,"%f; ",mFloatStats["runtimeWater"]);
    info += n;
    sprintf(n,"%d; ",mIntStats["SiAWECount"]);
    info += n;
    sprintf(n,"%d; ",mIntStats["SeAWECount"]);
    info += n;
    sprintf(n,"%d; ",mIntStats["SiAWE"]);
    info += n;
    sprintf(n,"%d; ",mIntStats["SeAWE"]);
    info += n;
    sprintf(n,"%d; ",mIntStats["volume"]);
    info += n;
    sprintf(n,"%f; ",mFloatStats["Wobj"]);
    info += n;
    sprintf(n,"%d; ",mIntStats["runSEG"]);
    info += n;
    sprintf(n,"%f; ",mFloatStats["runtimeSEG"]);
    info += n;
    sprintf(n,"%d; ",mIntStats["SiSEGCount"]);
    info += n;
    sprintf(n,"%d; ",mIntStats["SeSEGCount"]);
    info += n;
    sprintf(n,"%d; ",mIntStats["SiSEG"]);
    info += n;
    sprintf(n,"%d; ",mIntStats["SeSEG"]);
    info += n;
    sprintf(n,"%f; ",100*(float)mIntStats["tp"]/(float)size);
    info += n;
    sprintf(n,"%f; ",100*(float)mIntStats["tn"]/(float)size);
    info += n;
    sprintf(n,"%f; ",100*(float)mIntStats["fp"]/(float)size);
    info += n;
    sprintf(n,"%f; ",100*(float)mIntStats["fn"]/(float)size);
    info += n;
    sprintf(n,"%f; ",100*mFloatStats["DiceSimilarity"]);
    info += n;
    sprintf(n,"%f; ",100*mFloatStats["FMeasure"]);
    info += n;
    sprintf(n,"%f; ",100*mFloatStats["ErodedFMeasure"]);
    info += n;
    sprintf(n,"%f; ",100*mFloatStats["DilatedFMeasure"]);
    info += n;
    sprintf(n,"%f; ",100*mFloatStats["DilEroFMeasure"]);
    info += n;
    sprintf(n,"%f; ",100*(float)mIntStats["tpbin"]/(float)size);
    info += n;
    sprintf(n,"%f; ",100*(float)mIntStats["tnbin"]/(float)size);
    info += n;
    sprintf(n,"%f; ",100*(float)mIntStats["fpbin"]/(float)size);
    info += n;
    sprintf(n,"%f; ",100*(float)mIntStats["fnbin"]/(float)size);
    info += n;
    sprintf(n,"%f\n",100*mFloatStats["BinFMeasure"]);
    info += n;

    fprintf(f,"%s",info.c_str());

    fclose(f);

    mDataSet = false;
    mExpFinished = false;

    return true;
}

bool APPStatistics :: CreateNewCSVFile(const string& filename)
{
    string fname = "out/" + filename;
    FILE* f = fopen(fname.c_str(), "w");

    if(f == NULL) return false;

    fprintf(f,"Filename; Date; GT_filename; Width; Height; ");

    map<string, int>::iterator iter;

    string info = "";

    info += "Number of Runs (ENH); ";
//    info += "Runtime (ENH); ";
    info += "Runtime Gradient; ";
    info += "Runtime OPF; ";
    info += "Runtime Watergray; ";
    info += "Internal markers (ENH); ";
    info += "External markers (ENH); ";
    info += "Internal markers pixels (ENH); ";
    info += "External markers pixels (ENH); ";
    info += "Volume (Watergray); ";
    info += "Wobj (ENH); ";
    info += "Number of Runs (DEL); ";
    info += "Runtime (DEL); ";
    info += "Internal markers (DEL); ";
    info += "External markers (DEL); ";
    info += "Internal markers pixels (DEL); ";
    info += "External markers pixels (DEL); ";

    info += "True Positive; ";
    info += "True Negative; ";
    info += "False Positive; ";
    info += "False Negative; ";

    info += "Dice similarity; ";
    info += "F-Measure; ";
    info += "Eroded GT F-Measure; ";
    info += "Dilated Label F-Measure; ";
    info += "Dilated Label and Eroded GT F-Measure; ";
    info += "Binary True Positive; ";
    info += "BinaryTrue Negative; ";
    info += "BinaryFalse Positive; ";
    info += "BinaryFalse Negative; ";
    info += "Binary F-Measure\n";
    fprintf(f,"%s",info.c_str());

    fclose(f);

    return true;
}

void APPStatistics :: ResetData()
{
    map<string, int>::iterator iter;

    for(iter = mIntStats.begin(); iter != mIntStats.end(); iter++)
        iter->second = 0;

    map<string, float>::iterator f_iter;

    for(f_iter = mFloatStats.begin(); f_iter != mFloatStats.end(); f_iter++)
        f_iter->second = 0.0;

    mExpFinished = false;
    mDataSet = false;
}

string APPStatistics :: DisplayInfo()
{
    string info("Experiment saved to file: out/" + mFilename + "\n\n");

    char n[50];

    info += "Filename: " + mImgname;
    info += "\nDate: ";
    info += date;
    info += "\nGT_filename: " + mGTFilename;

    sprintf(n,"\nWidth: %d",mWidth);
    info += n;
    sprintf(n,"\nHeight: %d",mHeight);
    info += n;

    info += "\n\nObject Enhancement statistics:\n";

    int size = mWidth*mHeight;

    size = (size == 0) ? 1 : size;

    sprintf(n,"\nNumber of Runs: %d",mIntStats["runAWE"]);
    info += n;
//    sprintf(n,"\nRuntime: %f ms",mFloatStats["runtimeAWE"]);
//    info += n;
    sprintf(n,"\nRuntime (Gradient): %f ms",mFloatStats["runtimeGrad"]);
    info += n;
    sprintf(n,"\nRuntime (OPF): %f ms",mFloatStats["runtimeOPF"]);
    info += n;
    sprintf(n,"\nRuntime (Watergray): %f ms",mFloatStats["runtimeWater"]);
    info += n;
    sprintf(n,"\nInternal markers: %d",mIntStats["SiAWECount"]);
    info += n;
    sprintf(n,"\nExternal markers: %d",mIntStats["SeAWECount"]);
    info += n;
    sprintf(n,"\nInternal markers pixels: %d",mIntStats["SiAWE"]);
    info += n;
    sprintf(n,"\nExternal markers pixels: %d",mIntStats["SeAWE"]);
    info += n;
    sprintf(n,"\nVolume: %d",mIntStats["volume"]);
    info += n;
    sprintf(n,"\nWobj: %f",mFloatStats["Wobj"]);
    info += n;

    info += "\n\nObject Delineation statistics:\n";

    sprintf(n,"\nNumber of Runs: %d",mIntStats["runSEG"]);
    info += n;
    sprintf(n,"\nRuntime: %f ms",mFloatStats["runtimeSEG"]);
    info += n;
    sprintf(n,"\nInternal markers: %d",mIntStats["SiSEGCount"]);
    info += n;
    sprintf(n,"\nExternal markers: %d",mIntStats["SeSEGCount"]);
    info += n;
    sprintf(n,"\nInternal markers pixels: %d",mIntStats["SiSEG"]);
    info += n;
    sprintf(n,"\nExternal markers pixels: %d",mIntStats["SeSEG"]);
    info += n;
    sprintf(n,"\n\nTrue Positive: %f%%",100*(float)mIntStats["tp"]/(float)size);
    info += n;
    sprintf(n,"\nTrue Negative: %f%%",100*(float)mIntStats["tn"]/(float)size);
    info += n;
    sprintf(n,"\nFalse Positive: %f%%",100*(float)mIntStats["fp"]/(float)size);
    info += n;
    sprintf(n,"\nFalse Negative: %f%%",100*(float)mIntStats["fn"]/(float)size);
    info += n;
    sprintf(n,"\n\nDice Similarity: %f%%",100*mFloatStats["DiceSimilarity"]);
    info += n;
    sprintf(n,"\nFMeasure: %f%%",100*mFloatStats["FMeasure"]);
    info += n;
    sprintf(n,"\nEroded GT FMeasure: %f%%",100*mFloatStats["ErodedFMeasure"]);
    info += n;
    sprintf(n,"\nDilated Label FMeasure: %f%%",100*mFloatStats["DilatedFMeasure"]);
    info += n;
    sprintf(n,"\nDilated Label and Eroded GT FMeasure: %f%%",100*mFloatStats["DilEroFMeasure"]);
    info += n;
    sprintf(n,"\n\nBinary True Positive: %f%%",100*(float)mIntStats["tpbin"]/(float)size);
    info += n;
    sprintf(n,"\nBinary True Negative: %f%%",100*(float)mIntStats["tnbin"]/(float)size);
    info += n;
    sprintf(n,"\nBinary False Positive: %f%%",100*(float)mIntStats["fpbin"]/(float)size);
    info += n;
    sprintf(n,"\nBinary False Negative: %f%%",100*(float)mIntStats["fnbin"]/(float)size);
    info += n;
    sprintf(n,"\n\nBinary FMeasure: %f%%",100*mFloatStats["BinFMeasure"]);
    info += n;
    return info;

}

/** ------------------------------------------------------- **/


APPDataContainer :: APPDataContainer()
{
}

APPDataContainer :: APPDataContainer(const string& key, APPData* data)
{
    SetAPPData(key,data);
}

APPDataContainer :: ~APPDataContainer()
{
    map<string, APPData*>::iterator iter;

    for(iter = mAPPArray.begin(); iter != mAPPArray.end(); iter++)
    {
        if(iter->second != NULL) delete iter->second;
    }

    std::cerr << "APPDataContainer deleted!\n";
}
APPData* APPDataContainer::GetCurAPPData()
{
    return GetAPPData(current_key);
}

void APPDataContainer :: SetAPPData(const string& key, APPData* data)
{
    map<string, APPData*>::iterator iter;
    iter = mAPPArray.find(key);
    if(iter != mAPPArray.end() && iter->second != NULL)
    {
        if(iter->second != NULL) delete iter->second;
        if(_APPDATA_DEBUG_)
        {
            char msg[300];
            sprintf (msg,"Deleting APPData \"%s\"",key.c_str());
            Warning(msg,(char*)"SetAPPData*");

        }
    }else if(_APPDATA_DEBUG_ && iter == mAPPArray.end())
    {
        /// Warns when new data is created, useful for debugging
        char msg[300];
        sprintf(msg,"Creating new APPData* named \"%s\" ",key.c_str());
        Warning(msg,(char*)"SetAPPData*");
    }
    if(_APPDATA_DEBUG_)
    {
        char msg[300];
        sprintf(msg,"Setting new APPData* named \"%s\" ",key.c_str());
        Warning(msg,(char*)"SetAPPData*");
    }
    mAPPArray[key] = data;
}

APPData* APPDataContainer::GetAPPData(const string& key)
{
    map<string, APPData*>::iterator iter;
    iter = mAPPArray.find(key);

    if(iter != this->mAPPArray.end()) return this->mAPPArray[key];

    return NULL;
}

void APPDataContainer::SetCurAPPData(const string& key)
{
    this->current_key = key;
}

int APPDataContainer::Size()
{
    return mAPPArray.size();
}


void app_draw_frames()
{
//    if (!AppData->IsLoaded()) return;
//
//    app_draw_frame(0);
//    app_draw_frame(1);
//    app_draw_frame(2);
//    app_draw_frame(3);
//
//    Views[0]->canvas->Refresh();
//    Views[1]->canvas->Refresh();
//    Views[2]->canvas->Refresh();
//    Views[3]->canvas->Refresh();

}


void app_draw_frame(int plane)
{
//    GraphDrawOptions opt;
//    SparseGraph *sg;
//    CImage *cimg, *caux, *zcimg;
//    Image  *img,*label,*nodeval;
//    Set    *S=NULL;
//    int   p,n,op,Imax;
//    int   sel_highlight, sel_marker, method;
//    float zoom;
//    bool  fill;
//
//    if (!AppData->IsLoaded()) return;
//    Window->GetMethod(&method);
//    Window->GetViewOptions(&sel_highlight, &sel_marker);
//    op = Window->GetOperationMode();
//    if (op<0) return;
//
//    if (AppData->type==TXT_GRAPH)
//    {
//        sg = (AppData->exGraph)->G;
//
//        if ( (sg->A)->n>5 || sg->Wmax>99 )
//            opt.edge_val_align = ALIGN_NONE;
//        else
//            opt.edge_val_align = ALIGN_TOPRIGHT;
//        opt.edge_color_from = 0x000000; 0x0000FF;
//        opt.edge_color_to = 0xFF0000; 0xFF0000;
//
//        opt.node_spacing = 49;
//        opt.node_scale = 0.22;
//        opt.seed_scale = 0.23;
//        opt.node_val_align = ALIGN_CENTER;
//        opt.node_val_font_size = 10.0;
//        opt.edge_val_font_size = 10.0;
//        opt.arrow_w_scale = 0.08;
//        opt.arrow_h_scale = 0.15;
//
//        opt.label2dottype[0].color = AppData->bkgColor;
//        opt.label2dottype[0].bkgcolor = -1;
//        opt.label2dottype[0].label_color = 0x000000;
//        opt.label2dottype[0].border_color = 0xffffff;
//        opt.label2dottype[0].angle = 0.0;
//        opt.label2dottype[0].n = 3;
//        opt.label2dottype[0].dot_type = DOT_TYPE_SIMPLE;
//
//        opt.label2dottype[1].color = AppData->objColor;
//        opt.label2dottype[1].bkgcolor = -1;
//        opt.label2dottype[1].label_color = 0x000000;
//        opt.label2dottype[1].border_color = 0xffffff;
//        opt.label2dottype[1].angle = PI/4.0;
//        opt.label2dottype[1].n = 3;
//        opt.label2dottype[1].dot_type = DOT_TYPE_SIMPLE;
//
//        label = CopyImage(AppData->GetImg("label"));
//        S = AppData->GetAllSeeds(op);
//
//        n = AppData->GetWidth()*AppData->GetHeight();
//        for (p=0; p<n; p++)
//        {
//            if (AppData->IsInternalSeed(p, op))
//                label->val[p] = 1;
//            else if (AppData->IsExternalSeed(p, op))
//                label->val[p] = 0;
//        }
//
//        switch (plane)
//        {
//        case 0:
//            nodeval = AppData->label;
//            Imax = MaximumNotInfinityValue(nodeval);
//            opt.graph_type = GRAPH_TYPE_ALL;
//            opt.node_val_align = ALIGN_NONE;
//            cimg = SparseGraph2CImage((AppData->exGraph)->G,
//                                      NULL, label,
//                                      NULL, S, &opt);
//            WriteCImage(cimg, "canvas1.ppm");
//            break;
//        case 1:
//            nodeval = (AppData->exGraph)->t_link_S;
//            Imax = MaximumNotInfinityValue(nodeval);
//            opt.graph_type = GRAPH_TYPE_ALL;
//            if (Imax<=99) opt.node_val_align = ALIGN_CENTER;
//            else         opt.node_val_align = ALIGN_NONE;
//
//            cimg = SparseGraph2CImage((AppData->exGraph)->G,
//                                      NULL, label,
//                                      nodeval, S, &opt);
//            break;
//        case 2:
//            nodeval = (AppData->exGraph)->t_link_T;
//            Imax = MaximumNotInfinityValue(nodeval);
//            opt.graph_type = GRAPH_TYPE_ALL;
//            if (Imax<=99) opt.node_val_align = ALIGN_CENTER;
//            else         opt.node_val_align = ALIGN_NONE;
//
//            cimg = SparseGraph2CImage((AppData->exGraph)->G,
//                                      NULL, label,
//                                      nodeval, S, &opt);
//            break;
//        case 3:
//            nodeval = AppData->cost;
//            Imax = MaximumNotInfinityValue(nodeval);
//            opt.graph_type = GRAPH_TYPE_FOREST;
//            if (Imax<=99) opt.node_val_align = ALIGN_CENTER;
//            else         opt.node_val_align = ALIGN_NONE;
//
//            cimg = SparseGraph2CImage((AppData->exGraph)->G,
//                                      AppData->pred, label,
//                                      nodeval, S, &opt);
//            WriteCImage(cimg, "canvas4.ppm");
//            break;
//        }
//
//        DestroyImage(&label);
//        DestroySet(&S);
//    }
//    else
//    {
//        switch (plane)
//        {
//        case 0:
//            if ( AppData->bpp>8 )
//            {
//                cimg = (CImage*)calloc(1,sizeof(CImage));
//                cimg->C[0] = ConvertToNbits((AppData->orig)->C[0], 8);
//                cimg->C[1] = ConvertToNbits((AppData->orig)->C[1], 8);
//                cimg->C[2] = ConvertToNbits((AppData->orig)->C[2], 8);
//            }
//            else
//                cimg = CopyCImage(AppData->orig);
//
//            if (op==1 && sel_highlight!=ID_Highlight_Off)
//            {
//                fill = (sel_highlight==ID_Highlight_Fill);
//
//                if (method ==ID_Method_OPF && AppData->regions != NULL)
//                {
//                    caux = APP_HighlightLabels(cimg, AppData->label, AppData->regions, 1.5,
//                                               AppData->objColor, AppData->bkgColor, fill);
//                    DestroyCImage(&cimg);
//                    cimg = caux;
//                }
//                else
//                {
//
//                    caux = CWideHighlight(cimg, AppData->label, 2.9,
//                                          AppData->objColor, fill);
//                    DestroyCImage(&cimg);
//                    cimg = caux;
//                }
//            }
//
//            if (sel_marker==ID_MarkerOnOff_On) AppData->HighlightMarkers(cimg, op);
//            break;
//        case 1:
//            img  = ConvertToNbits((AppData->exGraph)->t_link_S, 8);
//            cimg = Convert2CImage(img);
//            DestroyImage(&img);
//            break;
//        case 2:
//            img  = ConvertToNbits((AppData->exGraph)->t_link_T, 8);
//            cimg = Convert2CImage(img);
//            DestroyImage(&img);
//            break;
//        case 3:
//            img  = ConvertToNbits(AppData->grad, 8);
//            cimg = Convert2CImage(img);
//            DestroyImage(&img);
//            break;
//        }
//    }
//
//    zcimg = cimg;
//
//    Views[plane]->canvas->DrawCImage(cimg);
//
//    if (zcimg!=cimg)
//        DestroyCImage(&zcimg);
//    DestroyCImage(&cimg);
}


void app_reset_frame()
{
//    int op;
//
//    if (!AppData->IsLoaded()) return;
//
//    op = Window->GetOperationMode();
//    if (op==1)
//    {
//        Execution
//        SetImage(AppData->label,        0);
//        SetImage(AppData->pred,         NIL);
//        SetImage(AppData->cost,         INT_MAX);
//        SetImage(AppData->seedLbMap[1], 0);
//        SetImage(AppData->seedMkMap[1], 0);
//        SetImage(AppData->regions,      0);
//        AppData->markerID = MaximumValue(AppData->seedMkMap[0])+1;
//        AppData->checkpoint = 0;
//        Window->RefreshBorderMk();
//    }
//    else if (op==0
//            )  Pre_proc
//    {
//
//        SetImage((AppData->exGraph)->t_link_S, 0);
//        SetImage((AppData->exGraph)->t_link_T, 0);
//        SetImage(AppData->grad,         0);
//        SetImage(AppData->seedLbMap[0], 0);
//        SetImage(AppData->seedMkMap[0], 0);
//        AppData->markerID = MaximumValue(AppData->seedMkMap[1])+1;
//
//        AppData->checkpoint = 0;
//    }
//    if (AppData->frontier!=NULL)
//        DestroySet(&AppData->frontier);
//
//    AppData->frontier = NULL;
//    AppData->closed = false;
}

void APPData_debug_mode(bool on_off)
{
    _APPDATA_DEBUG_ = on_off;
}


