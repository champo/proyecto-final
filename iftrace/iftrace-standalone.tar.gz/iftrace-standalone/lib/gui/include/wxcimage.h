#ifndef _WXCIMAGE_H_
#define _WXCIMAGE_H_

#include "wx/wx.h"

extern "C" {
#include "ift.h"
}

/*! Converts the image frow wxWidgets type (wxImage), to CImage 
 * type. In greyscale images, the value of the pixel
 * is assigned to R,G and B (i.e. C[0],C[1] and C[2]).
 * Notice that the original image is not deleted.
 */
CImage* ConvertToCImage(wxImage& img);

/*! Converts the image from CImage to wxImage. This function does 
 * not free the orignal image.
 */
wxImage* ConvertToWXImage(CImage* cimg);


#endif
