#ifndef _DIFTEXTRAPARAMETERS_H_
#define _DIFTEXTRAPARAMETERS_H_

#include "extraparameters.h"

class DIFTExtraParameters : public ExtraParameters {
public:
  DIFTExtraParameters(wxWindow *parent,
		      wxSizer  *sizer);
  void RefreshParametersLayout();
private:
  wxButton    *buTieZones;
  wxBitmapButton *buVideo;

  wxBoxSizer  *hbsTieZones;
  wxBoxSizer  *hbsVideo;
};

#endif
