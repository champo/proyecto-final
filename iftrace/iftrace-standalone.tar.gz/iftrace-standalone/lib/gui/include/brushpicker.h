#ifndef _BRUSHPICKER_H_
#define _BRUSHPICKER_H_

#include "simplecanvas.h"

extern "C"
{
    #include "ift.h"
}

class BrushPicker : public wxPanel
{
    public:
        BrushPicker(wxWindow *parent,
                    wxWindowID id);
        ~BrushPicker();
        int  GetBrushSize();

        Image* GetBrushCursor();

        void Refresh();

        void OnPress(wxCommandEvent & event);

    private:
        void AddBrush(wxBitmap *bm, int size);

        int n;
        int selection;
        int maxWidth, maxHeight;
        wxWindow *owner;
        wxBitmapButton *up;
        wxBitmapButton *down;
        SimpleCanvas *scanvas;
        wxBitmap **vbitmap;
        int *vsize;

    //DECLARE_EVENT_TABLE()
};



/*
BEGIN_EVENT_TABLE(BrushPicker, wxPanel)
  EVT_BUTTON(ID_BrushPickerUp, BrushPicker::OnUp)
  EVT_BUTTON(ID_BrushPickerDown, BrushPicker::OnDown)
END_EVENT_TABLE()
*/

#endif
