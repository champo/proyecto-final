#ifndef _MYCANVAS_H_
#define _MYCANVAS_H_

#include "canvas.h"

class MyCanvas : public Canvas
{
	public:
		/// Attributes

		//!Methods

		/// Constructor
		MyCanvas(wxWindow *parent);
		~MyCanvas();

	private:
		DECLARE_EVENT_TABLE()
};



#endif
