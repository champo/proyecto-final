#ifndef _OPFEXTRAPARAMETERS_H_
#define _OPFEXTRAPARAMETERS_H_

#include "extraparameters.h"

class OPFExtraParameters : public ExtraParameters
{
    public:
        OPFExtraParameters(wxWindow *parent,
                           wxSizer  *sizer);
        void GetParameters(int *volume, int *area, int *kmax, int *di);
        void RefreshParametersLayout();
    private:
        wxSpinCtrl  *spVolumeOpen;
        wxSpinCtrl  *spAreaOpen;
        wxSpinCtrl  *spKmax;
        wxSpinCtrl  *spImageBand;

        wxButton    *buFilterPDF;
        wxBoxSizer  *hbsVolumeOpen;
        wxBoxSizer  *hbsAreaOpen;
        wxBoxSizer  *hbsFilterPDF;
        wxBoxSizer  *hbsKmax;
        wxBoxSizer  *hbsImageBand;
};

#endif
