#ifndef _IFTGCEXTRAPARAMETERS_H_
#define _IFTGCEXTRAPARAMETERS_H_

#include "extraparameters.h"

class IFTGCExtraParameters : public ExtraParameters {
public:
  IFTGCExtraParameters(wxWindow *parent,
		       wxSizer  *sizer);
  void GetParameters(int *measure, int *maxorder,
		     int *lambda, bool *posproc);
  bool GetAutoRun();
  void RefreshParametersLayout();
private:
  wxChoice    *chCutMeasure;
  wxSpinCtrl  *spMaxOrd;
  wxSpinCtrl  *spLambda;
  wxCheckBox  *cbAutoRun;
  wxCheckBox  *cbPosproc;
  wxButton    *buPlot;
  wxBitmapButton *buVideo;

  wxBoxSizer  *hbsCutMeasure;
  wxBoxSizer  *hbsMaxOrd;
  wxBoxSizer  *hbsLambda;
  wxBoxSizer  *hbsPosproc;
  wxBoxSizer  *hbsPlot;
  wxBoxSizer  *hbsVideo;
};

#endif
