#ifndef _MYFRAME_H_
#define _MYFRAME_H_

#include "gui.h"


class MyFrame: public wxFrame
{

    public:
        MyFrame(const wxString& title, const wxPoint& pos, const wxSize& size);
        ~MyFrame();

        void OnAbout(wxCommandEvent& event);
        void AppendOptPanel(wxPanel *panel);
        void PrependOptPanel(wxPanel *panel);
        bool DetachOptPanel(wxPanel *panel);
        void SetViewPanel(wxPanel *view, int pos);
        wxPanel* GetViewPanel(int pos);
        void SetMode(int id);
        void ToggleMode(int id, bool toggle = true);

        wxString LoadImagePath(const wxString& dirpath = _(""), const wxString& msg = _(""));

        wxString LoadFilePath(const wxString& dirpath = _(""),
            const wxString& windowmsg = _(""), const wxString& msg = _(""), const wxChar *FILETYPES = _T("All files|*.*"));

        wxString SaveFilePath(const wxString& dirpath = _(""),
            const wxString& windowmsg = _(""), const wxString& msg = _(""), const wxChar *FILETYPES = _T("All files|*.*"));

        /// TODO: send to modules
        void OnCreateVideo(wxCommandEvent& event);
        void OnRun(wxCommandEvent& event);
        void OnChangeHighlight(wxCommandEvent& event);
        void OnChangeGradOpt(wxCommandEvent& event);
        void OnChangeMarkerOnOff(wxCommandEvent& event);
        void OnRepeatTrainingSeeds(wxCommandEvent& event);
        void OnShowTieZones(wxCommandEvent& event);
        void OnShowTopology(wxCommandEvent& event);
        void OnShowPlot(wxCommandEvent& event);
        void OnShowGPTree(wxCommandEvent& event);
        void OnFilterPDF(wxCommandEvent& event);
        void OnChangeMaxOrd(wxSpinEvent& event);
        void OnChangeBorderMk(wxCommandEvent& event);
        void OnChangeOri(wxCommandEvent& event);
        int  GetBrushSize();
        void GetViewOptions(int *highlight, int *marker);
        void GetGradOptions(int *type, int *input,
                            float *Wobj);
        void RefreshBorderMk();

        int ChooseLabelColour(int prevcolor);

        /// TODO: send to APPClass
        void OnQuit(wxCommandEvent& event);
        void OnSaveLabel(wxCommandEvent & event);
        void OnSaveObject(wxCommandEvent & event);
        void OnLoadMarkers(wxCommandEvent & event);
        void OnSaveMarkers(wxCommandEvent & event);
        void OnSaveFeats(wxCommandEvent & event);
        void OnSaveObjMap(wxCommandEvent & event);
        void OnSaveBkgMap(wxCommandEvent & event);
        void OnExportGraph(wxCommandEvent & event);
        void EnableOperationMode(int op, bool enable);
        void SetOperationMode(int op);
        int  GetOperationMode();
        void LoadGraph(char *filename);
        void ExportGraph(char *filename);
        void ExportImages(char *filename);
        void OnLoadGraph(wxCommandEvent & event);
        void OnCleanMarkers(wxCommandEvent & event);

        /// Eliminate
        void OnChangeMethod(wxCommandEvent& event);
        void OnChooseClassif(wxCommandEvent& event);
        void GetMethod(int *method);


        ///transform into common functions
        void DisplayImage(wxString filename);
        void DisplayImage(CImage* cimg, wxString filename);
        void DisplayImage(wxImage& img, wxString filename);

        void AppendModuleMenu(const wxString& menuLabel, wxArrayString modLabels, int* modIDArray);

        void OnSelectView(wxCommandEvent & event);
        void UniformView();

    private:

        void SaveMap(Image*, wxString, wxString);
        void FilterSaveType(int, wxBitmapType*,wxString*);
        wxString DefaultFileTypes();


        wxChoice    *chMethod;
        wxChoice    *chHighlight;
        wxChoice    *chGradType;
        wxChoice    *chGradInput;
        wxChoice    *chMarker;
        wxChoice	*chFeatMethod;
        wxChoice	*chClassifMethod;

        wxCheckBox  *cbNormFeats;

//        wxSpinCtrl  *spNscales;
        wxSpinCtrl  *spWobj;
//        wxSpinCtrl  *spMaxDensity;
//        wxSpinCtrl  *spImageBand;
        wxButton    *buRepeat;
        wxButton    *buGPTree;

        wxBoxSizer  *hbsMethod;
        wxBoxSizer  *hbsHighlight;
        wxBoxSizer  *hbsMarker;
        wxBoxSizer	*hbsFeatMethod;
        wxBoxSizer  *hbsGType;
        wxBoxSizer  *hbsGInput;
        wxBoxSizer  *hbsNormFeats;
		wxBoxSizer	*hbsDistMethod;
        wxBoxSizer  *hbsWobj;
//        wxBoxSizer  *hbsMaxDensity;

        ExtraParameters* param;
        BrushPicker *bPicker;

        wxStaticBoxSizer *sgsizer;
        wxStaticBoxSizer *vosizer;
        wxStaticBoxSizer *bpsizer;
        wxStaticBoxSizer *gosizer;
        wxStaticBoxSizer *prsizer;



        wxToolBar      *toolBar;

        wxPanel        *panel;
        wxBoxSizer     *vsizer;
        wxSplitterWindow *splitter;
        wxSplitterWindow *topWindow;
        wxSplitterWindow *bottomWindow;
        wxPanel *Views[4];


        DECLARE_EVENT_TABLE()
};


#endif
