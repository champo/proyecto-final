#ifndef _VIDEOOPT_H_
#define _VIDEOOPT_H_

#include "gui.h"


class VideoOpt
{
    public:
        int ShowConfigDialog(wxWindow *parent);

        typedef enum {GIF, AVI} VideoType;
        VideoType type;

        int GetFPS()
        {
            return fps;
        }

        int GetNFrames()
        {
            return nframes;
        }

        int GetWidth()
        {
            return w;
        }

        int GetHeight()
        {
            return w;
        }

    private:

        int fps;
        int nframes;
        int w,h;

};

#endif
