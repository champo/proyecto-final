
#ifndef _CANVAS_H_
#define _CANVAS_H_

#include "wxgui.h"
extern "C" {
#include "ift.h"
}

#include "interactionhandler.h"

class Canvas : public wxScrolledWindow
{
	public:
		Canvas(wxWindow *parent);
		virtual ~Canvas();

		virtual void OnMouseEvent(wxMouseEvent& event);
		virtual void Draw();

		void DrawCImage(CImage *cimg);
		void ClearFigure();

		void OnPaint(wxPaintEvent& event);

		void Refresh();
		void ZoomIn();
		void ZoomOut();
		void SetZoomLevel(float zoom);
		float GetZoomLevel()
		{
		    return zoom;
		}
        /// Sets the interaction handler, if there is an existing
        /// one it will NOT be deleted
		void SetInteractionHandler(InteractionHandler *handler);

		void GetImageSize(int* width, int* height);

		void GetDisplaySize(int* width, int* height);
		CImage *CopyAsCImage();
		int Canvas2Image(int x, int y, Pixel* p);

	protected:

		float zoom;
		int imageWidth, imageHeight;
		int displayWidth, displayHeight;
		InteractionHandler *handler;
		wxWindow *owner;
		wxMemoryDC *ibuf;
        wxImage *wximg;

	private:
		DECLARE_EVENT_TABLE()
};

#endif

