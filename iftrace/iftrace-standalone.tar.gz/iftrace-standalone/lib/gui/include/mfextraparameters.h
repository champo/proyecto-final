#ifndef _MFEXTRAPARAMETERS_H_
#define _MFEXTRAPARAMETERS_H_

#include "extraparameters.h"

class MFExtraParameters : public ExtraParameters {
public:
  MFExtraParameters(wxWindow *parent,
		    wxSizer  *sizer);
  void GetParameters(int *lambda);
  void RefreshParametersLayout();
private:
  wxSpinCtrl  *spLambda;
  wxBoxSizer  *hbsLambda;
};

#endif
