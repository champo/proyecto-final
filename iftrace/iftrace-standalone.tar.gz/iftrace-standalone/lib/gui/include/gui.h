
#ifndef _GUI_H_
#define _GUI_H_

#include "wxgui.h"
extern "C" {
#include "ift.h"
}

#include "guibasic.h"
#include "basepanel.h"
#include "basedialog.h"
#include "colourbutton.h"
#include "bitmaptogglebutton.h"
#include "bricontrdialog.h"
#include "brushpicker.h"
#include "simplecanvas.h"
#include "canvas.h"
#include "chartwindow.h"
#include "spinslider.h"
#include "labelpanel.h"
#include "interactionhandler.h"
#include "lwirehandler.h"
#include "wxcimage.h"
#include "sliceview.h"
#include "extraparameters.h"
#include "cursor.h"
#include "myframe.h"

void SetColor(wxColour *wxcolor, int color);

typedef struct _plotRange {
  double begin;
  double end;
} PlotRange;


#endif


