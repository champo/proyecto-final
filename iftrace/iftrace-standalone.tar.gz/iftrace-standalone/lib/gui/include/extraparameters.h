#ifndef _EXTRAPARAMETERS_H_
#define _EXTRAPARAMETERS_H_

#include "wxgui.h"


class ExtraParameters {
public:
  ExtraParameters(wxWindow *parent,
		  wxSizer  *sizer);
  virtual ~ExtraParameters();
  bool GetBorderMk();
  //Funcao virtual pura.
  virtual void RefreshParametersLayout()=0;


  typedef enum {BASE, DIFT, TP, IFTGC,MF, KCC, OPF, LWIRE} ParamType;
  ParamType type;

protected:
  wxWindow *parent;
  wxSizer  *sizer;

  wxCheckBox  *cbBorder;
  wxBoxSizer  *hbsBorder;
};

#endif
