#ifndef _LWIREEXTRAPARAMETERS_H_
#define _LWIREEXTRAPARAMETERS_H_

#include "extraparameters.h"

class LWIREExtraParameters : public ExtraParameters 
{
	public:
		LWIREExtraParameters(wxWindow *parent,
				   wxSizer  *sizer);
		void GetParameters(bool *isOri);
		void RefreshParametersLayout();
		void OnCheck(wxCommandEvent & event);

	private:
		wxCheckBox  *cbOri;
		wxBoxSizer  *hbsOri;
};

#endif
