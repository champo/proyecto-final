
#ifndef _LABELPANEL_H_
#define _LABELPANEL_H_

#include "wxgui.h"
#include "gui.h"


class LabelPanel : public BasePanel {
public:
  LabelPanel(wxWindow *parent,
	     wxWindowID id);
  ~LabelPanel();
  void GetName(char *name);
  int  GetColor();
private:
  ColourButton *butColor;
  wxTextCtrl   *texName;
};

#endif

