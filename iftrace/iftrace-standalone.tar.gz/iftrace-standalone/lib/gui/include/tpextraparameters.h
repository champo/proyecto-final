#ifndef _TPEXTRAPARAMETERS_H_
#define _TPEXTRAPARAMETERS_H_

#include "extraparameters.h"

class TPExtraParameters : public ExtraParameters
{
	public:
		TPExtraParameters(wxWindow *parent,
				wxSizer  *sizer);
		void RefreshParametersLayout();

	private:
		wxButton    *buTopology;
		wxBitmapButton *buVideo;

		wxBoxSizer  *hbsTopology;
		wxBoxSizer  *hbsVideo;
};

#endif
