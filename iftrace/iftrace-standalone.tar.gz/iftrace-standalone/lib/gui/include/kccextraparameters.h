#ifndef _KCCEXTRAPARAMETERS_H_
#define _KCCEXTRAPARAMETERS_H_

#include "extraparameters.h"

class KCCExtraParameters : public ExtraParameters {
public:
  KCCExtraParameters(wxWindow *parent,
		     wxSizer  *sizer);
  void GetParameters(int *thres, int *area);
  void RefreshParametersLayout();
private:
  wxSpinCtrl  *spAreaClose;
  wxSpinCtrl  *spSizeTh;
  wxBitmapButton *buVideo;

  wxBoxSizer  *hbsAreaClose;
  wxBoxSizer  *hbsSizeTh;
  wxBoxSizer  *hbsVideo;
};

#endif
