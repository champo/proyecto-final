#ifndef _APPDATATYPE_H_
#define _APPDATATYPE_H_

#include "gui.h"
extern "C" {
#include "ift.h"
#include "code_c.h"
}

#include "code_cpp.h"

#define GREY_IMAGE    0
#define COLOR_IMAGE   1
#define TXT_GRAPH     2

enum{
  ID_Quit = 1,
  ID_About,
  ID_ObjLabelColour,
  ID_BkgLabelColour,
  ID_Pre_proc,
  ID_Execution,
  ID_Run,
  ID_Zoomin,
  ID_Zoomout,
  ID_LoadImg,
  ID_LoadGraph,
  ID_SaveLabel,
  ID_SaveObject,
  ID_SaveObjMBB,
  ID_LoadMark,
  ID_SaveMark,
  ID_ExportGraph,
  ID_ExportImages,
  ID_Method,
  ID_Method_DIFT,
  ID_Method_TP,
  ID_Method_KCC,
  ID_Method_IFT_GC,
  ID_Method_MF,
  ID_Method_OPF,
  ID_Highlight,
  ID_Highlight_Fill,
  ID_Highlight_Border,
  ID_Highlight_Off,
  ID_GradType,
  ID_GradType_Intensity,
  ID_GradType_Sobel,
  ID_GradType_nDim,
  ID_GradType_ColorGrad,
  ID_GradInput,
  ID_GradInput_Image,
  ID_GradInput_ObjMap,
  ID_GradInput_Both,
  ID_Nscales,
  ID_Kmax,
  ID_Wobj,
  ID_MarkerOnOff,
  ID_MarkerOnOff_On,
  ID_MarkerOnOff_Off,
  ID_Contrast,
  ID_Brightness,
  ID_BorderMk,
  ID_Posproc,
  ID_MaxOrd,
  ID_Lambda,
  ID_CutMeasure,
  ID_SizeTh,
  ID_AreaClose,
  ID_AreaOpen,
  ID_VolumeOpen,
  ID_MaxDensity,
  ID_ImageBand,
  ID_ButFilterPDF,
  ID_ButPlot,
  ID_ButRepeat,
  ID_ButTopology,
  ID_ButTieZones,
  ID_AutoRun,
  ID_VideoDIFT,
  ID_VideoTP,
  ID_VideoIFTGC,
  ID_VideoKCC,
  ID_GraphDraw_Label,
  ID_Clean_Markers,
  ID_ChooseFeats,
  ID_Method_LWIRE,
  ID_Ori,
  ID_SaveFeats,
  ID_ChooseClassif,
  ID_SaveObjMap,
  ID_SaveBkgMap,
  ID_ButGPTree
};

class AppDataType{

    public:

        // Attributes

        wxString    filename;

        /// Stores the file original directory name,
        /// used for interface purposes, not essential
        wxString	dirname;

        /// GREY_IMAGE, COLOR_IMAGE, TXT_GRAPH
        int        	type;
        int        	bpp;

        CImage     	*orig;

        Image      	*grad;
        Image      	*pred;
        Image      	*cost;
        Image      	*label;
        Image      	*regions;

        /// Image features
        Features   	*feat;

        ExSparseGraph 	*exGraph;
        Subgraph      	*sg;

        /// LiveWire propagation front.
        Set *frontier;

        bool closed;

        Image      	*seedLbMap[2];
        Image      	*seedMkMap[2];

        Image       *objMap;
        Image       *bkgMap;

        int			markerID, checkpoint;
        int			colormap[256];
        /// Object label color
        int			objColor;
        /// Background label color
        int         bkgColor;

        /// Normalized Features
        Features    *normfeats;

        /// Methods
        AppDataType();
        ~AppDataType();

        bool IsLoaded();
        void SetLoaded(bool);

        bool UseNormalizedFeats() { return this->useNormalized;}
        void SetUseNormalized(bool t) { this->useNormalized = t;}

        void UnloadData();

        void DrawBorderMarker(int markerID);
        void HighlightMarkers(CImage *cimg, int op);

        bool IsInternalSeed(int p, int op);
        bool IsExternalSeed(int p, int op);
        Set *GetInternalSeeds(int op);
        Set *GetExternalSeeds(int op);
        Set *GetNewInternalSeeds(int checkpoint, int op);
        Set *GetNewExternalSeeds(int checkpoint, int op);
        Set *GetAllSeeds(int op);
        int  GetFirstInternalSeed(int op);
        int  GetLastInternalSeed(int op);

        int GetHeight()
        {
            return height;
        }

        int GetWidth()
        {
            return width;
        }

        void CreateData(CImage* img, int type, AdjRel* adj);
        void CreateData(int cols, int rows, int type, ExSparseGraph* exGraph);

        /// Uses the name of the string to try to obtain its type
        void SetImageInfo(wxString filename, wxString dirname);

        wxString GetFilename();

        wxBitmapType GetImageType();


    private:

        /// Tells if the image is loaded or not
        bool loaded;
        /// Tells if features have been normalized
        bool useNormalized;

        int width,height;

        wxBitmapType imageType;

};

void app_draw_frame(int plane);
void app_draw_frames();
void app_reset_frame();



typedef struct _plotRange {
  double begin;
  double end;
} PlotRange;



/** Methods stuff **/


CImage *SparseGraph2CImage(SparseGraph *sg,
			   Image *pred,
			   Image *label,
			   Image *nodeval,
			   Set *seeds,
			   GraphDrawOptions *opt);

CImage *PlotCurve(Curve *C, int w, int h,
		  PlotRange *rangex, PlotRange *rangey,
		  char *title, char *xlabel, char *ylabel,
		  int objColor, int plotColor,
		  bool showmin);

Subgraph *APP_BestkSubgraph(Features *f, Set *Si, Set *Se, Subgraph** rsgeval, float* MaxAcc);
Image *APP_ComputeGradient(CImage *cimg, Image *img, int type);

Image *APP_ComputerBorderStrength(Image *label, Subgraph *sg);

Subgraph *APP_CreateSubgraph(Features *f, int kmax, float di);

CImage *APP_HighlightLabels(CImage *cimg, Image *objlabel,
	Image *bkglabel, float radius, int objcolor, int bkgcolor, bool fill);

Image *APP_StatisticalReconstruction( FeatMap *fmap, int w, int h, int label);

Image *APP_ImagePDF(Subgraph *sg, Features *f,
		    int label, Set *Si, Set *Se);

Image *APP_RemoveRegionByArea(Image *label, int area);

Image *APP_FilterPDF(Subgraph *sg, int volume, int area);

Subgraph *APP_CreateSubgraph(Features *f, int kmax, float di);

Subgraph* APP_OPFLearning(Features *f, Set *Si, Set *Se);

void FastWritePlotVideoFrames(Curve *C,
			      char *title,
			      char *xlabel,
			      char *ylabel,
			      int objColor, int plotColor,
			      int w, int h, FileList *L);


#endif
