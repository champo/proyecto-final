#ifndef _SLICEVIEW_H_
#define _SLICEVIEW_H_

#include "gui.h"

#include "mycanvas.h"

/** This abstract class is the superclass that will be used for
 * instantiating children classes that will actually do the work.
 * It is responsible for storing MyCanvas objects in order to display
 * images (i.e. the segmented image - ColorView class; the
 * object probability map - GreyscaleView class; the background proba-
 * bility map - GreyscaleView class; and the gradient image - GreyscaleView)
 *
 */
class SliceView : public wxPanel
{
	public:

        typedef enum {COLOR, GREYSCALE} ViewType;

		SliceView(wxWindow *parent);
		virtual ~SliceView();

		virtual void ShowCoordinate(Pixel *px);
        virtual SliceView::ViewType GetType();

		void CleanCoordinates();

        /// Image display
        void Refresh();
        void Refresh(CImage* cimg);
        void Refresh(Image* img);

        void ZoomIn();
        void ZoomOut();
		float GetZoomLevel();
        void SetZoomLevel(float zoom);

        void ClearImage();

        /// When the radiometric resolution of the
        /// original image is different, these
        /// methods determine that the real
        /// image pixel value should be displayed
        /// by the ShowCoordinate method
        void SetDataImage(CImage* cimg);
        void SetDataImage(Image* img);

		void SetInteractionHandler(InteractionHandler *handler);

        void SetMsg(const wxString& msg);
        void SetImgCanvasCursor(Image* cur);
        void SetCanvasCursorById(int id);

        /// Events
		void OnLeaveWindow(wxMouseEvent & event);
        void OnEnterWindow(wxMouseEvent & event);

	protected:

        void DisplayImage(CImage* cimg);

        /// Image to be displayed
        CImage* mDisplayImg;
        /// If the image has radiometric resolution > 8, this
        /// image will have different values for each pixel
        CImage* mDataImg;

		MyCanvas       *mCanvas;
		wxWindow       *mOwner;
		wxStaticText   *mCoordinate;

		wxString       mMsg;
        wxCursor* mCanvasCursor;

	private:
		DECLARE_EVENT_TABLE()
};

class ColorView : public SliceView
{
	public:

		ColorView(wxWindow *parent);
        ~ColorView();
		void ShowCoordinate(Pixel *px);
        SliceView :: ViewType GetType();
};

class GreyscaleView : public SliceView
{
	public:

		GreyscaleView(wxWindow *parent);
		~GreyscaleView();

		void ShowCoordinate(Pixel *px);
        SliceView :: ViewType GetType();
};

#endif
