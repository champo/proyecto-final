
#ifndef _INTERACTIONHANDLER_H_
#define _INTERACTIONHANDLER_H_

#include "wxgui.h"

extern "C" {
#include "ift.h"
}


class InteractionHandler {
public:
  InteractionHandler();
  virtual ~InteractionHandler();

  /*!This function is for experts only.
   * Do not redefine it unless you really
   * know what you are doing.
   */
  virtual void OnMouseEvent(wxMouseEvent& event,
			    Pixel p);

protected:
  //!You should redefine the functions below.
	virtual void OnLeftClick(Pixel p);
	virtual void OnRightClick(Pixel p);
	virtual void OnMiddleClick(Pixel p);

	virtual void OnLeftDrag(Pixel p, Pixel q);
	virtual void OnRightDrag(Pixel p, Pixel q);

	virtual void OnLeftRelease(Pixel p);
	virtual void OnRightRelease(Pixel p);
	virtual void OnMiddleRelease(Pixel p);

	virtual void OnMouseMotion(Pixel p);

	virtual void OnMouseWheel(Pixel p,
				int rotation,
				int delta);
	Pixel drag_p;
};

#endif

