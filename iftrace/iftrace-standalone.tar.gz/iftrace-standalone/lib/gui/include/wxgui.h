#ifndef _WXGUI_H_
#define _WXGUI_H_

#include <sys/time.h>
#include <string.h>
#include "wx/wx.h"
#include "wx/bitmap.h"
#include "wx/splitter.h"
#include "wx/spinctrl.h"
#include "wx/tglbtn.h"
#include "wx/valgen.h"
#include "wx/toolbar.h"
#include "wx/tbarbase.h"
#include "wx/msgdlg.h"
#include "wx/busyinfo.h"
#include "wx/statline.h"
#include "wx/treectrl.h"
#include "wx/imaglist.h"
#include "wx/tooltip.h"
#include "wx/tipwin.h"
#include "wx/colordlg.h"
#include "wx/dynarray.h"
#include "wx/arrstr.h"
#include "wx/numdlg.h"

enum
{
    ID_Quit = 1, // used
    ID_About, //used
    ID_ObjLabelColour,
    ID_BkgLabelColour,
    ID_Awe, // used
    ID_Segmentation, //used
    ID_Pre_proc,
    ID_Run, // used
    ID_Zoomin, // used
    ID_Zoomout, // used
    ID_LoadImg, //used
    ID_LoadGraph,
    ID_SaveLabel,
    ID_SaveObject,
    ID_SaveObjMBB,
    ID_LoadMark,
    ID_SaveMark,
    ID_ExportGraph,
    ID_ExportImages,
    ID_Method,
    ID_Method_DIFT,
    ID_Method_TP,
    ID_Method_KCC,
    ID_Method_IFT_GC,
    ID_Method_MF,
    ID_Method_OPF,
    ID_Highlight, // used
    ID_Highlight_Fill,
    ID_Highlight_Border,
    ID_Highlight_Off,
    ID_GradType,
    ID_GradType_Intensity,
    ID_GradType_Sobel,
    ID_GradType_nDim,
    ID_GradType_ColorGrad,
    ID_GradInput,
    ID_GradInput_Image,
    ID_GradInput_ObjMap,
    ID_GradInput_Both,
    ID_Nscales,
    ID_Kmax,
    ID_Wobj, // used
    ID_MarkerOnOff, // used
    ID_MarkerOnOff_On,
    ID_MarkerOnOff_Off,
    ID_Contrast,
    ID_Brightness,
    ID_BorderMk,
    ID_Posproc,
    ID_MaxOrd,
    ID_Lambda,
    ID_CutMeasure,
    ID_SizeTh, //used
    ID_AreaClose, //used
    ID_AreaOpen,
    ID_VolumeOpen,
    ID_MaxDensity,
    ID_ImageBand,
    ID_ButFilterPDF,
    ID_ButPlot,
    ID_ButRepeat, // used
    ID_ButTopology,
    ID_ButTieZones,
    ID_AutoRun,
    ID_VideoDIFT,
    ID_VideoTP,
    ID_VideoIFTGC,
    ID_VideoKCC, // used
    ID_GraphDraw_Label,
    ID_Clean_Markers, // used
    ID_ChooseFeats,
    ID_Method_LWIRE,
    ID_Ori,
    ID_SaveFeats,
    ID_ChooseClassif,
    ID_SaveObjMap,
    ID_SaveBkgMap,
    ID_ButGPTree,
    ID_ChangeMethod,
    ID_ChangeModule, // used
    ID_BPicker, // used
    ID_UseModified, // used
    ID_UseSpatConst, // used
    ID_LoadLabel, // used
    ID_LoadGT, // used
    ID_FinExp, // used
    ID_BuAddSeeds,
    ID_BuDelSeeds,
    ID_CloseHoles, //used
	ID_Watershed, //used
	ID_View0, //used
	ID_View1, //used
	ID_View2, //used
	ID_View3, //used
	ID_View4,  //used
    ID_LoadVideo, //used
    ID_ButNextFrame,
    ID_ButPrevFrame,
    ID_ButFinVGT
};


#endif

