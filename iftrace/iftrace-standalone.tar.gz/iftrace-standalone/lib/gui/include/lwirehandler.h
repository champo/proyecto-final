#ifndef _LWIREHANDLER_H_
#define _LWIREHANDLER_H_

#include "interactionhandler.h"

class LWireHandler : public InteractionHandler
{
	public: 
		
		LWireHandler(bool isOri);
		~LWireHandler();
		
		
	protected:
	
		void OnLeftClick(Pixel p);
		void OnRightClick(Pixel p);
		void OnMiddleClick(Pixel p);
		void OnMouseMotion(Pixel p);
		
	private:
		//! Radius of the pixel to be drawn, has the same size 
		//! of the brush
  		bool isOri;
		int src,dst,init;		
  		int *boundary;
  		
  		bool initLWire(bool right_click, Pixel px);
  		void endLWire();
  		
  		wxMutex mutex;
};

#endif
