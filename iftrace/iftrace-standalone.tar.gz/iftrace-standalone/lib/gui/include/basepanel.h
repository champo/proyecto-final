#ifndef _BASEPANEL_H_
#define _BASEPANEL_H_

#include "wxgui.h"

class BasePanel : public wxPanel
{
    public:
        BasePanel(wxWindow* parent);
        BasePanel();

        virtual ~BasePanel();

        void InitializeBase(wxWindow* parent, int style = wxNO_BORDER);

        virtual void InitPanel(wxWindow* parent);

        bool IsInitialized()
        {
            return is_initialized;
        }

    protected:

        wxWindow *parent;
        wxSizer  *sizer;

        bool is_initialized;
};

#include "gui.h"

#endif

