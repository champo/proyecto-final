
#include "labelpanel.h"


LabelPanel :: LabelPanel(wxWindow *parent,
			 wxWindowID id)
  : BasePanel(parent){

  wxStaticText *tColor = new wxStaticText(this, -1, _T("Color"), wxDefaultPosition, wxDefaultSize, wxALIGN_LEFT, _T("staticText1"));
  wxStaticText *tName = new wxStaticText(this, -1, _T("Name"), wxDefaultPosition, wxDefaultSize, wxALIGN_LEFT, _T("staticText2"));

  butColor = new ColourButton(this, id);
  texName  = new wxTextCtrl(this, id, _T(""), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("textCtrl"));

  wxBoxSizer *hbsColor = new wxBoxSizer(wxHORIZONTAL);
  hbsColor->Add(tColor, 0, wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL);
  hbsColor->Add(butColor, 0, wxALIGN_LEFT);
  this->sizer->Add(hbsColor, 0, wxEXPAND);

  wxBoxSizer *hbsName = new wxBoxSizer(wxHORIZONTAL);
  hbsName->Add(tName, 0, wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL);
  hbsName->Add(texName, 0, wxALIGN_LEFT);
  this->sizer->Add(hbsName, 0, wxEXPAND);

  this->sizer->SetSizeHints(this);
  this->sizer->Layout();
}



LabelPanel :: ~LabelPanel(){
}


void LabelPanel :: GetName(char *name){
  wxString wxstr = texName->GetValue();
  strcpy(name, wxstr.mb_str());
}


int LabelPanel :: GetColor(){
  return butColor->GetValue();
}

