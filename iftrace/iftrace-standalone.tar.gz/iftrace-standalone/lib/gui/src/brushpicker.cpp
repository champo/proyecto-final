#include "brushpicker.h"

#include "cursor.h"

#include "../xpm/adj0.xpm"
#include "../xpm/adj3.xpm"
#include "../xpm/adj6.xpm"
#include "../xpm/adj9.xpm"
#include "../xpm/adj12.xpm"
#include "../xpm/adj15.xpm"
#include "../xpm/adj18.xpm"
#include "../xpm/arrowdown.xpm"
#include "../xpm/arrowup.xpm"


BrushPicker :: BrushPicker(wxWindow *parent,
                           wxWindowID id)
        : wxPanel(parent, wxID_ANY, wxDefaultPosition, wxDefaultSize, wxSIMPLE_BORDER, _T("bpicker"))
{
    owner = parent;
    n = 0;
    maxWidth = maxHeight = 0;
    vbitmap = NULL;
    vsize   = NULL;

    scanvas = new SimpleCanvas(this);

    wxBitmap *bmAdj;

    bmAdj = new wxBitmap(adj0_xpm);
    AddBrush(bmAdj, 0);
    bmAdj = new wxBitmap(adj3_xpm);
    AddBrush(bmAdj, 3);
    bmAdj = new wxBitmap(adj6_xpm);
    AddBrush(bmAdj, 6);
    bmAdj = new wxBitmap(adj9_xpm);
    AddBrush(bmAdj, 9);
    bmAdj = new wxBitmap(adj12_xpm);
    AddBrush(bmAdj, 12);
    bmAdj = new wxBitmap(adj15_xpm);
    AddBrush(bmAdj, 15);
    bmAdj = new wxBitmap(adj18_xpm);
    AddBrush(bmAdj, 18);

    selection = 1;
    Refresh();

    wxBitmap *bmUp = new wxBitmap(arrowup_xpm);

    wxBitmap *bmDown = new wxBitmap(arrowdown_xpm);

    up = new wxBitmapButton(this, id, *bmUp, wxDefaultPosition, wxDefaultSize, wxBU_AUTODRAW, wxDefaultValidator, _T("b_up"));
    down = new wxBitmapButton(this, id, *bmDown, wxDefaultPosition, wxDefaultSize, wxBU_AUTODRAW, wxDefaultValidator, _T("b_down"));

    wxBoxSizer *hsizer = new wxBoxSizer(wxHORIZONTAL);
    hsizer->Add(scanvas, 0, wxEXPAND);

    wxBoxSizer *vsizer = new wxBoxSizer(wxVERTICAL);

    vsizer->Add(up, 0, wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL);
    vsizer->AddSpacer(2);
    vsizer->Add(down, 0, wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL);

    hsizer->Add(vsizer, 0, wxALIGN_LEFT);

    SetSizer(hsizer, true);
    hsizer->SetSizeHints(this);

    Connect( id, wxEVT_COMMAND_BUTTON_CLICKED,
             wxCommandEventHandler(BrushPicker::OnPress),
             NULL, NULL );
}


BrushPicker :: ~BrushPicker()
{
    int id = up->GetId();
    int i;

    for (i = 0;i<n-1;i++)
    {
        delete vbitmap[i];
    }
    if (vsize != NULL) free(vsize);
    Disconnect( id, wxEVT_COMMAND_BUTTON_CLICKED,
                wxCommandEventHandler(BrushPicker::OnPress),
                NULL, NULL );
}


void BrushPicker :: AddBrush(wxBitmap *bm, int size)
{
    wxBitmap **tbitmap;
    int *tsize, i,w,h;

    n++;
    h = bm->GetHeight() + 2;
    w = bm->GetWidth() + 2;
    tbitmap = vbitmap;
    tsize = vsize;
    vbitmap = (wxBitmap **)malloc(sizeof(wxBitmap *)*n);
    vsize = (int *)malloc(sizeof(int)*n);
    i=0;
    if (tsize!=NULL)
    {
        for (;i<n-1;i++)
        {
            vsize[i] = tsize[i];
            vbitmap[i] = tbitmap[i];
        }
        free(tsize);
        free(tbitmap);
    }
    vsize[i] = size;
    vbitmap[i] = bm;

    if (w > maxWidth)
        maxWidth = w;
    if (h > maxHeight)
        maxHeight = h;
    scanvas->SetSize(maxWidth,maxHeight);
}

void BrushPicker :: Refresh()
{
    scanvas->DrawFigure(*(vbitmap[selection]));
    scanvas->Refresh();
}

int  BrushPicker :: GetBrushSize()
{

    if (n==0) return -1;
    return (vsize[selection]);
}


Image* BrushPicker :: GetBrushCursor()
{
    AdjRel* A = Circular((float)this->GetBrushSize());
    Image *bin = AdjRel2Image(A);
    Image *border = ObjectBorder(bin);

    DestroyImage(&bin);
    DestroyAdjRel(&A);

    return border;
}

/// Events

void BrushPicker :: OnPress(wxCommandEvent & event)
{
    if (event.GetEventObject()==up)
    {
        if (selection<n-1)
        {
            selection++;
            Refresh();
        }
    }
    else
    {
        if (selection>0)
        {
            selection--;
            Refresh();
        }
    }

    event.Skip();
}



