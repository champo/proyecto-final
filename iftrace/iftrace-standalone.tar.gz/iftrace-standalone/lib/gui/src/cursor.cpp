#include "cursor.h"


wxCursor *Image2Cursor(Image *img, Image *mask,
                       int hotSpotX, int hotSpotY,
                       float zoom, int color1, int color0)
{
    Image *zimg,*zmask;
    char *down_bits=NULL,*down_mask=NULL;
    int q,p,nr,ncols,nrows,ncolsr,i,j;
    unsigned char selbit = 1;

    hotSpotX *= zoom;
    hotSpotY *= zoom;
    zimg  = Zoom(img, zoom, zoom);
    zmask = Zoom(mask, zoom, zoom);

    ncols = zimg->ncols;
    nrows = zimg->nrows;
    if (ncols!=zmask->ncols || nrows!=zmask->nrows)
        return NULL;

    ncolsr =  (ncols/8 + 1)*8;
    nr = ncolsr*nrows;

    down_bits = AllocCharArray(nr/8);
    down_mask = AllocCharArray(nr/8);
    q = 0;
    for (i=0; i<nrows; i++)
    {
        for (j=0; j<ncolsr; j++)
        {
            p = j+i*ncols;
            if (!ValidPixel(zimg,j,i))
                down_mask[q] &= ~selbit;
            else
            {
                if (zimg->val[p]>0)  down_bits[q] |= selbit;
                else   	            down_bits[q] &= ~selbit;
                if (zmask->val[p]>0) down_mask[q] |= selbit;
                else                down_mask[q] &= ~selbit;
            }
            if (selbit==128)
            {
                q++;
                selbit = 1;
            }
            else selbit<<=1;
        }
    }

    wxColour wxcolor1;
    wxColour wxcolor0;
    SetColor(&wxcolor1, color1);
    SetColor(&wxcolor0, color0);

#ifdef __WXMSW__
    wxBitmap down_bitmap(down_bits, ncolsr, nrows);
    wxBitmap down_mask_bitmap(down_mask, ncolsr, nrows);

    down_bitmap.SetMask(new wxMask(down_mask_bitmap));
    wxImage down_image = down_bitmap.ConvertToImage();
    down_image.SetOption(wxIMAGE_OPTION_CUR_HOTSPOT_X, hotSpotX);
    down_image.SetOption(wxIMAGE_OPTION_CUR_HOTSPOT_Y, hotSpotY);
    wxCursor *down_cursor = new wxCursor(down_image);
#else
    wxCursor *down_cursor = new wxCursor(down_bits, ncolsr, nrows,
                                         hotSpotX, hotSpotY, down_mask,
                                         &wxcolor1, &wxcolor0);
#endif

    free(down_bits);
    free(down_mask);
    DestroyImage(&zimg);
    DestroyImage(&zmask);

    return down_cursor;
}



wxCursor *CrossCursor(int zoom)
{
    wxCursor *cursor=NULL;
    Image *img,*bin;
    static int vimg[]={0,0,0,0,0,1,0,0,0,0,0,
                       0,0,0,0,0,1,0,0,0,0,0,
                       0,0,0,0,0,1,0,0,0,0,0,
                       0,0,0,0,0,1,0,0,0,0,0,
                       0,0,0,0,0,1,0,0,0,0,0,
                       1,1,1,1,1,0,1,1,1,1,1,
                       0,0,0,0,0,1,0,0,0,0,0,
                       0,0,0,0,0,1,0,0,0,0,0,
                       0,0,0,0,0,1,0,0,0,0,0,
                       0,0,0,0,0,1,0,0,0,0,0,
                       0,0,0,0,0,1,0,0,0,0,0
                      };

    static int vbin[]={0,0,0,0,1,1,1,0,0,0,0,
                       0,0,0,0,1,1,1,0,0,0,0,
                       0,0,0,0,1,1,1,0,0,0,0,
                       0,0,0,0,1,1,1,0,0,0,0,
                       1,1,1,1,1,1,1,1,1,1,1,
                       1,1,1,1,1,0,1,1,1,1,1,
                       1,1,1,1,1,1,1,1,1,1,1,
                       0,0,0,0,1,1,1,0,0,0,0,
                       0,0,0,0,1,1,1,0,0,0,0,
                       0,0,0,0,1,1,1,0,0,0,0,
                       0,0,0,0,1,1,1,0,0,0,0
                      };

    img = CreateImage(11,11);
    bin = CreateImage(11,11);

    memcpy(img->val, vimg, sizeof(int)*121);
    memcpy(bin->val, vbin, sizeof(int)*121);

    cursor = Image2Cursor(img, bin, 5, 5, zoom,
                          0x000000, 0xFFFFFF);
    DestroyImage(&img);
    DestroyImage(&bin);

    return cursor;
}





