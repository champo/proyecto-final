#include "tpextraparameters.h"

#ifndef _VIDEO_XPM_
#define _VIDEO_XPM_
#include "video.xpm"
#endif

TPExtraParameters :: TPExtraParameters(wxWindow *parent,
				       wxSizer  *sizer)
  : ExtraParameters(parent, sizer){
  this->type = TP;
  buTopology = new wxButton(parent, ID_ButTopology, _T("Show Topology"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("button1"));

  hbsTopology = new wxBoxSizer(wxHORIZONTAL);
  hbsTopology->Add(buTopology, 1, wxALIGN_CENTER);
  sizer->Add(hbsTopology, 0, wxEXPAND);

  wxStaticText *tVideo = new wxStaticText(parent, -1, _T("Leaking Detection"), wxDefaultPosition, wxDefaultSize, wxALIGN_LEFT, _T("staticText1"));

  wxBitmap *bmVideo = new wxBitmap(video_xpm);
  buVideo = new wxBitmapButton(parent, ID_VideoTP, *bmVideo, wxDefaultPosition, wxDefaultSize, wxBU_AUTODRAW, wxDefaultValidator, _T("b_video"));

  hbsVideo = new wxBoxSizer(wxHORIZONTAL);
  hbsVideo->Add(tVideo,  0, wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL);
  hbsVideo->Add(buVideo, 0, wxALIGN_LEFT);
  sizer->Add(hbsVideo, 0, wxEXPAND);
}

void TPExtraParameters :: RefreshParametersLayout(){}
