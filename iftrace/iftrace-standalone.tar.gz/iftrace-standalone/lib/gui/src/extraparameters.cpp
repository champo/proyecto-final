#include "extraparameters.h"

ExtraParameters :: ExtraParameters(wxWindow *parent,
				   wxSizer  *sizer){
  this->parent = parent;
  this->sizer = sizer;
  this->type = BASE;

  cbBorder = new wxCheckBox(parent, ID_BorderMk, _T("Border marker"), wxDefaultPosition, wxDefaultSize, wxCHK_2STATE, wxDefaultValidator, _T("checkBox1"));

  hbsBorder = new wxBoxSizer(wxHORIZONTAL);

  hbsBorder->Add(cbBorder, 1, wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL);
  sizer->AddSpacer(5);
  sizer->Add(hbsBorder, 0, wxEXPAND);
}

ExtraParameters :: ~ExtraParameters(){
  sizer->Clear(true);
}

bool ExtraParameters :: GetBorderMk(){
  return cbBorder->GetValue();
}
