#include "iftgcextraparameters.h"

#ifndef _VIDEO_XPM_
#define _VIDEO_XPM_
#include "video.xpm"
#endif

extern "C"
{
    #include "code_c.h"
}

IFTGCExtraParameters :: IFTGCExtraParameters(wxWindow *parent,
					     wxSizer  *sizer)
  : ExtraParameters(parent, sizer){
  this->type = IFTGC;
  cbPosproc = new wxCheckBox(parent, ID_Posproc, _T("Close Holes"), wxDefaultPosition, wxDefaultSize, wxCHK_2STATE, wxDefaultValidator, _T("checkBox2"));

  wxStaticText *tCutMeasure = new wxStaticText(parent, -1, _T("Measure"), wxDefaultPosition, wxDefaultSize, wxALIGN_LEFT, _T("staticText1"));
  wxStaticText *tMaxOrd   = new wxStaticText(parent, -1, _T("Max order"), wxDefaultPosition, wxDefaultSize, wxALIGN_LEFT, _T("staticText2"));
  wxStaticText *tLambda   = new wxStaticText(parent, -1, _T("Lambda"), wxDefaultPosition, wxDefaultSize, wxALIGN_LEFT, _T("staticText3"));

  wxString cmChoices[4];
  cmChoices[0] = _T("Mean cut");
  cmChoices[1] = _T("Normalized");
  cmChoices[2] = _T("Energy func");
  cmChoices[3] = _T("None");
  chCutMeasure = new wxChoice(parent, ID_CutMeasure, wxDefaultPosition, wxDefaultSize, 4, cmChoices, 0, wxDefaultValidator, _T("choice7"));
  chCutMeasure->SetSelection(0);

  wxSize spsize(50, -1);
  spMaxOrd = new wxSpinCtrl(parent, ID_MaxOrd, wxEmptyString, wxDefaultPosition, spsize, wxSP_ARROW_KEYS, 1, 100, 75, _T("wxSpinCtrl1"));

  cbAutoRun = new wxCheckBox(parent, ID_AutoRun, _T("Run"), wxDefaultPosition, wxDefaultSize, wxCHK_2STATE, wxDefaultValidator, _T("checkBox3"));

  spLambda = new wxSpinCtrl(parent, ID_Lambda, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxSP_ARROW_KEYS, 0, 500, 40, _T("wxSpinCtrl1"));
  buPlot = new wxButton(parent, ID_ButPlot, _T("Plot"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("button1"));

  wxStaticText *tVideo = new wxStaticText(parent, -1, _T("Cut Curve"), wxDefaultPosition, wxDefaultSize, wxALIGN_LEFT, _T("staticText1"));

  wxBitmap *bmVideo = new wxBitmap(video_xpm);
  buVideo = new wxBitmapButton(parent, ID_VideoIFTGC, *bmVideo, wxDefaultPosition, wxDefaultSize, wxBU_AUTODRAW, wxDefaultValidator, _T("b_video"));

  hbsPosproc    = new wxBoxSizer(wxHORIZONTAL);
  hbsCutMeasure = new wxBoxSizer(wxHORIZONTAL);
  hbsMaxOrd     = new wxBoxSizer(wxHORIZONTAL);
  hbsLambda     = new wxBoxSizer(wxHORIZONTAL);
  hbsPlot       = new wxBoxSizer(wxHORIZONTAL);
  hbsVideo      = new wxBoxSizer(wxHORIZONTAL);

  hbsPosproc->Add(cbPosproc, 1, wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL);
  hbsCutMeasure->Add(tCutMeasure, 1, wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL);
  hbsCutMeasure->Add(chCutMeasure, 0, wxALIGN_RIGHT);
  hbsMaxOrd->Add(tMaxOrd, 1, wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL);
  hbsMaxOrd->Add(spMaxOrd, 0, wxALIGN_LEFT);
  hbsMaxOrd->Add(cbAutoRun, 0, wxALIGN_RIGHT);
  hbsLambda->Add(tLambda,  1, wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL);
  hbsLambda->Add(spLambda, 0, wxALIGN_RIGHT);
  hbsPlot->Add(buPlot, 1, wxALIGN_CENTER);
  hbsVideo->Add(tVideo,  0, wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL);
  hbsVideo->Add(buVideo, 0, wxALIGN_LEFT);

  sizer->Add(hbsPosproc,    0, wxEXPAND);
  sizer->Add(hbsCutMeasure, 0, wxEXPAND);
  sizer->Add(hbsMaxOrd,     0, wxEXPAND);
  sizer->Add(hbsLambda,     0, wxEXPAND);
  sizer->Add(hbsPlot,       0, wxEXPAND);
  sizer->Add(hbsVideo,      0, wxEXPAND);
}

void IFTGCExtraParameters::GetParameters(int *measure, int *maxorder,
					 int *lambda, bool *posproc){
  int sel;

  sel = chCutMeasure->GetSelection();
  switch(sel){
  case 0: *measure = MEAN_CUT;       break;
  case 1: *measure = NORMALIZED_CUT; break;
  case 2: *measure = ENERGY_FUNC;    break;
  case 3: *measure = LAST_BOUNDARY;  break;
  }
  *posproc  = cbPosproc->GetValue();
  *maxorder = spMaxOrd->GetValue();
  *lambda   = spLambda->GetValue();
}

bool IFTGCExtraParameters::GetAutoRun(){
  return cbAutoRun->GetValue();
}

void IFTGCExtraParameters :: RefreshParametersLayout(){}
