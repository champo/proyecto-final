#include "videoopt.h"


int VideoOpt::ShowConfigDialog(wxWindow *parent)
{
    wxDialog *dialog = new wxDialog(parent, -1, _T(""), wxDefaultPosition, wxDefaultSize, wxDEFAULT_DIALOG_STYLE | wxRESIZE_BORDER, _T("dialogBox"));

    wxBoxSizer *vsizer = new wxBoxSizer(wxVERTICAL);

    wxStaticText *tFPS = new wxStaticText(dialog, -1, _T("fps"), wxDefaultPosition, wxDefaultSize, wxALIGN_LEFT, _T("staticText1"));
    wxStaticText *tNFR = new wxStaticText(dialog, -1, _T("nframes"), wxDefaultPosition, wxDefaultSize, wxALIGN_LEFT, _T("staticText2"));
    wxStaticText *tTYP = new wxStaticText(dialog, -1, _T("type"), wxDefaultPosition, wxDefaultSize, wxALIGN_LEFT, _T("staticText3"));
    wxStaticText *tRES = new wxStaticText(dialog, -1, _T("resolution"), wxDefaultPosition, wxDefaultSize, wxALIGN_LEFT, _T("staticText4"));

    wxSpinCtrl *spFPS = new wxSpinCtrl(dialog, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxSP_ARROW_KEYS, 1, 100, 15, _T("wxSpinCtrl1"));
    wxSpinCtrl *spNFR = new wxSpinCtrl(dialog, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxSP_ARROW_KEYS, 1, 1000, 30, _T("wxSpinCtrl2"));

    wxString tyChoices[2];
    tyChoices[0] = _T("GIF");
    tyChoices[1] = _T("AVI");
    wxChoice *chTYP = new wxChoice(dialog, wxID_ANY, wxDefaultPosition, wxDefaultSize, 2, tyChoices, 0, wxDefaultValidator, _T("choice1"));
    chTYP->SetSelection(0);

    wxString resChoices[2];
    resChoices[0] = _T("320x240");
    resChoices[1] = _T("640x480");
    wxChoice *chRES = new wxChoice(dialog, wxID_ANY, wxDefaultPosition, wxDefaultSize, 2, resChoices, 0, wxDefaultValidator, _T("choice2"));
    chRES->SetSelection(0);

    wxBoxSizer *hbsFPS = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer *hbsNFR = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer *hbsTYP = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer *hbsRES = new wxBoxSizer(wxHORIZONTAL);

    hbsFPS->Add(tFPS,  1, wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL);
    hbsFPS->Add(spFPS, 0, wxALIGN_RIGHT);
    hbsNFR->Add(tNFR,  1, wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL);
    hbsNFR->Add(spNFR, 0, wxALIGN_RIGHT);
    hbsTYP->Add(tTYP,  1, wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL);
    hbsTYP->Add(chTYP, 0, wxALIGN_RIGHT);
    hbsRES->Add(tRES,  1, wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL);
    hbsRES->Add(chRES, 0, wxALIGN_RIGHT);

    wxStaticLine *sline1 = new wxStaticLine(dialog, wxID_ANY, wxDefaultPosition, wxDefaultSize, wxLI_HORIZONTAL, _T("staticLine1"));
    wxSizer *sbutton = dialog->CreateButtonSizer(wxOK|wxCANCEL);

    vsizer->AddSpacer(10);
    vsizer->Add(hbsFPS,     0, wxEXPAND);
    vsizer->Add(hbsNFR,     0, wxEXPAND);
    vsizer->Add(hbsTYP,     0, wxEXPAND);
    vsizer->Add(hbsRES,     0, wxEXPAND);
    vsizer->Add(sline1,     0, wxEXPAND);
    vsizer->Add(sbutton,    0, wxEXPAND);
    dialog->SetSizer(vsizer, true);
    vsizer->SetSizeHints(dialog);
    vsizer->Layout();

    //----- Show Window ----------
    wxWindowDisabler disableAll(dialog);
    wxTheApp->Yield();

    dialog->SetTitle(_T("Video Options"));
    vsizer->SetSizeHints(dialog);
    vsizer->Layout();

    if (dialog->ShowModal()==wxID_OK)
    {
        this->fps = spFPS->GetValue();
        this->nframes = spNFR->GetValue();
        int sel;
        sel = chTYP->GetSelection();
        switch (sel)
        {
        case 0:
            this->type = VideoOpt::GIF;
            break;
        case 1:
            this->type = VideoOpt::AVI;
            break;
        }
        sel = chRES->GetSelection();
        switch (sel)
        {
        case 0:
            this->w = 320;
            this->h = 240;
            break;
        case 1:
            this->w = 640;
            this->h = 480;
            break;
        }
        return 0;
    }
    else
    {
        this->fps = 0;
        this->nframes = 0;
        return 1;
    }
}
