#include "sliceview.h"

BEGIN_EVENT_TABLE(SliceView, wxPanel)
    EVT_LEAVE_WINDOW(SliceView::OnLeaveWindow)
    EVT_ENTER_WINDOW(SliceView::OnEnterWindow)
END_EVENT_TABLE()

SliceView :: SliceView(wxWindow *parent)
        : wxPanel(parent, wxID_ANY, wxDefaultPosition, wxDefaultSize,wxSIMPLE_BORDER)
{

    mOwner = parent;

    mDisplayImg = NULL;
    mDataImg = NULL;
    mCanvasCursor = NULL;

    wxBoxSizer *vsizer = new wxBoxSizer(wxVERTICAL);

    mCanvas = new MyCanvas(this);
    mMsg = wxString(_(""));
    mCoordinate = new wxStaticText(this, -1, mMsg, wxDefaultPosition, wxDefaultSize, wxALIGN_LEFT, _T("mCoordinate"));

    wxBoxSizer *hsizer = new wxBoxSizer(wxHORIZONTAL);

    hsizer->AddSpacer(20);
    hsizer->Add(mCoordinate, 0, wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL);

    vsizer->Add(mCanvas, 1, wxEXPAND);
    vsizer->Add(hsizer, 0, wxALIGN_LEFT|wxEXPAND);

    SetSizer(vsizer, true);
    vsizer->SetSizeHints(this);
}

SliceView :: ~SliceView()
{
    delete this->mCanvas;
    delete this->mCoordinate;

    delete this->mCanvasCursor;

    if(this->mDisplayImg != NULL) DestroyCImage(&(this->mDisplayImg));
    if(this->mDataImg != NULL) DestroyCImage(&(this->mDataImg));

}

void SliceView :: DisplayImage(CImage* cimg)
{
    if(cimg == NULL) return;

    if(this->mDisplayImg != NULL) DestroyCImage(&(this->mDisplayImg));

    this->mDisplayImg = CopyCImage(cimg);

    this->mCanvas->DrawCImage(this->mDisplayImg);
}

void SliceView :: Refresh()
{
    if(this->mDisplayImg == NULL || this->mCanvas == NULL) return;

    this->mCanvas->Refresh();
}

void SliceView :: Refresh(CImage* cimg)
{
    DisplayImage(cimg);
    Refresh();
}

void SliceView :: Refresh(Image* img)
{
    if(img == NULL) return;

    if(this->mDisplayImg != NULL) DestroyCImage(&(this->mDisplayImg));

    this->mDisplayImg = Convert2CImage(img);

    this->mCanvas->DrawCImage(this->mDisplayImg);

    Refresh();
}

void SliceView :: ZoomIn()
{
    if(this->mCanvas == NULL) return;

    mCanvas->ZoomIn();
}

void SliceView :: ZoomOut()
{
    if(this->mCanvas ==  NULL) return;

    mCanvas->ZoomOut();
}

float SliceView :: GetZoomLevel()
{
    return mCanvas->GetZoomLevel();
}

void SliceView :: SetZoomLevel(float zoom)
{
    mCanvas->SetZoomLevel(zoom);
}

void SliceView :: ClearImage()
{
    if(this->mCanvas == NULL) return;

    DestroyCImage(&mDisplayImg);
    DestroyCImage(&mDataImg);

    mCanvas->ClearFigure();
    mCanvas->Refresh();
}

void SliceView :: SetDataImage(CImage* cimg)
{
    if(this->mDataImg != NULL) DestroyCImage(&(this->mDataImg));

    this->mDataImg = CopyCImage(cimg);
}

void SliceView :: SetDataImage(Image* img)
{
    if(this->mDataImg != NULL) DestroyCImage(&(this->mDataImg));

    this->mDataImg = Convert2CImage(img);
}

void SliceView :: SetInteractionHandler(InteractionHandler *handler)
{
    mCanvas->SetInteractionHandler(handler);
}

void SliceView :: SetMsg(const wxString& msg)
{
    mMsg = wxString(msg);
    mCoordinate->SetLabel(mMsg);
}

SliceView :: ViewType SliceView :: GetType()
{
    return SliceView :: COLOR;
}

void SliceView :: ShowCoordinate(Pixel *px)
/// This method needs to be empty for it is a virtual method
{
}

void SliceView :: CleanCoordinates()
{
    mCoordinate->SetLabel(mMsg);
}

void SliceView :: SetImgCanvasCursor(Image* cur)
{
    if(mCanvas == NULL) return;
    if(mCanvasCursor != NULL) delete mCanvasCursor;

    if(cur == NULL)
    {
        mCanvasCursor = new wxCursor(*wxSTANDARD_CURSOR);
        return;
    }

    int ncols,nrows;

    ncols = cur->ncols;
    nrows = cur->nrows;
    if (ncols*nrows==1) cur->val[0] = 1;

    float zoom = mCanvas->GetZoomLevel();

    /// preventing vanishing of cursor
    if(zoom < 1.0 && ncols <= 7 && nrows <= 7) zoom = 1.0;

    mCanvasCursor = Image2Cursor(cur, cur, ncols/2, nrows/2, zoom, 0xFFFFFF, 0x000000);

}

void SliceView :: SetCanvasCursorById(int id)
{
    if(mCanvas == NULL) return;
    if(mCanvasCursor != NULL) delete mCanvasCursor;

    mCanvasCursor = new wxCursor(id);
}

/// Events

void SliceView::OnLeaveWindow(wxMouseEvent & event)
{
    CleanCoordinates();
    mCanvas->SetCursor(*wxSTANDARD_CURSOR);
}

void SliceView :: OnEnterWindow(wxMouseEvent& event)
{

}

///------- ColorView Class --------///

ColorView :: ColorView(wxWindow* parent) : SliceView(parent)
{
}

ColorView :: ~ColorView()
{
}

void ColorView :: ShowCoordinate(Pixel *px)
{
    wxString coord;
    int p,R,G,B;

    if(this->mDisplayImg == NULL) return;

    CImage* cimg;

    if(this->mDataImg == NULL)
        cimg = this->mDisplayImg;
    else
        cimg = this->mDataImg;

    if(mCanvasCursor != NULL)
    {
//        if(mCanvas->GetCursor() == *mCanvasCursor) cerr << "droga!!";
        mCanvas->SetCursor(*mCanvasCursor);
    }

    if (px!=NULL)
    {
        p = px->x + cimg->C[0]->tbrow[px->y];

        R = cimg->C[0]->val[p];
        G = cimg->C[1]->val[p];
        B = cimg->C[2]->val[p];

        coord.Printf(_("pixel (%d,%d) = (R:%d,G:%d,B:%d)"),px->x,px->y,R,G,B);
        if(mMsg != _(""))
            mCoordinate->SetLabel(mMsg + _(" - ") + coord);
        else
            mCoordinate->SetLabel(coord);
    }
    else
    {
        mCoordinate->SetLabel(mMsg);
    }
}

SliceView :: ViewType ColorView :: GetType()
{
    return SliceView :: COLOR;
}

///------- GreyscaleView Class  --------///

GreyscaleView :: GreyscaleView(wxWindow* parent) : SliceView(parent)
{
}

GreyscaleView :: ~GreyscaleView()
{
}

void GreyscaleView :: ShowCoordinate(Pixel *px)
{
    wxString coord;
    int p,V;
    Image* aux;

    if(this->mDataImg == NULL)
        aux = this->mDisplayImg->C[0];
    else
        aux = this->mDataImg->C[0];

    if(mCanvasCursor != NULL)
    {
//        if(mCanvas->GetCursor() == *mCanvasCursor) cerr << "droga!!";
        mCanvas->SetCursor(*mCanvasCursor);
    }
    if (px!=NULL)
    {
        p = px->x + aux->tbrow[px->y];

        V = aux->val[p];

        coord.Printf(_("pixel (%d,%d) = %d"),px->x,px->y,V);
        if(mMsg != _(""))
            mCoordinate->SetLabel(mMsg + _(" - ") + coord);
        else
            mCoordinate->SetLabel(coord);
    }
    else
    {
        mCoordinate->SetLabel(mMsg);
    }
}

SliceView :: ViewType GreyscaleView :: GetType()
{
    return SliceView :: GREYSCALE;
}
