#include "appdata_old.h"

#include "myframe.h"
#include "sliceview.h"
#include "graphdrawoptdialog.h"

extern APPData* AppData;
extern SliceView *Views[4];
extern MyFrame   *Window;

AppDataType::AppDataType()
{
    this->closed = false;
    this->markerID = 1;
    this->checkpoint = 0;
    this->objColor = 0xffff00;
    this->bkgColor = 0x1e90ff;//0xffffff;

    this->orig = NULL;

    this->grad = NULL;
    this->pred = NULL;
    this->cost = NULL;
    this->label = NULL;
    this->regions = NULL;
    this->objMap = NULL;
    this->bkgMap = NULL;

    this->feat = NULL;

    this->exGraph = NULL;
    this->sg = NULL;

    this->frontier = NULL;
    this->loaded = false;
    this->useNormalized = false;

    this->normfeats = NULL;
}

AppDataType::~AppDataType()
{
    UnloadData();
}

bool AppDataType::IsLoaded()
{
    return loaded;
}

void AppDataType::SetLoaded(bool l)
{
    this->loaded = l;
}

void AppDataType::UnloadData()
{
    if (IsLoaded())
    {
        DestroyCImage(&(orig));
        DestroyImage(&(grad));
        DestroyImage(&(pred));
        DestroyImage(&(cost));
        DestroyImage(&(label));
        DestroyImage(&(regions));
        DestroySubgraph(&(sg));
        DestroyExSparseGraph(&(exGraph));
        DestroyFeatures(&(feat));
        DestroyFeatures(&(normfeats));
        DestroyImage(&(seedLbMap[0]));
        DestroyImage(&(seedLbMap[1]));
        DestroyImage(&(seedMkMap[0]));
        DestroyImage(&(seedMkMap[1]));
        this->loaded = false;
        this->useNormalized = false;

    }
}

void AppDataType::CreateData(int cols, int rows, int type, ExSparseGraph* exGraph)
{
    this->orig     = CreateCImage(cols, rows);


    this->grad     = CreateImage(cols, rows);
    this->pred     = CreateImage(cols, rows);
    this->cost     = CreateImage(cols, rows);
    this->label    = CreateImage(cols, rows);

    this->seedLbMap[0] = CreateImage(cols, rows);
    this->seedLbMap[1] = CreateImage(cols, rows);
    this->seedMkMap[0] = CreateImage(cols, rows);
    this->seedMkMap[1] = CreateImage(cols, rows);

    this->exGraph  = exGraph;

    this->height = rows;
    this->width = cols;


    this->type = type;

    this->useNormalized = false;

}


void AppDataType::CreateData(CImage* img, int type, AdjRel* adj)
{

    if(img == NULL || img->C[0] == NULL) return;

    if(this->loaded == true) UnloadData();

    int cols = img->C[0]->ncols;
    int rows = img->C[0]->nrows;

    this->orig     = img;

    this->grad     = CreateImage(cols, rows);
    this->pred     = CreateImage(cols, rows);
    this->cost     = CreateImage(cols, rows);
    this->label    = CreateImage(cols, rows);

    this->seedLbMap[0] = CreateImage(cols, rows);
    this->seedLbMap[1] = CreateImage(cols, rows);
    this->seedMkMap[0] = CreateImage(cols, rows);
    this->seedMkMap[1] = CreateImage(cols, rows);

    this->feat     = NULL;

    if(adj != NULL)
        this->exGraph  = CreateExSparseGraph(cols, rows, adj);

    this->height = rows;
    this->width = cols;

    this->type = type;
    this->useNormalized = false;

}

void AppDataType::DrawBorderMarker(int markerID)
{
    Set *B=NULL,*seeds=NULL;
    int p;

    //B = ImageBorder(AppData->grad);
    B = ImageWideBorder(AppData->grad, 4); //3

    seeds = B;
    while (seeds != NULL)
    {
        p = seeds->elem;

        if (markerID>0)
        {
            if ((AppData->seedMkMap[1])->val[p]==0)
            {
                (AppData->seedMkMap[1])->val[p] = markerID;
                (AppData->seedLbMap[1])->val[p] = 0;
            }
        }
        else if (markerID==0)
        {
            if ((AppData->seedLbMap[1])->val[p]==0)
            {
                (AppData->seedMkMap[1])->val[p] = 0;
            }
        }

        seeds = seeds->next;
    }

    DestroySet(&B);
}

void AppDataType::HighlightMarkers(CImage *cimg, int op)
{
    Image *LbMap = AppData->seedLbMap[op];
    Image *MkMap = AppData->seedMkMap[op];
    int p,n,lb,color;

    n = cimg->C[0]->ncols*cimg->C[0]->nrows;
    for (p=0; p<n; p++)
    {
        if (MkMap->val[p]>0)
        {
            lb = LbMap->val[p];
            if (lb>0) color = AppData->objColor;
            else     color = AppData->bkgColor;
            cimg->C[0]->val[p] = t0(color);
            cimg->C[1]->val[p] = t1(color);
            cimg->C[2]->val[p] = t2(color);
        }
    }
}


bool AppDataType::IsInternalSeed(int p, int op)
{
    Image *LbMap = AppData->seedLbMap[op];
    Image *MkMap = AppData->seedMkMap[op];

    if (MkMap->val[p]>0)
        if (LbMap->val[p]>0)
            return true;

    return false;
}


bool AppDataType::IsExternalSeed(int p, int op)
{
    Image *LbMap = AppData->seedLbMap[op];
    Image *MkMap = AppData->seedMkMap[op];

    if (MkMap->val[p]>0)
        if (LbMap->val[p]==0)
            return true;

    return false;
}


Set *AppDataType::GetInternalSeeds(int op)
{
    Image *LbMap = AppData->seedLbMap[op];
    Image *MkMap = AppData->seedMkMap[op];
    Set *S=NULL;
    int p,n;

    n = LbMap->ncols*LbMap->nrows;
    for (p=0; p<n; p++)
    {
        if (MkMap->val[p]>0)
        {
            if (LbMap->val[p]>0)
                InsertSet(&S, p);
        }
    }

    return S;
}


Set *AppDataType::GetExternalSeeds(int op)
{
    Image *LbMap = AppData->seedLbMap[op];
    Image *MkMap = AppData->seedMkMap[op];
    Set *S=NULL;
    int p,n;

    n = LbMap->ncols*LbMap->nrows;
    for (p=0; p<n; p++)
    {
        if (MkMap->val[p]>0)
        {
            if (LbMap->val[p]==0)
                InsertSet(&S, p);
        }
    }

    return S;
}


Set *AppDataType::GetNewInternalSeeds(int checkpoint, int op)
{
    Image *LbMap = AppData->seedLbMap[op];
    Image *MkMap = AppData->seedMkMap[op];
    Set *S=NULL;
    int p,n;

    n = LbMap->ncols*LbMap->nrows;
    for (p=0; p<n; p++)
    {
        if (MkMap->val[p]>checkpoint)
        {
            if (LbMap->val[p]>0)
                InsertSet(&S, p);
        }
    }

    return S;
}


Set *AppDataType::GetNewExternalSeeds(int checkpoint, int op)
{
    Image *LbMap = AppData->seedLbMap[op];
    Image *MkMap = AppData->seedMkMap[op];
    Set *S=NULL;
    int p,n;

    n = LbMap->ncols*LbMap->nrows;
    for (p=0; p<n; p++)
    {
        if (MkMap->val[p]>checkpoint)
        {
            if (LbMap->val[p]==0)
                InsertSet(&S, p);
        }
    }

    return S;
}


Set *AppDataType::GetAllSeeds(int op)
{
    Image *MkMap = AppData->seedMkMap[op];
    Set *S=NULL;
    int p,n;

    n = MkMap->ncols*MkMap->nrows;
    for (p=0; p<n; p++)
    {
        if (MkMap->val[p]>0)
            InsertSet(&S, p);
    }

    return S;
}


int  AppDataType::GetLastInternalSeed(int op)
{
    Image *LbMap = AppData->seedLbMap[op];
    Image *MkMap = AppData->seedMkMap[op];
    int p,n,pmax=NIL,max=0;

    n = LbMap->ncols*LbMap->nrows;
    for (p=0; p<n; p++)
    {
        if (MkMap->val[p]>0 && LbMap->val[p]>0)
        {
            if (MkMap->val[p]>max)
            {
                pmax = p;
                max = MkMap->val[p];
            }
        }
    }
    return pmax;
}


int  AppDataType::GetFirstInternalSeed(int op)
{
    Image *LbMap = AppData->seedLbMap[op];
    Image *MkMap = AppData->seedMkMap[op];
    int p,n,pmin=NIL,min=INT_MAX;

    n = LbMap->ncols*LbMap->nrows;
    for (p=0; p<n; p++)
    {
        if (MkMap->val[p]>0 && LbMap->val[p]>0)
        {
            if (MkMap->val[p]<min)
            {
                pmin = p;
                min = MkMap->val[p];
            }
        }
    }
    return pmin;
}

void AppDataType::SetImageInfo(wxString filename, wxString dirname)
{
    this->filename = filename;
    this->dirname = dirname;
}


/** -------------------------------------------------------------------- **/

void app_draw_frames()
{
//    if (!AppData->IsLoaded()) return;
//
//    app_draw_frame(0);
//    app_draw_frame(1);
//    app_draw_frame(2);
//    app_draw_frame(3);
//
//    Views[0]->canvas->Refresh();
//    Views[1]->canvas->Refresh();
//    Views[2]->canvas->Refresh();
//    Views[3]->canvas->Refresh();

}


void app_draw_frame(int plane)
{
//    GraphDrawOptions opt;
//    SparseGraph *sg;
//    CImage *cimg, *caux, *zcimg;
//    Image  *img,*label,*nodeval;
//    Set    *S=NULL;
//    int   p,n,op,Imax;
//    int   sel_highlight, sel_marker, method;
//    float zoom;
//    bool  fill;
//
//    if (!AppData->IsLoaded()) return;
//    Window->GetMethod(&method);
//    Window->GetViewOptions(&sel_highlight, &sel_marker);
//    op = Window->GetOperationMode();
//    if (op<0) return;
//
//    if (AppData->type==TXT_GRAPH)
//    {
//        sg = (AppData->exGraph)->G;
//
//        if ( (sg->A)->n>5 || sg->Wmax>99 )
//            opt.edge_val_align = ALIGN_NONE;
//        else
//            opt.edge_val_align = ALIGN_TOPRIGHT;
//        opt.edge_color_from = 0x000000; //0x0000FF;
//        opt.edge_color_to = 0xFF0000; //0xFF0000;
//
//        opt.node_spacing = 49;
//        opt.node_scale = 0.22;
//        opt.seed_scale = 0.23;
//        opt.node_val_align = ALIGN_CENTER;
//        opt.node_val_font_size = 10.0;
//        opt.edge_val_font_size = 10.0;
//        opt.arrow_w_scale = 0.08;
//        opt.arrow_h_scale = 0.15;
//
//        opt.label2dottype[0].color = AppData->bkgColor;
//        opt.label2dottype[0].bkgcolor = -1;
//        opt.label2dottype[0].label_color = 0x000000;
//        opt.label2dottype[0].border_color = 0xffffff;
//        opt.label2dottype[0].angle = 0.0;
//        opt.label2dottype[0].n = 3;
//        opt.label2dottype[0].dot_type = DOT_TYPE_SIMPLE;
//
//        opt.label2dottype[1].color = AppData->objColor;
//        opt.label2dottype[1].bkgcolor = -1;
//        opt.label2dottype[1].label_color = 0x000000;
//        opt.label2dottype[1].border_color = 0xffffff;
//        opt.label2dottype[1].angle = PI/4.0;
//        opt.label2dottype[1].n = 3;
//        opt.label2dottype[1].dot_type = DOT_TYPE_SIMPLE;
//
//        label = CopyImage(AppData->GetImage("label"));
//        S = AppData->GetAllSeeds(op);
//
//        n = AppData->GetWidth()*AppData->GetHeight();
//        for (p=0; p<n; p++)
//        {
//            if (AppData->IsInternalSeed(p, op))
//                label->val[p] = 1;
//            else if (AppData->IsExternalSeed(p, op))
//                label->val[p] = 0;
//        }
//
//        switch (plane)
//        {
//        case 0:
//            nodeval = AppData->label;
//            Imax = MaximumNotInfinityValue(nodeval);
//            opt.graph_type = GRAPH_TYPE_ALL;
//            opt.node_val_align = ALIGN_NONE;
//            cimg = SparseGraph2CImage((AppData->exGraph)->G,
//                                      NULL, label,
//                                      NULL, S, &opt);
//            WriteCImage(cimg, "canvas1.ppm");
//            break;
//        case 1:
//            nodeval = (AppData->exGraph)->t_link_S;
//            Imax = MaximumNotInfinityValue(nodeval);
//            opt.graph_type = GRAPH_TYPE_ALL;
//            if (Imax<=99) opt.node_val_align = ALIGN_CENTER;
//            else         opt.node_val_align = ALIGN_NONE;
//
//            cimg = SparseGraph2CImage((AppData->exGraph)->G,
//                                      NULL, label,
//                                      nodeval, S, &opt);
//            break;
//        case 2:
//            nodeval = (AppData->exGraph)->t_link_T;
//            Imax = MaximumNotInfinityValue(nodeval);
//            opt.graph_type = GRAPH_TYPE_ALL;
//            if (Imax<=99) opt.node_val_align = ALIGN_CENTER;
//            else         opt.node_val_align = ALIGN_NONE;
//
//            cimg = SparseGraph2CImage((AppData->exGraph)->G,
//                                      NULL, label,
//                                      nodeval, S, &opt);
//            break;
//        case 3:
//            nodeval = AppData->cost;
//            Imax = MaximumNotInfinityValue(nodeval);
//            opt.graph_type = GRAPH_TYPE_FOREST;
//            if (Imax<=99) opt.node_val_align = ALIGN_CENTER;
//            else         opt.node_val_align = ALIGN_NONE;
//
//            cimg = SparseGraph2CImage((AppData->exGraph)->G,
//                                      AppData->pred, label,
//                                      nodeval, S, &opt);
//            WriteCImage(cimg, "canvas4.ppm");
//            break;
//        }
//
//        DestroyImage(&label);
//        DestroySet(&S);
//    }
//    else
//    {
//        switch (plane)
//        {
//        case 0:
//            if ( AppData->bpp>8 )
//            {
//                cimg = (CImage*)calloc(1,sizeof(CImage));
//                cimg->C[0] = ConvertToNbits((AppData->orig)->C[0], 8);
//                cimg->C[1] = ConvertToNbits((AppData->orig)->C[1], 8);
//                cimg->C[2] = ConvertToNbits((AppData->orig)->C[2], 8);
//            }
//            else
//                cimg = CopyCImage(AppData->orig);
//
//            if (op==1 && sel_highlight!=ID_Highlight_Off)
//            {
//                fill = (sel_highlight==ID_Highlight_Fill);
//
//                if (method ==ID_Method_OPF && AppData->regions != NULL)
//                {
//                    caux = APP_HighlightLabels(cimg, AppData->label, AppData->regions, 1.5,
//                                               AppData->objColor, AppData->bkgColor, fill);
//                    DestroyCImage(&cimg);
//                    cimg = caux;
//                }
//                else
//                {
//
//                    caux = CWideHighlight(cimg, AppData->label, 2.9,
//                                          AppData->objColor, fill);
//                    DestroyCImage(&cimg);
//                    cimg = caux;
//                }
//            }
//
//            if (sel_marker==ID_MarkerOnOff_On) AppData->HighlightMarkers(cimg, op);
//            break;
//        case 1:
//            img  = ConvertToNbits((AppData->exGraph)->t_link_S, 8);
//            cimg = Convert2CImage(img);
//            DestroyImage(&img);
//            break;
//        case 2:
//            img  = ConvertToNbits((AppData->exGraph)->t_link_T, 8);
//            cimg = Convert2CImage(img);
//            DestroyImage(&img);
//            break;
//        case 3:
//            img  = ConvertToNbits(AppData->grad, 8);
//            cimg = Convert2CImage(img);
//            DestroyImage(&img);
//            break;
//        }
//    }
//
//    zcimg = cimg;
//
//    Views[plane]->canvas->DrawCImage(cimg);
//
//    if (zcimg!=cimg)
//        DestroyCImage(&zcimg);
//    DestroyCImage(&cimg);
}


void app_reset_frame()
{
//    int op;
//
//    if (!AppData->IsLoaded()) return;
//
//    op = Window->GetOperationMode();
//    if (op==1)
//    {
//        //Execution
//        SetImage(AppData->label,        0);
//        SetImage(AppData->pred,         NIL);
//        SetImage(AppData->cost,         INT_MAX);
//        SetImage(AppData->seedLbMap[1], 0);
//        SetImage(AppData->seedMkMap[1], 0);
//        //SetImage(AppData->regions,      0);
//        AppData->markerID = MaximumValue(AppData->seedMkMap[0])+1;
//        AppData->checkpoint = 0;
//        Window->RefreshBorderMk();
//    }
//    else if (op==0
//            )  //Pre_proc
//    {
//
//        SetImage((AppData->exGraph)->t_link_S, 0);
//        SetImage((AppData->exGraph)->t_link_T, 0);
//        SetImage(AppData->grad,         0);
//        SetImage(AppData->seedLbMap[0], 0);
//        SetImage(AppData->seedMkMap[0], 0);
//        AppData->markerID = MaximumValue(AppData->seedMkMap[1])+1;
//
//        AppData->checkpoint = 0;
//    }
//    if (AppData->frontier!=NULL)
//        DestroySet(&AppData->frontier);
//
//    AppData->frontier = NULL;
//    AppData->closed = false;
}

