#include "lwirehandler.h"

extern "C"
{
	#include "code_c.h"
}
#include "appdata.h"


extern APPData* AppData;

LWireHandler::LWireHandler(bool isOri)
{
	this->boundary=NULL;
	this->isOri = isOri;
}

LWireHandler::~LWireHandler()
{
}

void LWireHandler::OnLeftClick(Pixel p)
{
//	if(!initLWire(false,p)) return;
//
//	if(AppData->frontier!=NULL) DestroySet(&AppData->frontier);
//
//	AppData->frontier = NULL;
//	Image* cost = AppData->GetImg("cost");
//	Image* label = AppData->GetImg("label");
//	Image* pred = AppData->GetImg("pred");
//	SetImage(cost, INT_MAX);
//	SetImage(label,      0);
//	SetImage(pred,     NIL);
//
//	if(boundary!=NULL)
//	{
//		int i;
//		int n = boundary[0];
//		for(i=1; i<=n; i++)
//		{
//			int index = boundary[i];
//
//			cost->val[index] = INT_MIN;
//			label->val[index] = 1;
//
//			if(i<n)
//				pred->val[index] = boundary[i+1];
//		}
//	}
//
//    Image* seedMkMap = AppData->GetImg("seedMkMapSEG");
//    Image* seedLbMap = AppData->GetImg("seedLbMapSEG");
//
//	if(seedMkMap->val[dst]==0)
//	{
//		AppData->markerID++;
//		seedMkMap->val[dst] = AppData->markerID;
//		seedLbMap->val[dst] = 1;
//	}
//
//	endLWire();
}

void LWireHandler::OnRightClick(Pixel p)
{
//    //Test closed boundary:
//
//	initLWire(true,p);
//
//    Image* pred = AppData->GetImg("pred");
//
//	if(pred->val[init]!=NIL)
//	{
//		AppData->closed = true;
//		Image* label = AppData->GetImg("label");
//		Image* flabel = CloseHoles(label);
//		int size = flabel->ncols*flabel->nrows;
//		memcpy(label->val,flabel->val, size*sizeof(int));
//		DestroyImage(&flabel);
//	}
//
//	endLWire();
}

void LWireHandler::OnMiddleClick(Pixel p)
{
//	int i;
//
//	if(!initLWire(false,p)) return;
//
//	if(AppData->frontier!=NULL) DestroySet(&AppData->frontier);
//
//	AppData->frontier = NULL;
//	AppData->closed = false;
//
//	Image* cost = AppData->GetImg("cost");
//	Image* label = AppData->GetImg("label");
//	Image* pred = AppData->GetImg("pred");
//    Image* seedMkMap = AppData->GetImg("seedMkMapSEG");
//    Image* seedLbMap = AppData->GetImg("seedLbMapSEG");
//
//	if(src!=NIL)
//	{
//		AppData->markerID--;
//		seedMkMap->val[src] = 0;
//		seedLbMap->val[src] = 0;
//	}
//	src = AppData->GetLastInternalSeed("SEG");
//
//	SetImage(cost, INT_MAX);
//	SetImage(label,      0);
//	SetImage(pred,     NIL);
//
//	if(boundary!=NULL)
//	{
//		int n = boundary[0];
//
//		for(i=1; i<=n; i++)
//			if(boundary[i]==src) break;
//
//		for(; i<=n; i++)
//		{
//
//			int index = boundary[i];
//
//			cost->val[index] = INT_MIN;
//			label->val[index] = 1;
//		if(i<n)
//			pred->val[index] = boundary[i+1];
//
//		}
//	}
//	endLWire();

}

void LWireHandler::OnMouseMotion(Pixel p)
{
	if(AppData->closed) return;
	if(!initLWire(false,p)) return;
	endLWire();
}

bool LWireHandler::initLWire(bool right_click, Pixel px)
{
//	init = AppData->GetFirstInternalSeed("SEG");
//
//	Image* cost = AppData->GetImg("cost");
//	Image* label = AppData->GetImg("label");
//	Image* pred = AppData->GetImg("pred");
//
//	if(right_click==true)
//		dst = init;
//	else
//		dst = px.x + px.y*AppData->GetWidth();
//
//	if(dst==NIL) return false;
//
//	src = AppData->GetLastInternalSeed("SEG");
//	if(src!=NIL)
//	{
//		ChangeSparseGraphType((AppData->exGraph)->G,
//		CAPACITY);
//
//		if(!isOri)
//		{
//			boundary = iftLiveWire(cost, pred,
//						(AppData->exGraph)->G, &AppData->frontier,
//						init, src, dst);
//		}else{
//			boundary = iftOLiveWire(cost, pred,
//						(AppData->exGraph)->G, &AppData->frontier,
//						(AppData->exGraph)->t_link_S, 1,
//						init, src, dst);
//		}
//
//		SetImage(label, 0);
//
//		if(boundary!=NULL)
//		{
//			int i;
//			int n = boundary[0];
//			for(i=1; i<=n; i++)
//			{
//				int index = boundary[i];
//				label->val[index] = 1;
//			}
//		}
//	}
//
//	return true;

}

void LWireHandler::endLWire()
{
	//wxMutexLocker lock(mutex);

	if(boundary!=NULL)
	{
		free(boundary);
		boundary = NULL;
	}
	AppData->checkpoint = 0;

	app_draw_frame(0);
}


