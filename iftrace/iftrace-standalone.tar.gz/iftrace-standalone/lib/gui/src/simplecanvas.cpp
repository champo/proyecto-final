
#include "simplecanvas.h"


BEGIN_EVENT_TABLE(SimpleCanvas, wxPanel)
  EVT_PAINT(SimpleCanvas::OnPaint)
END_EVENT_TABLE()


SimpleCanvas :: SimpleCanvas(wxWindow *parent) 
    : wxPanel(parent, wxID_ANY, wxDefaultPosition, wxDefaultSize, wxSIMPLE_BORDER, _T("scanvas"))
{
  owner = parent;
  ibuf = new wxMemoryDC;  
  SetBackgroundColour(*wxWHITE);
  imageWidth = imageHeight = -1;
  loaded = false;
}

void SimpleCanvas :: DrawFigure(wxBitmap bitmap) {
  ibuf->SelectObject(bitmap);
  loaded = true;
}

void SimpleCanvas :: ClearFigure() {
  ibuf->SelectObject(wxNullBitmap);
  loaded = true;
}

void SimpleCanvas :: Refresh(){
  wxPanel::Refresh(true, NULL);
  Update();
}
  
void SimpleCanvas :: OnPaint(wxPaintEvent& event) {
  if(!loaded) return;

  wxSize size = ibuf->GetSize();
  imageWidth = size.GetWidth();
  imageHeight = size.GetHeight();

  wxPaintDC paintDC(this);
  //DoPrepareDC(paintDC);
  paintDC.Blit(0, 0, size.GetWidth(), size.GetHeight(), ibuf, 0, 0);
}


