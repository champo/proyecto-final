
#include "interactionhandler.h"


InteractionHandler :: InteractionHandler()
{
	drag_p = (Pixel){-1,-1};
}


InteractionHandler :: ~InteractionHandler()
{
}


void InteractionHandler :: OnLeftClick(Pixel p){
}

void InteractionHandler :: OnRightClick(Pixel p){
}

void InteractionHandler :: OnMiddleClick(Pixel p){
}

void InteractionHandler :: OnLeftDrag(Pixel p, Pixel q){
}

void InteractionHandler :: OnRightDrag(Pixel p, Pixel q){
}

void InteractionHandler :: OnLeftRelease(Pixel p){
}

void InteractionHandler :: OnRightRelease(Pixel p){
}

void InteractionHandler :: OnMiddleRelease(Pixel p){
}


void InteractionHandler :: OnMouseMotion(Pixel p){
}

void InteractionHandler :: OnMouseWheel(Pixel p,
					int rotation,
					int delta){
}

//This function is for experts only.
void InteractionHandler :: OnMouseEvent(wxMouseEvent& event,
		Pixel p)
{
	if(p.x < 0  || p.y < 0) return;

	switch (event.GetButton())
	{
		case wxMOUSE_BTN_LEFT :
			if(event.GetEventType() == wxEVT_LEFT_DOWN)
			{
				drag_p = p;
				OnLeftClick(p);
			}
			else if (event.GetEventType() == wxEVT_LEFT_UP){}

			break;
		case wxMOUSE_BTN_MIDDLE :
			if (event.GetEventType() == wxEVT_MIDDLE_DOWN)
			{
				OnMiddleClick(p);
			}
			else if (event.GetEventType() == wxEVT_MIDDLE_UP){}

			break;
		case wxMOUSE_BTN_RIGHT :
			if (event.GetEventType() == wxEVT_RIGHT_DOWN)
			{
				drag_p = p;
				OnRightClick(p);
			}
			else if (event.GetEventType() == wxEVT_RIGHT_UP){}

			break;
		case wxMOUSE_BTN_NONE :
			if (event.GetEventType() == wxEVT_ENTER_WINDOW) {}
			else if (event.GetEventType() == wxEVT_LEAVE_WINDOW){}
			else if (event.GetEventType() == wxEVT_MOTION)
			{
				if (event.Dragging())
				{
					if(event.LeftIsDown())
					{
						OnLeftDrag(drag_p, p);
						drag_p = p;
					}
					else if(event.RightIsDown())
					{
						OnRightDrag(drag_p, p);
						drag_p = p;
					}
					else if(event.MiddleIsDown()) {}
				}
				OnMouseMotion(p);
			}
			else if (event.GetEventType() == wxEVT_MOUSEWHEEL) {}

			break;
	}
}


