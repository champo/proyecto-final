#include "kccextraparameters.h"

#ifndef _VIDEO_XPM_
#define _VIDEO_XPM_
#include "video.xpm"
#endif

KCCExtraParameters :: KCCExtraParameters(wxWindow *parent,
					 wxSizer  *sizer)
  : ExtraParameters(parent, sizer){
  this->type = KCC;
  wxStaticText *tSizeTh = new wxStaticText(parent, -1, _T("Size Th"), wxDefaultPosition, wxDefaultSize, wxALIGN_LEFT, _T("staticText1"));
  spSizeTh = new wxSpinCtrl(parent, ID_SizeTh, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxSP_ARROW_KEYS, 1, 100, 10, _T("wxSpinCtrl1"));

  wxStaticText *tAreaClose = new wxStaticText(parent, -1, _T("Area Close"), wxDefaultPosition, wxDefaultSize, wxALIGN_LEFT, _T("staticText2"));
  spAreaClose = new wxSpinCtrl(parent, ID_AreaClose, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxSP_ARROW_KEYS, 1, 500, 10, _T("wxSpinCtrl2"));

  hbsSizeTh = new wxBoxSizer(wxHORIZONTAL);
  hbsSizeTh->Add(tSizeTh,  1, wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL);
  hbsSizeTh->Add(spSizeTh, 0, wxALIGN_RIGHT);
  sizer->Add(hbsSizeTh,    0, wxEXPAND);

  hbsAreaClose = new wxBoxSizer(wxHORIZONTAL);
  hbsAreaClose->Add(tAreaClose, 1, wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL);
  hbsAreaClose->Add(spAreaClose, 0, wxALIGN_RIGHT);
  sizer->Add(hbsAreaClose, 0, wxEXPAND);

  wxStaticText *tVideo = new wxStaticText(parent, -1, _T("WaveCost Burst"), wxDefaultPosition, wxDefaultSize, wxALIGN_LEFT, _T("staticText3"));

  wxBitmap *bmVideo = new wxBitmap(video_xpm);
  buVideo = new wxBitmapButton(parent, ID_VideoKCC, *bmVideo, wxDefaultPosition, wxDefaultSize, wxBU_AUTODRAW, wxDefaultValidator, _T("b_video"));

  hbsVideo = new wxBoxSizer(wxHORIZONTAL);
  hbsVideo->Add(tVideo,  0, wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL);
  hbsVideo->Add(buVideo, 0, wxALIGN_LEFT);
  sizer->Add(hbsVideo, 0, wxEXPAND);
}

void KCCExtraParameters::GetParameters(int *thres, int *area){
  *thres = spSizeTh->GetValue();
  *area  = spAreaClose->GetValue();
}

void KCCExtraParameters :: RefreshParametersLayout(){}
