#include "wxcimage.h"

wxImage* ConvertToWXImage(CImage* cimg)
{
	if(cimg == NULL || cimg->C == NULL) return NULL;

	wxImage*  img = new wxImage(cimg->C[0]->ncols, cimg->C[0]->nrows, false);

  	int p = 0;

	for(int j=0; j< img->GetHeight(); j++)
	{
		for(int i = 0; i < img->GetWidth(); i++)
		{
			unsigned char red = cimg->C[0]->val[p];
			unsigned char green = cimg->C[1]->val[p];
			unsigned char blue = cimg->C[2]->val[p];
			img->SetRGB(i,j,red,green,blue);
			p++;
		}
	}

  	return img;
}

CImage* ConvertToCImage(wxImage& img)
{
	if(!img.Ok()) return NULL;

	CImage* cimg = CreateCImage(img.GetWidth(), img.GetHeight());

  	int p = 0;

	for(int j=0; j< img.GetHeight(); j++)
	{
		for(int i = 0; i < img.GetWidth(); i++)
		{
			cimg->C[0]->val[p] = img.GetRed(i,j);
			cimg->C[1]->val[p] = img.GetGreen(i,j);
			cimg->C[2]->val[p] = img.GetBlue(i,j);
			p++;
		}
	}

   	return cimg;

}
