#include "mfextraparameters.h"

MFExtraParameters :: MFExtraParameters(wxWindow *parent,
				       wxSizer  *sizer)
  : ExtraParameters(parent, sizer){
  this->type = MF;
  wxStaticText *tLambda   = new wxStaticText(parent, -1, _T("Lambda"), wxDefaultPosition, wxDefaultSize, wxALIGN_LEFT, _T("staticText1"));
  spLambda = new wxSpinCtrl(parent, ID_Lambda, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxSP_ARROW_KEYS, 0, 500, 40, _T("wxSpinCtrl1"));

  hbsLambda = new wxBoxSizer(wxHORIZONTAL);
  hbsLambda->Add(tLambda,  1, wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL);
  hbsLambda->Add(spLambda, 0, wxALIGN_RIGHT);
  sizer->Add(hbsLambda,     0, wxEXPAND);
}

void MFExtraParameters::GetParameters(int *lambda){
  *lambda = spLambda->GetValue();
}

void MFExtraParameters :: RefreshParametersLayout(){}
