#include "mycanvas.h"

#include "myframe.h"
#include "sliceview.h"

#include "extraparameters.h"
#include "appdata.h"

BEGIN_EVENT_TABLE(MyCanvas, wxScrolledWindow)
	EVT_PAINT(MyCanvas::OnPaint)
	EVT_MOUSE_EVENTS(MyCanvas::OnMouseEvent)
END_EVENT_TABLE()

MyCanvas :: MyCanvas(wxWindow *parent) : Canvas(parent)
{
}

MyCanvas :: ~MyCanvas()
{
}

