#include "basepanel.h"


BasePanel :: BasePanel(wxWindow* parent)
        : wxPanel(parent, wxID_ANY, wxDefaultPosition, wxDefaultSize, wxNO_BORDER, _T("basepanel"))  //wxSIMPLE_BORDER
{
    this->parent = parent;
    is_initialized = true;
    sizer = new wxBoxSizer(wxVERTICAL);
    this->SetSizer(sizer, true);
    sizer->SetSizeHints(this);
    sizer->Layout();
}

BasePanel :: BasePanel() : wxPanel()
{
    is_initialized = false;
}

BasePanel :: ~BasePanel()
{
    sizer->Clear(true);
}

void BasePanel :: InitializeBase(wxWindow* parent, int style)
{
    Create(parent, wxID_ANY, wxDefaultPosition, wxDefaultSize, style, _("basepanel"));

    sizer = new wxBoxSizer(wxVERTICAL);
    this->SetSizer(sizer, true);
    sizer->SetSizeHints(this);
    sizer->Layout();

    is_initialized = true;
}


void BasePanel :: InitPanel(wxWindow* parent)
{
    InitializeBase(parent);
}
