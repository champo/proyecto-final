#include "canvas.h"
#include "sliceview.h"
#include "appdata.h"

BEGIN_EVENT_TABLE(Canvas, wxScrolledWindow)
    EVT_PAINT(Canvas::OnPaint)
    EVT_MOUSE_EVENTS(Canvas::OnMouseEvent)
END_EVENT_TABLE()


Canvas :: Canvas(wxWindow *parent)
        : wxScrolledWindow(parent, wxID_ANY,
                           wxDefaultPosition, wxDefaultSize,
                           wxSIMPLE_BORDER|wxVSCROLL|wxHSCROLL)
{
    owner = parent;
    ibuf = new wxMemoryDC();
    wximg = NULL;

    imageWidth = imageHeight = -1;
    displayWidth = displayHeight = -1;
    zoom = 1.0;
    handler = NULL;

    SetBackgroundColour(*wxBLACK);
}

Canvas :: ~Canvas()
{
    if (ibuf != NULL && ibuf->Ok()) delete ibuf;
    if (wximg != NULL) delete wximg;
}

void Canvas :: DrawCImage(CImage *cimg)
{
    int ncols,nrows;

    ncols = cimg->C[0]->ncols;
    nrows = cimg->C[0]->nrows;

    imageWidth = ncols;
    imageHeight = nrows;

    if (wximg!=NULL) delete wximg;

    wximg = ConvertToWXImage(cimg);

    wxImage tmp(*wximg);
    if (zoom!=1.0)
    {
#if wxMINOR_VERSION>=8
        tmp.Rescale(ROUND(ncols*zoom), ROUND(nrows*zoom),
                    wxIMAGE_QUALITY_NORMAL);
#else
        tmp.Rescale(ROUND(ncols*zoom), ROUND(nrows*zoom));
#endif
    }

    wxBitmap wxbit(tmp, -1);
    ibuf->SelectObject(wxbit);
}

void Canvas :: ClearFigure()
{
    if(wximg != NULL)
    {
        delete wximg;
        wximg = NULL;
    }
    ibuf->SelectObject(wxNullBitmap);
}

void Canvas :: Draw()
{

}

//Returns the pixel address.
int Canvas :: Canvas2Image(int x, int y, Pixel* p)
{
    int w,h;
    float fx,fy;

    CalcUnscrolledPosition(x,y,&x,&y);

    fx = (float)x / this->zoom;
    fy = (float)y / this->zoom;
    x = ROUND(fx);
    y = ROUND(fy);

    w = this->imageWidth;
    h = this->imageHeight;
    /// Só processa o evento caso o mouse esteja
    ///dentro da imagem.
    if (x<0 || y<0 || x>=w || y>=h) return -1;

    p->x = x;
    p->y = y;

    return 1;
}


void Canvas :: Refresh()
{
    wxScrolledWindow::Refresh(true, NULL);
    Update();
}

void Canvas :: OnPaint(wxPaintEvent& event)
{

    wxSize size = ibuf->GetSize();

    if (displayWidth!=size.GetWidth() || displayHeight!=size.GetHeight())
    {
        displayWidth = size.GetWidth();
        displayHeight = size.GetHeight();
        SetScrollRate(5, 5);
        Scroll(0, 0);
        SetVirtualSize(displayWidth,displayHeight);
    }

    wxPaintDC paintDC(this);
    DoPrepareDC(paintDC);
    paintDC.Blit(0, 0, size.GetWidth(), size.GetHeight(), ibuf, 0, 0);
}


void Canvas :: OnMouseEvent(wxMouseEvent& event)
{
    int j, x,y;
    Pixel p;

    if (wximg == NULL) return;

    event.GetPosition(&x, &y);
    j = Canvas2Image(x, y, &p);

    if (handler!=NULL && j>=0)
        handler->OnMouseEvent(event, p);
    if (j >= 0)
        ((SliceView*)owner)->ShowCoordinate(&p);
    Refresh();
}


void Canvas :: ZoomIn()
{
    if (zoom>=4.0) return;
    zoom *= 2.0;

    if(wximg == NULL) return;

    wxImage tmp(*wximg);
    if (zoom!=1.0)
    {
#if wxMINOR_VERSION>=8
        tmp.Rescale(ROUND(imageWidth*zoom),
                    ROUND(imageHeight*zoom),
                    wxIMAGE_QUALITY_NORMAL);
#else
        tmp.Rescale(ROUND(imageWidth*zoom),
                    ROUND(imageHeight*zoom));
#endif
    }

    wxBitmap wxbit(tmp, -1);
    ibuf->SelectObject(wxbit);

    this->Refresh();
}

void Canvas :: ZoomOut()
{
    if (zoom<=0.5) return;
    zoom *= 0.5;

    if(wximg == NULL) return;

    wxImage tmp(*wximg);
    if (zoom!=1.0)
    {
#if wxMINOR_VERSION>=8
        tmp.Rescale(ROUND(imageWidth*zoom),
                    ROUND(imageHeight*zoom),
                    wxIMAGE_QUALITY_NORMAL);
#else
        tmp.Rescale(ROUND(imageWidth*zoom),
                    ROUND(imageHeight*zoom));
#endif
    }

    wxBitmap wxbit(tmp, -1);
    ibuf->SelectObject(wxbit);

    this->Refresh();
}


void Canvas :: SetZoomLevel(float zoom)
{
    if (zoom<0.5 || zoom>4.0) return;

    if(fabsf(zoom - this->zoom) < 0.00001) return;

    this->zoom = zoom;

    if(wximg == NULL) return;

    wxImage tmp(*wximg);
    if (zoom!=1.0)
    {
#if wxMINOR_VERSION>=8
        tmp.Rescale(ROUND(imageWidth*zoom),
                    ROUND(imageHeight*zoom),
                    wxIMAGE_QUALITY_NORMAL);
#else
        tmp.Rescale(ROUND(imageWidth*zoom),
                    ROUND(imageHeight*zoom));
#endif
    }

    wxBitmap wxbit(tmp, -1);
    ibuf->SelectObject(wxbit);

    this->Refresh();
}


void Canvas :: SetInteractionHandler(InteractionHandler *handler)
{
    this->handler = handler;
}

void Canvas :: GetImageSize(int* width, int* height)
{
    *width = imageWidth;
    *height = imageHeight;
}


void Canvas :: GetDisplaySize(int* width, int* height)
{
    *width = displayWidth;
    *height = displayHeight;
}


CImage * Canvas :: CopyAsCImage()
{

    if (imageWidth == -1 || imageHeight == -1 || wximg == NULL)
        return NULL;

    return ConvertToCImage(*wximg);
}


