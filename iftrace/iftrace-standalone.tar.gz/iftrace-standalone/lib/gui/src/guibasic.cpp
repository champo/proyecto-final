
#include "guibasic.h"
#include "gui.h"

void SetColor(wxColour *wxcolor, int color){
#if wxMINOR_VERSION>=8
  wxcolor->Set(t0(color),
	       t1(color),
	       t2(color),
	       wxALPHA_OPAQUE);
#else
  wxcolor->Set(t0(color),
	       t1(color),
	       t2(color));
#endif
}


/* Prints "label" at point (x,y), using the current label font size.
   The parameter "xalign" (resp. "yalign)" specifies which point of the string's
   bounding box will end up at (x,y): 0.0 means the left (resp. bottom) side,
   1.0 means the right (resp. top) side.  Default is (0.5, 0.5), meaning
   the box will be centered at (x,y). */
void DrawAsciiString(wxMemoryDC *ibuf,
		     char *str,
		     int x, int y,
		     int color, int border_color,
		     double xalign, double yalign,
		     double angle){
  wxString wxstr(str, wxConvUTF8);
  DrawWxString(ibuf, &wxstr, x, y, color, border_color,
	       xalign, yalign, angle);
}


void DrawWxString(wxMemoryDC *ibuf,
		  wxString *wxstr,
		  int x, int y,
		  int color, int border_color,
		  double xalign, double yalign,
		  double angle){
  int dhx,dhy;
  wxColour wxcolor;
  wxSize size;
  int w,h,dw,dh;
  double rad = angle*PI/180.0;

  yalign = 1.0 - yalign;
  ibuf->SetTextBackground(*wxWHITE);
#if wxMINOR_VERSION>=8
  size = ibuf->GetTextExtent(*wxstr);
#else
  wxCoord wc,hc;
  ibuf->GetTextExtent(*wxstr, &wc, &hc,
		      NULL, NULL, NULL);
  size.Set(wc, hc);
#endif

  w = size.GetWidth();
  h = size.GetHeight();
  if(angle != 0.0){
    dw =  ROUND(-sin(rad)*h*yalign - cos(rad)*w*xalign );
    dh = -ROUND( cos(rad)*h*yalign - sin(rad)*w*xalign );
  }
  else{
    dw = -w*xalign;
    dh = -h*yalign;
  }

  if(border_color>=0){
    SetColor(&wxcolor, border_color);
    ibuf->SetTextForeground(wxcolor);
    for(dhy = -1; dhy <= 1; dhy++)
      for(dhx = -1; dhx <= 1; dhx++)
	if(dhx!=0 || dhy!=0)
	  ibuf->DrawRotatedText(*wxstr,
				ROUND(x + dw + dhx),
				ROUND(y + dh + dhy),
				angle);
  }

  if(color>=0){
    SetColor(&wxcolor, color);
    ibuf->SetTextForeground(wxcolor);
  }
  ibuf->DrawRotatedText(*wxstr,
			ROUND(x + dw),
			ROUND(y + dh),
			angle);
}

void FastWritePlotVideoFrames(Curve *C,
                             char *title,
                             char *xlabel,
                             char *ylabel,
                             int objColor, int plotColor,
                             int w, int h, FileList *L)
{
   double x_min,x_max;
   double y_min,y_max;
   CImage *cimg,*cdraw,*frame;
   Image *alpha;
   int margin_left,margin_right;
   int margin_top,margin_bottom;
   int dx,dy,i,j,p,q,k,t,n,sizex,sizey,dr,r;
   unsigned char *data;
   char str[100];
   wxColour wxcolor;
   wxMemoryDC ibuf;

   margin_left   = ROUND(0.19*320+20); //w);
   margin_right  = ROUND(0.05*320+20); //w);
   margin_top    = ROUND(0.15*h);
   margin_bottom = ROUND(0.20*h);

   InvertXY(C);
   SortCurve(C, 0, C->n-1, INCREASING);
   InvertXY(C);

   x_min = y_min = DBL_MAX;
   x_max = y_max = DBL_MIN;
   for (k=0; k<C->n; k++)
   {
       if (C->X[k]>x_max && C->X[k]!=DBL_MAX)
           x_max = C->X[k];
       if (C->X[k]<x_min && C->X[k]!=DBL_MIN)
           x_min = C->X[k];

       if (C->Y[k]>y_max && C->Y[k]!=DBL_MAX)
           y_max = C->Y[k];
       if (C->Y[k]<y_min && C->Y[k]!=DBL_MIN)
           y_min = C->Y[k];
   }

   if (x_min==DBL_MAX || y_min==DBL_MAX ||
           x_max==DBL_MIN || y_max==DBL_MIN)
       Error((char*)"Bad or corrupted curve",
             (char*)"FastWritePlotVideoFrames");

   cimg  = CreateCImage(w, h);
   cdraw = CreateCImage(w, h);
   alpha = CreateImage(w, h);
   //-----------------------------------
   wxImage wximg(w, h, false);
   data = wximg.GetData();

   n = w*h;
   for (p=0,q=0;p<n;p++,q+=3)
   {
       data[q]   = cimg->C[0]->val[p];
       data[q+1] = cimg->C[1]->val[p];
       data[q+2] = cimg->C[2]->val[p];
   }
   wxBitmap wxbit(wximg, -1);
   ibuf.SelectObject(wxbit);

   wxFont font(10, wxFONTFAMILY_SWISS, wxFONTSTYLE_NORMAL,
               wxFONTWEIGHT_NORMAL, false, _T(""),
               wxFONTENCODING_DEFAULT);
   wxFont font2(15, wxFONTFAMILY_SWISS, wxFONTSTYLE_NORMAL,
                wxFONTWEIGHT_NORMAL, false, _T(""),
                wxFONTENCODING_DEFAULT);
   wxFont font3(20, wxFONTFAMILY_SWISS, wxFONTSTYLE_NORMAL,
                wxFONTWEIGHT_NORMAL, false, _T(""),
                wxFONTENCODING_DEFAULT);

   SetColor(&wxcolor, 0xFFFFFF);
   ibuf.SetTextBackground(*wxBLACK);
   ibuf.SetTextForeground(wxcolor);
   ibuf.SetFont(font);

   sprintf(str,"%.1f",x_min);
   DrawAsciiString(&ibuf, str,
                   margin_left,
                   h-margin_bottom+10,
                   -1, -1, 0.5, 0.5, 0.0);
   sprintf(str,"%.1f",x_max);
   DrawAsciiString(&ibuf, str,
                   w-margin_right,
                   h-margin_bottom+10,
                   -1, -1, 0.5, 0.5, 0.0);
   sprintf(str,"%.1f",(x_min+x_max)/2.0);
   DrawAsciiString(&ibuf, str,
                   (margin_left+w-margin_right)/2,
                   h-margin_bottom+10,
                   -1, -1, 0.5, 0.5, 0.0);

   sprintf(str,"%.1g",y_min);
   DrawAsciiString(&ibuf, str,
                   margin_left-2,
                   h-margin_bottom,
                   -1, -1, 1.0, 0.5, 0.0);
   sprintf(str,"%.1g",y_max);
   DrawAsciiString(&ibuf, str,
                   margin_left-2,
                   margin_top,
                   -1, -1, 1.0, 0.5, 0.0);
   sprintf(str,"%.1g",(y_min+y_max)/2.0);
   DrawAsciiString(&ibuf, str,
                   margin_left-2,
                   (margin_top+h-margin_bottom)/2,
                   -1, -1, 1.0, 0.5, 0.0);

   ibuf.SetFont(font2);
   DrawAsciiString(&ibuf, xlabel,
                   w/2,
                   h-margin_bottom/2,
                   -1, -1, 0.5, 0.5, 0.0);
   DrawAsciiString(&ibuf, ylabel,
                   3, (h-margin_bottom)/2,
                   -1, -1, 0.5, 1.0, 90.0);

   SetColor(&wxcolor, plotColor);
   ibuf.SetTextBackground(*wxBLACK);
   ibuf.SetTextForeground(wxcolor);
   ibuf.SetFont(font3);
   DrawAsciiString(&ibuf, title,
                   w/2,
                   margin_top/2,
                   -1, -1, 0.5, 0.5, 0.0);

   wxImage wximg2 = wxbit.ConvertToImage();
   data = wximg2.GetData();

   for (p=0,q=0;p<n;p++,q+=3)
   {
       cimg->C[0]->val[p] = data[q];
       cimg->C[1]->val[p] = data[q+1];
       cimg->C[2]->val[p] = data[q+2];
   }
   //-----------------------------------
   p = margin_left + margin_top*w;
   q = margin_left + (h-margin_bottom)*w;
   DrawCImageLine(cdraw, alpha, p, q,
                  0.0, 0xffffff, 255, false);
   p = margin_left + (h-margin_bottom)*w;
   q = (w-margin_right) + (h-margin_bottom)*w;
   DrawCImageLine(cdraw, alpha, p, q,
                  0.0, 0xffffff, 255, false);

   q = NIL;
   t = r = 0;
   dr = ROUND((float)C->n/(L->n-1));
   for (k=0; t<L->n; k++)
   {
       if (k<C->n)
       {
           if (C->X[k]>DBL_MIN && C->X[k]<DBL_MAX &&
                   C->Y[k]>DBL_MIN && C->Y[k]<DBL_MAX)
           {

               sizex = w-(margin_left+margin_right);
               sizey = h-(margin_top+margin_bottom);
               dx = ROUND(sizex*(C->X[k]-x_min)/(x_max-x_min));
               dy = ROUND(sizey*(C->Y[k]-y_min)/(y_max-y_min));
               j = margin_left + dx;
               i = margin_top + (sizey-dy);
               p = j + i*w;

               if (q!=NIL)
                   DrawCImageLine(cdraw, alpha, p, q,
                                  1.0, plotColor, 255, true);
               q = p;
           }
       }

       if (k>=r && t<L->n)
       {
           frame = CopyCImage(cimg);
           BlendDrawCImage(frame, cdraw, alpha);
           WriteCImage(frame, GetFile(L, t));
           DestroyCImage(&frame);
           t++;
           r += dr;
           if (r>=C->n) r=C->n-1;
       }
   }
   BlendDrawCImage(cimg, cdraw, alpha);
   DestroyCImage(&cdraw);
   DestroyImage(&alpha);
}

void WxDisplayImage(wxImage& img, wxString filename)
{
    if (!img.Ok()) return;

    wxBitmap bmp(img);

    int width = bmp.GetWidth();
    int height = bmp.GetHeight();

    wxFrame* frame = new wxFrame(NULL, wxID_ANY, filename, wxDefaultPosition, wxSize(width,height));

    wxScrolledWindow* sw = new wxScrolledWindow(frame);

    wxStaticBitmap* sb = new wxStaticBitmap(sw, -1, bmp);

    sw->SetScrollbars(10, 10, width/10, height/10);
    sw->Scroll(10,10);

    frame->Show();

}

void  WxDisplayCImage(CImage* cimg, wxString filename)
{
    wxImage* img = ConvertToWXImage(cimg);

    WxDisplayImage(*img, filename);

    delete img;
}

void WxDisplayImageFile(wxString filename)
{
    wxImage img(filename,wxBITMAP_TYPE_ANY);

    WxDisplayImage(img, filename);
}


