#include "lwireextraparameters.h"

LWIREExtraParameters :: LWIREExtraParameters(wxWindow *parent,
					     wxSizer  *sizer)
  : ExtraParameters(parent, sizer){
  this->type = LWIRE;

  cbOri = new wxCheckBox(parent, ID_Ori, _T("Oriented"), wxDefaultPosition, wxDefaultSize, wxCHK_2STATE, wxDefaultValidator, _T("checkBox3"));
  hbsOri = new wxBoxSizer(wxHORIZONTAL);
  hbsOri->Add(cbOri, 1, wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL);
  sizer->Add(hbsOri, 0, wxEXPAND);
}

void LWIREExtraParameters::GetParameters(bool *isOri){
  *isOri = cbOri->GetValue();
}

void LWIREExtraParameters::RefreshParametersLayout(){}

