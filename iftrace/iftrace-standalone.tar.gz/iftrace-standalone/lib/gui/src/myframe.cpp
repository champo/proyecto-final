#include <wx/progdlg.h>

#include "myframe.h"
#include "code_cpp.h"
#include "mycanvas.h"
#include "sliceview.h"

#include "videoopt.h"

#include "filter.xpm"
#include "run.xpm"
#include "zoomin.xpm"
#include "zoomout.xpm"
#include "gear.xpm"
#include "eraser.xpm"
#include "navigator.xpm"

BEGIN_EVENT_TABLE(MyFrame, wxFrame)
    EVT_MENU(ID_Quit, MyFrame::OnQuit)
    EVT_MENU(ID_About, MyFrame::OnAbout)
    EVT_SIZE(           MyFrame::OnSize)
    EVT_TOOL(ID_Run, MyFrame::OnRun)
    EVT_TOOL(ID_Clean_Markers, MyFrame::OnCleanMarkers)
    EVT_MENU(ID_LoadGraph, MyFrame::OnLoadGraph)
    EVT_MENU(ID_SaveLabel, MyFrame::OnSaveLabel)
    EVT_MENU(ID_SaveObject, MyFrame::OnSaveObject)
    EVT_MENU(ID_LoadMark, MyFrame::OnLoadMarkers)
    EVT_MENU(ID_SaveMark, MyFrame::OnSaveMarkers)
    EVT_MENU(ID_SaveObjMap, MyFrame::OnSaveObjMap)
    EVT_MENU(ID_SaveBkgMap, MyFrame::OnSaveBkgMap)
    EVT_MENU(ID_SaveFeats, MyFrame::OnSaveFeats)
    EVT_MENU(ID_ExportGraph, MyFrame::OnExportGraph)
    EVT_CHOICE(ID_Method, MyFrame::OnChangeMethod)
    EVT_CHOICE(ID_Highlight, MyFrame::OnChangeHighlight)
    EVT_CHOICE(ID_GradType, MyFrame::OnChangeGradOpt)
    EVT_CHOICE(ID_GradInput, MyFrame::OnChangeGradOpt)
    EVT_CHOICE(ID_MarkerOnOff, MyFrame::OnChangeMarkerOnOff)
    EVT_CHOICE(ID_ChooseClassif, MyFrame::OnChooseClassif)
    //    EVT_TOOL_RANGE(ID_Awe, ID_Segmentation, MyFrame::OnChangeMode)
    EVT_CHECKBOX(ID_BorderMk, MyFrame::OnChangeBorderMk)
    EVT_CHECKBOX(ID_Ori, MyFrame::OnChangeOri)
    EVT_BUTTON(ID_VideoDIFT,  MyFrame::OnCreateVideo)
    EVT_BUTTON(ID_VideoTP,    MyFrame::OnCreateVideo)
    EVT_BUTTON(ID_VideoIFTGC, MyFrame::OnCreateVideo)
    EVT_BUTTON(ID_VideoKCC,   MyFrame::OnCreateVideo)
    EVT_BUTTON(ID_ButTieZones, MyFrame::OnShowTieZones)
    EVT_BUTTON(ID_ButRepeat,   MyFrame::OnRepeatTrainingSeeds)
    EVT_BUTTON(ID_ButTopology, MyFrame::OnShowTopology)
    EVT_BUTTON(ID_ButGPTree, MyFrame::OnShowGPTree)
    EVT_BUTTON(ID_ButPlot, MyFrame::OnShowPlot)
    EVT_BUTTON(ID_ButFilterPDF,  MyFrame::OnFilterPDF)
    EVT_SPINCTRL(ID_MaxOrd, MyFrame::OnChangeMaxOrd)
    EVT_MENU(ID_View0, MyFrame::OnSelectView)
    EVT_MENU(ID_View1, MyFrame::OnSelectView)
    EVT_MENU(ID_View2, MyFrame::OnSelectView)
    EVT_MENU(ID_View3, MyFrame::OnSelectView)
    EVT_MENU(ID_View4, MyFrame::OnSelectView)
END_EVENT_TABLE()


MyFrame::MyFrame(const wxString& title, const wxPoint& pos, const wxSize& size)
        : wxFrame((wxFrame*) NULL, -1, title, pos, size)
{
    ///Menubar
    wxMenu *menuFile = new wxMenu;
    menuFile->Append(ID_LoadImg,   _T("&Load Image...\tCTRL+O"));
    menuFile->Append(ID_LoadMark,  _T("Load Mar&kers...\tCTRL+M"));
    menuFile->Append(ID_LoadLabel,  _T("Lo&ad Label...\tCTRL+L"));
    menuFile->Append(ID_LoadGT,  _T("Load Ground&truth...\tCTRL+G"));
    menuFile->AppendSeparator();
    menuFile->Append(ID_LoadVideo, _T("Load &Video...\tCTRL+N"));
    menuFile->AppendSeparator();
    menuFile->Append(ID_SaveMark,  _T("Save &Markers..."));

    menuFile->AppendSeparator();
    menuFile->Append(ID_ExportImages, _T("&Export Images..."));
    menuFile->AppendSeparator();
    menuFile->Append(ID_Quit, _T("E&xit"));

    wxMenu *menuView = new wxMenu;
    menuView->Append(ID_ObjLabelColour, _T("&Obj Label Colour"));
    menuView->Append(ID_BkgLabelColour, _T("&Bkg Label Colour"));

    menuView->AppendSeparator();

    menuView->Append(ID_View0, _T("&All views...\tCTRL+'"));
    menuView->Append(ID_View1, _T("View&1...\tCTRL+1"));
    menuView->Append(ID_View2, _T("View&2...\tCTRL+2"));
    menuView->Append(ID_View3, _T("View&3...\tCTRL+3"));
    menuView->Append(ID_View4, _T("View&4...\tCTRL+4"));

    menuView->AppendSeparator();
    menuView->Append(ID_Zoomin, _T("Zoom &In...\tCTRL+a"));
    menuView->Append(ID_Zoomout, _T("Zoom &Out...\tCTRL+z"));

    wxMenu *menuHelp = new wxMenu;
    menuHelp->Append(ID_About,  _T("&About..."));

    wxMenuBar* menuBar = new wxMenuBar;
    menuBar->Append( menuFile,    _T("&File") );
    menuBar->Append( menuView, _T("&View") );
    menuBar->Append( menuHelp,    _T("&Help") );

    SetMenuBar( menuBar );


    //********************************
    //wxBitmapButton *butPreproc = new wxBitmapButton(toolBar, ID_Preproc, *bmPreproc, wxDefaultPosition, wxDefaultSize, wxBU_AUTODRAW, wxDefaultValidator, _T("Preprocessing"));

    /*
    LabeledBitmapButton *butPreproc;
    butPreproc = new LabeledBitmapButton(toolBar, ID_Preproc,
      			       *bmPreproc, _T("Preproc"));
    //butPreproc->Update();

    wxColour wxcolor;
    SetColor(&wxcolor, 0xffffdd);
    butPreproc->SetBackgroundColour(wxcolor);

    //butPreproc->SetBitmapDisabled(*bmAnalysis);
    //butPreproc->Disable();

    toolBar->AddControl((wxControl*)butPreproc);

    //wxBitmap bmdis = butPreproc->GetBitmapDisabled();
    //bmdis.SaveFile(_T("disa.bmp"), wxBITMAP_TYPE_BMP, NULL);
    */
    wxBitmap *bmRun = new wxBitmap(run_xpm);
    wxBitmap *bmZoomin = new wxBitmap(zoomin_xpm);
    wxBitmap *bmZoomout = new wxBitmap(zoomout_xpm);
//    wxBitmap *bmAddMarker = new wxBitmap(gear_xpm);
//    wxBitmap *bmNavigator = new wxBitmap(navigator_xpm);
    wxBitmap *bmFilter = new wxBitmap(filter_xpm);
//    wxBitmap *bmEraser = new wxBitmap(eraser_xpm);

    toolBar = CreateToolBar(wxTB_HORIZONTAL | wxTB_TEXT, -1, _T("toolBar"));

//    toolBar->AddCheckTool(ID_Awe, _T("Arc-weight estimation"), *bmNavigator,
//                          *bmNavigator, _T("Pre-processing Mode"), _T(""), NULL);
//    toolBar->AddCheckTool(ID_Segmentation, _T("Segmentation (IFT)"), *bmAddMarker,
//                          *bmAddMarker, _T("Execution Mode"), _T(""), NULL);

    toolBar->AddTool(ID_Run, _T("Run"), *bmRun,
                     _T("Executes the current module"), wxITEM_NORMAL);

    toolBar->AddSeparator();

    toolBar->AddTool(ID_Zoomin, _T("Zoom In"), *bmZoomin,
                     _T("Zooms the image in"), wxITEM_NORMAL);

    toolBar->AddTool(ID_Zoomout, _T("Zoom Out"), *bmZoomout,
                     _T("Zooms the image out"), wxITEM_NORMAL);

    toolBar->AddSeparator();

    toolBar->AddTool(ID_FinExp, _T("Finish experiment"), *bmFilter, _T("Computes experiment data"), wxITEM_NORMAL);

    toolBar->ToggleTool(ID_Awe, true);
    toolBar->ToggleTool(ID_Segmentation, false);
    toolBar->Realize();


    //Display
    wxBoxSizer *hsizer = new wxBoxSizer(wxHORIZONTAL);

    panel = new wxPanel(this, wxID_ANY, wxDefaultPosition,
                        wxDefaultSize, wxBORDER_NONE);//wxBORDER_SIMPLE);
    //panel->SetBackgroundColour(*wxBLUE);
    splitter = new wxSplitterWindow(this, wxID_ANY, wxDefaultPosition, wxDefaultSize, wxSP_3D, _T("hsplitter"));

    topWindow = new wxSplitterWindow(splitter, wxID_ANY, wxDefaultPosition, wxDefaultSize, wxSP_3D, _T("top"));
    topWindow->Show(true);

    bottomWindow = new wxSplitterWindow(splitter, wxID_ANY, wxDefaultPosition, wxDefaultSize, wxSP_3D, _T("bottom"));
    bottomWindow->Show(true);

    splitter->SetMinimumPaneSize(20);  // Set this to prevent unsplitting
    splitter->SplitHorizontally( topWindow, bottomWindow );
    splitter->SetSashGravity(0.5);

    Views[0] = NULL;
    Views[1] = NULL;
    Views[2] = NULL;
    Views[3] = NULL;

    vsizer = new wxBoxSizer(wxVERTICAL);

    panel->SetSizer(vsizer, true);
    vsizer->SetSizeHints(panel);

    hsizer->Add(panel,    0, wxALIGN_LEFT|wxEXPAND);
    hsizer->Add(splitter, 1, wxEXPAND);
    SetSizer(hsizer, true);
    hsizer->SetSizeHints(this);

    wxSystemScreenType sst = wxSystemSettings::GetScreenType();
    if (sst==wxSYS_SCREEN_TINY || sst==wxSYS_SCREEN_PDA)
    {
        SetSize(320, 240);
    }
    else if (sst==wxSYS_SCREEN_SMALL)
    {
        SetSize(640, 480);
    }
    else if (sst==wxSYS_SCREEN_DESKTOP || sst==wxSYS_SCREEN_NONE)
    {
        SetSize(800, 600);
    }
    else
    {
        SetSize(800, 600);
    }

    vsizer->Layout();

    //Statusbar
    CreateStatusBar();
    SetStatusText( _T("Welcome to USIS - User-Steered Image Segmentation!") );
}

void MyFrame :: AppendModuleMenu(const wxString& menuLabel, wxArrayString modLabels, int* modIDArray)
{
    if (modIDArray == NULL) return;

    wxMenuBar *menuBar = GetMenuBar();

    if (menuBar == NULL) return;

    wxMenu* menu = new wxMenu();

    int i;

    for (i = 0; i < modLabels.size(); i++)
        menu->Append(modIDArray[i], modLabels[i]);

    wxMenu* menuHelp = menuBar->Remove(menuBar->GetMenuCount() - 1);

    menuBar->Append(menu, menuLabel);

    menuBar->Append(menuHelp, _T("&Help"));

    SetMenuBar(menuBar);
}

void MyFrame::AppendOptPanel(wxPanel *panel)
{
    wxWindow *parent = (wxWindow *)this->panel;
    if (parent==NULL || panel==NULL) return;

    panel->Reparent(parent);
    panel->Show(true);

    if (vsizer->GetItem(panel,false)!=NULL)
        vsizer->Detach(panel);

    vsizer->Add(panel, 0, wxEXPAND);
    vsizer->SetSizeHints(parent);
    vsizer->Layout();
    topWindow->SetSashPosition(topWindow->GetSize().GetWidth()/2);
    bottomWindow->SetSashPosition(bottomWindow->GetSize().GetWidth()/2);
    Layout();
}


void MyFrame::PrependOptPanel(wxPanel *panel)
{

    wxWindow *parent = (wxWindow *)this->panel;
    if (parent==NULL || panel==NULL) return;

    panel->Reparent(parent);
    panel->Show(true);

    if (vsizer->GetItem(panel,false)!=NULL)
        vsizer->Detach(panel);

    vsizer->Prepend(panel, 0, wxEXPAND);
    vsizer->SetSizeHints(parent);
    vsizer->Layout();
    topWindow->SetSashPosition(topWindow->GetSize().GetWidth()/2);
    bottomWindow->SetSashPosition(bottomWindow->GetSize().GetWidth()/2);
    Layout();
}

bool MyFrame::DetachOptPanel(wxPanel *panel)
{
    //wxWindow *parent = vsizer->GetContainingWindow();
    wxWindow *parent = (wxWindow *)this->panel;
    bool ret;

    if (parent==NULL || panel==NULL) return false;

    panel->Hide();
    ret = vsizer->Detach(panel);
    vsizer->SetSizeHints(parent);
    vsizer->Layout();
    topWindow->SetSashPosition(topWindow->GetSize().GetWidth()/2);
    bottomWindow->SetSashPosition(bottomWindow->GetSize().GetWidth()/2);
    Layout();

    return ret;
}

void MyFrame::SetViewPanel(wxPanel *view, int pos)
{
    wxSplitterWindow *splitter;

    if (pos==0 || pos==1)
        splitter = topWindow;
    else if (pos==2 || pos==3)
        splitter = bottomWindow;
    else return;

    // Set this to prevent unsplitting
    splitter->SetMinimumPaneSize(20);

    view->Reparent(splitter);
    if (Views[pos]!=NULL)
    {
        splitter->ReplaceWindow(Views[pos], view);
        delete Views[pos];
        Views[pos] = view;
        Views[pos]->Show(true);
    }
    else
    {
        Views[pos] = view;
        Views[pos]->Show(true);
        if (splitter->IsSplit())
            splitter->Unsplit(NULL);

        if (pos%2==0)
        {
            if (Views[pos+1]!=NULL)
                splitter->SplitVertically(view, Views[pos+1]);
            else
                splitter->Initialize(view);
        }
        else
        {
            if (Views[pos-1]!=NULL)
                splitter->SplitVertically(Views[pos-1], view);
            else
                splitter->Initialize(view);
        }
    }
    splitter->SetSashGravity(0.5);
}

wxPanel* MyFrame :: GetViewPanel(int pos)
{
    if (pos < 0 || pos > 3) return NULL;

    return Views[pos];
}

//
//MyFrame::MyFrame(const wxString& title, const wxPoint& pos, const wxSize& size)
//        : wxFrame((wxFrame *)NULL, -1, title, pos, size)
//{
//    wxColour wxcolor;
//
//    ///Menubar
//    wxMenu *menuFile = new wxMenu;
//    menuFile->Append(ID_LoadImg,   _T("&Load Image..."));
//    menuFile->Append(ID_LoadGraph, _T("Lo&ad Graph..."));
//    menuFile->Append(ID_LoadMark,  _T("Load Mar&kers..."));
//    menuFile->AppendSeparator();
//    menuFile->Append(ID_SaveObject, _T("&Save Object..."));
//    menuFile->Append(ID_SaveMark,  _T("Save &Markers..."));
//    menuFile->Append(ID_SaveFeats,  _T("Save &Features..."));
//    menuFile->Append(ID_SaveLabel, _T("Sa&ve Label..."));
//    menuFile->Append(ID_SaveObjMap, _T("Save Obj M&ap..."));
//    menuFile->Append(ID_SaveBkgMap, _T("Save B&kg Map..."));
//    menuFile->AppendSeparator();
//    menuFile->Append(ID_ExportImages, _T("&Export Images..."));
//    menuFile->Append(ID_ExportGraph, _T("Export &Graph..."));
//    menuFile->AppendSeparator();
//    menuFile->Append(ID_Quit, _T("E&xit"));
//
//    wxMenu *menuOptions = new wxMenu;
//    menuOptions->Append(ID_ObjLabelColour, _T("&Obj Label Colour"));
//    menuOptions->Append(ID_BkgLabelColour, _T("&Bkg Label Colour"));
//
//    wxMenu *menuHelp = new wxMenu;
//    menuHelp->Append(ID_About,  _T("&About..."));
//
//    wxMenuBar *menuBar = new wxMenuBar;
//    menuBar->Append( menuFile,    _T("&File") );
//    menuBar->Append( menuOptions, _T("&Options") );
//    menuBar->Append( menuHelp,    _T("&Help") );
//
//    SetMenuBar( menuBar );
//
/////---------------------------------------
//
//    ///Toolbar
//    wxBitmap *bmRun = new wxBitmap(run_xpm);
//    wxBitmap *bmZoomin = new wxBitmap(zoomin_xpm);
//    wxBitmap *bmZoomout = new wxBitmap(zoomout_xpm);
//    wxBitmap *bmAddMarker = new wxBitmap(gear_xpm);
//    wxBitmap *bmNavigator = new wxBitmap(filter_xpm);
//    wxBitmap *bmEraser = new wxBitmap(eraser_xpm);
//
//    toolBar = CreateToolBar(wxTB_HORIZONTAL | wxTB_TEXT, -1, _T("toolBar"));
//
//    toolBar->AddCheckTool(ID_Awe, _T("Arc-weight estimation"), *bmNavigator,
//                          *bmNavigator, _T("Pre-processing Mode"), _T(""), NULL);
//    toolBar->AddCheckTool(ID_Segmentation, _T("Segmentation (IFT)"), *bmAddMarker,
//                          *bmAddMarker, _T("Execution Mode"), _T(""), NULL);
//
//    toolBar->AddSeparator();
//    toolBar->AddTool(ID_Run, _T("Run"), *bmRun, _T("Run"), wxITEM_NORMAL);
//    toolBar->AddSeparator();
//
//    toolBar->AddTool(ID_Zoomin, _T("Zoom In"), *bmZoomin,
//                     _T("Zooms in the image"), wxITEM_NORMAL);
//    toolBar->AddTool(ID_Zoomout, _T("Zoom Out"), *bmZoomout,
//                     _T("Zooms out the image"), wxITEM_NORMAL);
//    toolBar->AddTool(ID_Clean_Markers, _T("Clean Markers"), *bmEraser,
//                     _T("Clean the image seeds"), wxITEM_NORMAL);
//
//    toolBar->ToggleTool(ID_Awe, true);
//    toolBar->ToggleTool(ID_Segmentation, false);
//    toolBar->Realize();
//
//    //Display
//    wxBoxSizer *hsizer = new wxBoxSizer(wxHORIZONTAL);
//
//    panel = new wxPanel(this, wxID_ANY, wxDefaultPosition, wxDefaultSize, wxSIMPLE_BORDER);
//    SetColor(&wxcolor, 0xCCCCCC);
//
/////---------------------------------------
//
//    /// Canvas
//
//    wxSplitterWindow *splitter = new wxSplitterWindow(this, wxID_ANY, wxDefaultPosition,
//            wxDefaultSize, wxSP_3D, _T("hsplitter"));
//
//    wxSplitterWindow *topWindow = new wxSplitterWindow(splitter, wxID_ANY,
//            wxDefaultPosition, wxDefaultSize, wxSP_3D, _T("top"));
//    topWindow->Show(true);
//
//    wxSplitterWindow *bottomWindow = new wxSplitterWindow(splitter, wxID_ANY,
//            wxDefaultPosition, wxDefaultSize, wxSP_3D, _T("bottom"));
//    bottomWindow->Show(true);
//
//    splitter->SetMinimumPaneSize(20);  // Set this to prevent unsplitting
//    splitter->SplitHorizontally( topWindow, bottomWindow );
//    splitter->SetSashGravity(0.5);
//
//    Views[0] = new ColorView(topWindow, 0);
//    Views[1] = new GreyscaleView(topWindow, 1);
//    Views[2] = new GreyscaleView(bottomWindow, 2);
//    Views[3] = new GreyscaleView(bottomWindow, 3);
//
//    Views[0]->Show(true);
//    Views[1]->Show(true);
//    Views[2]->Show(true);
//    Views[3]->Show(true);
//
//    topWindow->SetMinimumPaneSize(20);  // Set this to prevent unsplitting
//    bottomWindow->SetMinimumPaneSize(100);
//
//    topWindow->SplitVertically(Views[0], Views[1] );
//    bottomWindow->SplitVertically( Views[2], Views[3] );
//
//    topWindow->SetSashGravity(0.5);
//    bottomWindow->SetSashGravity(0.5);
//
/////---------------------------------------
//
//    /// Option panel
//
//    /** Common options **/
//    vsizer = new wxBoxSizer(wxVERTICAL);
//
//    wxStaticText *tMarker = new wxStaticText(panel, -1, _T("Marker"), wxDefaultPosition, wxDefaultSize, wxALIGN_LEFT, _T("staticText1"));
//
//    wxString mkChoices[2];
//    mkChoices[0] = _T("On");
//    mkChoices[1] = _T("Off");
//
//    chMarker = new wxChoice(panel, ID_MarkerOnOff, wxDefaultPosition,
//                            wxDefaultSize, 2, mkChoices, 0, wxDefaultValidator, _T("choice3"));
//
//    chMarker->SetSelection(0);
//
//    hbsMarker    = new wxBoxSizer(wxHORIZONTAL);
//    hbsMarker->Add(tMarker, 1, wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL);
//    hbsMarker->Add(chMarker, 0, wxALIGN_RIGHT);
//
//    bPicker = new BrushPicker(this, wxID_ANY);
//
//    bpsizer = new wxStaticBoxSizer(wxVERTICAL, panel, _T("Brush Selection"));
//    vosizer = new wxStaticBoxSizer(wxVERTICAL, panel, _T("View Options"));
//
//    bpsizer->AddSpacer(5);
//    bpsizer->Add(bPicker,   0, wxALIGN_CENTER);
//
//    vosizer->AddSpacer(5);
//    vosizer->Add(hbsMarker,    0, wxEXPAND);
//
/////---------------------------------------
//
//    /** AWE options **/
//    wxStaticText *tDistMethod = new wxStaticText(panel, -1, _T("Classif. Method"), wxDefaultPosition, wxDefaultSize, wxALIGN_LEFT, _T("staticText1"));
//    wxStaticText *tWobj   = new wxStaticText(panel, -1, _T("Wobj"), wxDefaultPosition, wxDefaultSize, wxALIGN_LEFT, _T("staticText6"));
//
//
//    wxString classifChoices[3];
//    classifChoices[0] = _T("Knn");
//    classifChoices[1] = _T("SupOPF");
//    classifChoices[2] = _T("GP(SupOPF)");
//
//    chClassifMethod = new wxChoice(panel, ID_ChooseClassif, wxDefaultPosition,
//                                   wxDefaultSize, 3, classifChoices, 0, wxDefaultValidator, _T("Classif. Method"));
//
//    chClassifMethod->SetSelection(1);
//
//    spWobj = new wxSpinCtrl(panel, ID_Wobj, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxSP_ARROW_KEYS, 0, 100, 50, _T("wxSpinCtrl1"));
//    buGPTree = new wxButton(panel, ID_ButGPTree, _T("Show GP Tree"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("button1"));
////
////    hbsDistMethod = new wxBoxSizer(wxHORIZONTAL);
//    hbsWobj      = new wxBoxSizer(wxHORIZONTAL);
////
////    hbsDistMethod->Add(tDistMethod, 1, wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL);
////    hbsDistMethod->Add(chClassifMethod, 0, wxALIGN_RIGHT);
////
//    hbsWobj->Add(tWobj,  1, wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL);
//    hbsWobj->Add(spWobj, 0, wxALIGN_RIGHT);
////
////    gosizer = new wxStaticBoxSizer(wxVERTICAL, panel, _T("Gradient Options"));
////
////    gosizer->AddSpacer(6);
////    gosizer->Add(hbsDistMethod, 0, wxEXPAND);
//    gosizer->Add(hbsWobj,   0, wxEXPAND);
//    gosizer->Add(buGPTree, 0, wxEXPAND);
//    gosizer->Hide(buGPTree, true);
///////------------------------------------------
//
//    /** Segmentation options **/
//    wxStaticText *tHighlight = new wxStaticText(panel, -1, _T("Label"), wxDefaultPosition, wxDefaultSize, wxALIGN_LEFT, _T("staticText0"));
//
//    wxString sgChoices[7];
//
//    sgChoices[0] = _T("DIFT");
//    sgChoices[1] = _T("Tree Pruning");
//    sgChoices[2] = _T("Kappa ConnComp");
//    sgChoices[3] = _T("IFT + graphcut");
//    sgChoices[4] = _T("Max-Flow");
//    sgChoices[5] = _T("OPF + DIFT");
//    sgChoices[6] = _T("Live Wire");
//
//    chMethod = new wxChoice(panel, ID_Method, wxDefaultPosition, wxDefaultSize,
//                            7, sgChoices, 0, wxDefaultValidator, _T("choice0"));
//    chMethod->SetSelection(0);
//
//    wxString lbChoices[3];
//    lbChoices[0] = _T("Fill");
//    lbChoices[1] = _T("Border");
//    lbChoices[2] = _T("Off");
//    chHighlight = new wxChoice(panel, ID_Highlight, wxDefaultPosition,
//                               wxDefaultSize, 3, lbChoices, 0, wxDefaultValidator, _T("choice1"));
//    chHighlight->SetSelection(0);
//
//    buRepeat = new wxButton(panel, ID_ButRepeat, _T("Repeat seeds"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("button1"));
//
//    hbsMethod    = new wxBoxSizer(wxHORIZONTAL);
//    hbsHighlight = new wxBoxSizer(wxHORIZONTAL);
//
//    hbsMethod->Add(chMethod, 0, wxALIGN_CENTER_VERTICAL);
//
//    hbsHighlight->Add(tHighlight, 1, wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL);
//    hbsHighlight->Add(chHighlight, 0, wxALIGN_RIGHT);
//
//    sgsizer = new wxStaticBoxSizer(wxVERTICAL, panel, _T("Segmentation method"));
//    prsizer = new wxStaticBoxSizer(wxVERTICAL, panel, _T("Extra Parameters"));
//
//    sgsizer->Add(hbsMethod,    0, wxEXPAND);
//    vosizer->Add(hbsHighlight, 0, wxEXPAND);
//    bpsizer->Add(buRepeat,  0, wxEXPAND);
//    bpsizer->Hide(buRepeat, true);
//
//    param = new DIFTExtraParameters(panel, prsizer);
//
/////---------------------------------------
//
//    /** Setting-up panel sizers **/
//
//    vsizer->AddSpacer(5);
//    vsizer->Add(sgsizer,  0, wxEXPAND);
//
//    vsizer->AddSpacer(5);
//    vsizer->Add(vosizer,  0, wxEXPAND);
//
//    vsizer->AddSpacer(15);
//    vsizer->Add(bpsizer,  0, wxEXPAND);
//
//    vsizer->AddSpacer(15);
//    vsizer->Add(gosizer,  0, wxEXPAND);
//
//    vsizer->AddSpacer(15);
//    vsizer->Add(prsizer,  0, wxEXPAND);
//
//    panel->SetSizer(vsizer, true);
//    vsizer->SetSizeHints(panel);
//
/////---------------------------------------
//
//    /// Adding panel and splitter to frame
//    hsizer->Add(panel,    0, wxALIGN_LEFT|wxEXPAND);
//    hsizer->Add(splitter, 1, wxEXPAND);
//
//    SetSizer(hsizer, true);
//    hsizer->SetSizeHints(this);
//
/////---------------------------------------
//
//    /// Setting-up screen options
//    wxSystemScreenType sst = wxSystemSettings::GetScreenType();
//    if (sst==wxSYS_SCREEN_TINY || sst==wxSYS_SCREEN_PDA)
//    {
//        SetSize(320, 240);
//    }
//    else if (sst==wxSYS_SCREEN_SMALL)
//    {
//        SetSize(640, 480);
//    }
//    else if (sst==wxSYS_SCREEN_DESKTOP || sst==wxSYS_SCREEN_NONE)
//    {
//        SetSize(800, 600);
//    }
//    else
//    {
//        SetSize(800, 600);
//    }
//
/////---------------------------------------
//    /// hiding segmentation stuff
//    vsizer->Show(prsizer, false, false);
//    vsizer->Layout();
//    vsizer->Show(sgsizer, false, true);
//    vsizer->Layout();
//    vosizer->Show(hbsHighlight, false, true);
//    vosizer->Layout();
//    prsizer->Layout();
//
/////---------------------------------------
//
//    /// Inializing data
//    AppData = new APPData();
//
/////---------------------------------------
//
////    GraphDrawOptDialog::SetDefaultOptions();
//
//
//    int r = GetBrushSize();
//
//    Views[0]->canvas->SetInteractionHandler(new ImageMode::AddMarkersHandler(r,"awe"));
//
/////---------------------------------------
//
//    ///Statusbar
//    CreateStatusBar();
//    SetStatusText( _T("Welcome to Usis - User-Steered Image Segmentation!") );
//}

MyFrame::~MyFrame()
{
}

void MyFrame::SetMode(int id)
{
    string op;
    toolBar->ToggleTool(ID_Awe,  false);
    toolBar->ToggleTool(ID_Segmentation, false);

    switch (id)
    {
    case ID_Awe:
        toolBar->ToggleTool(ID_Awe,  true);
        break;
    case ID_Segmentation:
        toolBar->ToggleTool(ID_Segmentation,  true);
        break;
    case ID_Pre_proc:
        break;
    }

    vsizer->Layout();
}

void MyFrame :: ToggleMode(int id, bool toggle)
{
    switch (id)
    {
    case ID_Awe:
        toolBar->ToggleTool(ID_Awe,  toggle);
        break;
    case ID_Segmentation:
        toolBar->ToggleTool(ID_Segmentation,  toggle);
        break;
    }
}

void  MyFrame::EnableOperationMode(int op, bool enable)
{
    if (op==1)
        toolBar->EnableTool(ID_Segmentation, enable);
    else if (op==0)
        toolBar->EnableTool(ID_Awe,  enable);
}

void  MyFrame::SetOperationMode(int op)
{
//    if (op==1)
//    {
//        toolBar->ToggleTool(ID_Awe,  false);
//        toolBar->ToggleTool(ID_Segmentation, true);
//        vsizer->Show(prsizer, true, false);
//        vsizer->Show(sgsizer, true, true);
//        vsizer->Show(vosizer, true, true);
//        vsizer->Show(gosizer, false, true);
//        vosizer->Show(hbsHighlight, true, true);
////        gosizer->Hide(hbsGType, true);
////        gosizer->Hide(hbsGInput, true);
//        bpsizer->Show(buRepeat, true, true);
//        prsizer->Layout();
//        vosizer->Layout();
//        sgsizer->Layout();
//        vsizer->Layout();
//    }
//    else if (op==0)
//    {
//        toolBar->ToggleTool(ID_Awe,  true);
//        toolBar->ToggleTool(ID_Segmentation, false);
//        vsizer->Show(prsizer, false, false);
//        vsizer->Show(sgsizer, false, true);
//        vsizer->Show(vosizer, true, true);
//        vsizer->Show(gosizer, true, true);
//        vosizer->Show(hbsHighlight, false, true);
////        gosizer->Hide(hbsGType, true);
////        gosizer->Hide(hbsGInput, true);
//        //gosizer->Hide(hbsKmax, true);
//        bpsizer->Hide(buRepeat, true);
//        vosizer->Layout();
//        sgsizer->Layout();
//        vsizer->Layout();
//    }

    //app_draw_frames();
}


int  MyFrame::GetOperationMode()
{
//    if (toolBar->GetToolState(ID_Awe))
//        return 0;
//    else if (toolBar->GetToolState(ID_Segmentation))
//        return 1;
//    return -1;
}


void MyFrame::GetMethod(int *method)
{
//    int sel;
//
//    sel = chMethod->GetSelection();
//    switch (sel)
//    {
//    case 0:
//        *method = ID_Method_DIFT;
//        break;
//    case 1:
//        *method = ID_Method_TP;
//        break;
//    case 2:
//        *method = ID_Method_KCC;
//        break;
//    case 3:
//        *method = ID_Method_IFT_GC;
//        break;
//    case 4:
//        *method = ID_Method_MF;
//        break;
//    case 5:
//        *method = ID_Method_OPF;
//        break;
//    case 6:
//        *method = ID_Method_LWIRE;
//        break;
//    }
}


void MyFrame::GetGradOptions(int *type, int *input,
                             float *Wobj)
{
//    int sel;
//
//    sel = chGradType->GetSelection();
//    switch (sel)
//    {
//    case 0:
//        *type = ID_GradType_ColorGrad;
//        break;
//    case 1:
//        *type = ID_GradType_Sobel;
//        break;
//    case 2:
//        *type = ID_GradType_Intensity;
//        break;
//    }
//
//
//    sel = chGradInput->GetSelection();
//    switch (sel)
//    {
//    case 0:
//        *input = ID_GradInput_Image;
//        break;
//    case 1:
//        *input = ID_GradInput_ObjMap;
//        break;
//    case 2:
//        *input = ID_GradInput_Both;
//        break;
//    }
//
////    *nscales = spNscales->GetValue();
////    *kmax = spKmax->GetValue();
//    *Wobj = spWobj->GetValue();
////    MAXDENS = spMaxDensity->GetValue();
////    *di = spImageBand->GetValue();
}

void MyFrame::GetViewOptions(int *highlight, int *marker)
{
//    int sel;
//
//    sel = chHighlight->GetSelection();
//    switch (sel)
//    {
//    case 0:
//        *highlight = ID_Highlight_Fill;
//        break;
//    case 1:
//        *highlight = ID_Highlight_Border;
//        break;
//    case 2:
//        *highlight = ID_Highlight_Off;
//        break;
//    }
//
//    sel = chMarker->GetSelection();
//    switch (sel)
//    {
//    case 0:
//        *marker = ID_MarkerOnOff_On;
//        break;
//    case 1:
//        *marker = ID_MarkerOnOff_Off;
//        break;
//    }
}

int MyFrame::GetBrushSize()
{
    return bPicker->GetBrushSize();
}

wxString MyFrame::LoadImagePath(const wxString& dirpath, const wxString& msg)
{
    wxString FILETYPES = wxString(
                             _("All files|*.*|"
                               "JPEG Image (*.jpg;*.jpeg)|*.jpg;*.jpeg|"
                               "Portable Pixel Map (.PPM)|*.ppm|"
                               "Portable Graymap Image (.pgm)|*.pgm|"
                               "Portable Bitmap Image (.pbm)|*.pbm|"
                               "Windows Bitmap Image (.bmp)|*.bmp|"
                               "GIF Image (.gif)|*.gif|"
                               "PNG Image (*.png)|*.png|"
                               "PCX Image (*.pcx)|*.pcx|"
                               "TIF Image (*.tif)|*.tif|"
                               "XPM Image (*.xpm)|*.xpm|"
                               "Windows Icon (*.ico)|*.ico|"
                               "Windows Cursor Image (*.cur)|*.cur|"
                              ));

#if wxMINOR_VERSION>=8
    wxFileDialog *openFileDialog =
        new wxFileDialog ( this, _T("Open file"), _T(""), _T(""), FILETYPES, wxOPEN|wxFD_PREVIEW, wxDefaultPosition);
#else
    wxFileDialog *openFileDialog =
        new wxFileDialog ( this, _T("Open file"), _T(""), _T(""), FILETYPES, wxOPEN, wxDefaultPosition);
#endif

    openFileDialog->SetDirectory(dirpath);

    if (openFileDialog->ShowModal() == wxID_OK)
    {
        if (msg == _(""))
            SetStatusText(_T("Loading ")+openFileDialog->GetFilename());
        else
            SetStatusText(msg);

        return openFileDialog->GetPath();
    }

    return _("");
}

wxString MyFrame::LoadFilePath(const wxString& dirpath, const wxString& windowmsg, const wxString& statusmsg,
                               const wxChar *FILETYPES)

{
    wxFileDialog *loadFileDialog =
        new wxFileDialog ( this,
                           windowmsg,
                           _T(""),
                           _T(""),
                           FILETYPES,
                           wxOPEN,
                           wxDefaultPosition);

    loadFileDialog->SetDirectory(dirpath);

    if (loadFileDialog->ShowModal() == wxID_OK)
    {
        SetStatusText(statusmsg);

        return wxString(loadFileDialog->GetPath());
    }

    return _("");
}

wxString MyFrame::SaveFilePath(const wxString& dirpath, const wxString& windowmsg, const wxString& statusmsg,
                               const wxChar *FILETYPES)

{
    wxFileDialog *saveFileDialog =
        new wxFileDialog ( this,
                           windowmsg,
                           _T(""),
                           _T(""),
                           FILETYPES,
                           wxSAVE,
                           wxDefaultPosition);

    saveFileDialog->SetDirectory(dirpath);

    if (saveFileDialog->ShowModal() == wxID_OK)
    {
        SetStatusText(statusmsg);

        return wxString(saveFileDialog->GetPath());
    }

    return _("");
}


void MyFrame::OnLoadGraph(wxCommandEvent & event)
{
//    static char dir[100] = {'\0'};
//    static const
//    wxChar
//    *FILETYPES = _T( "Graph files (.TXT)|*.txt|"
//                     "All files|*.*"
//                   );
//
//    wxFileDialog *openFileDialog =
//        new wxFileDialog ( this,
//                           _T("Load graph"),
//                           _T(""),
//                           _T(""),
//                           FILETYPES,
//                           wxOPEN,
//                           wxDefaultPosition);
//
//    if (dir[0]!='\0')
//    {
//        wxString wxdir(dir, wxConvUTF8);
//        openFileDialog->SetDirectory(wxdir);
//    }
//    if (openFileDialog->ShowModal() == wxID_OK)
//    {
//        wxBusyCursor wait;
//        SetStatusText(_T("Loading ")+openFileDialog->GetFilename());
//
//        char path[512];
//        strcpy( dir,  openFileDialog->GetDirectory().ToAscii() );
//        strcpy( path, openFileDialog->GetPath().ToAscii() );
//        LoadGraph(path);
//
//        AppData->filename =openFileDialog->GetFilename();
//
//        toolBar->EnableTool(ID_Clean_Markers,true);
//        toolBar->EnableTool(ID_Run,true);
//
//        SetStatusText(_T("Loading ")+openFileDialog->GetFilename()+_T("... Done"));
//    }
}


void MyFrame::OnExportGraph(wxCommandEvent & event)
{
//    static char dir[100] = {'\0'};
//    int s,filter;
//
//    static const
//    wxChar
//    *FILETYPES = _T( "EPS files (.EPS)|*.eps|"
//                     "All files|*.*"
//                   );
//
//
//    if (!AppData->IsLoaded())
//    {
//        wxMessageBox(_T("There is no image loaded!"), _T("No Data"), wxOK | wxICON_EXCLAMATION, this);
//        return;
//    }
//
//    wxFileDialog *saveFileDialog =
//        new wxFileDialog ( this,
//                           _T("Export graph"),
//                           _T(""),
//                           _T(""),
//                           FILETYPES,
//                           wxSAVE,
//                           wxDefaultPosition);
//
//    if (dir[0]!='\0')
//    {
//        wxString wxdir(dir, wxConvUTF8);
//        saveFileDialog->SetDirectory(wxdir);
//    }
//    if (saveFileDialog->ShowModal() == wxID_OK)
//    {
//        wxBusyCursor wait;
//        SetStatusText(_T("Export graph"));
//
//        char path[512];
//        strcpy( dir,  saveFileDialog->GetDirectory().ToAscii() );
//        strcpy( path, saveFileDialog->GetPath().ToAscii() );
//
//        s = strlen(path);
//        filter = saveFileDialog->GetFilterIndex();
//        if ( (s<3 || strcasecmp(path + s - 3, "eps")!=0) && filter==0 )
//            strcat(path,".eps");
//
//        ExportGraph(path);
//
//        SetStatusText(_T("Exporting to ")+saveFileDialog->GetFilename()+_T("... Done"));
//    }
}


void MyFrame::OnSaveLabel(wxCommandEvent & event)
{
//    static char dir[100] = {'\0'};
//    int s,filter;
//
//    static const
//    wxChar
//    *FILETYPES = _T( "Image files (.PGM)|*.pgm|"
//                     "All files|*.*"
//                   );
//
//
//    if (!AppData->IsLoaded())
//    {
//        wxMessageBox(_T("There is no image loaded!"), _T("No Data"), wxOK | wxICON_EXCLAMATION, this);
//        return;
//    }
//
//    wxFileDialog *saveFileDialog =
//        new wxFileDialog ( this,
//                           _T("Save label"),
//                           _T(""),
//                           _T(""),
//                           FILETYPES,
//                           wxSAVE|wxOVERWRITE_PROMPT,
//                           wxDefaultPosition);
//
//    if (dir[0]!='\0')
//    {
//        wxString wxdir(dir, wxConvUTF8);
//        saveFileDialog->SetDirectory(wxdir);
//    }
//    if (saveFileDialog->ShowModal() == wxID_OK)
//    {
//        wxBusyCursor wait;
//        SetStatusText(_T("Saving file ")+saveFileDialog->GetFilename());
//
//        char path[512];
//        strcpy( dir,  saveFileDialog->GetDirectory().ToAscii() );
//        strcpy( path, saveFileDialog->GetPath().ToAscii() );
//
//        s = strlen(path);
//        filter = saveFileDialog->GetFilterIndex();
//        if ( (s<3 || strcasecmp(path + s - 3, "pgm")!=0) && filter==0 )
//            strcat(path,".pgm");
//
//        WriteImage(AppData->label, path);
//
//        SetStatusText(_T("Saving file ")+saveFileDialog->GetFilename()+_T("... Done"));
//    }
}

void MyFrame::FilterSaveType(int saveoption, wxBitmapType* type, wxString* ext)
{
    typedef struct type_ext
    {
        wxString ext;
        wxBitmapType type;
    }type_ext;

    type_ext typeMap[12];

    typeMap[0] = (type_ext)
    {
        _(".png"),wxBITMAP_TYPE_PNG
    };
    typeMap[1] = (type_ext)
    {
        _(".ppm"),wxBITMAP_TYPE_PNM
    };
    typeMap[2] = (type_ext)
    {
        _(".pgm"),wxBITMAP_TYPE_PNM
    };
    typeMap[3] = (type_ext)
    {
        _(".pbm"),wxBITMAP_TYPE_PNM
    };
    typeMap[4] = (type_ext)
    {
        _(".bpm"),wxBITMAP_TYPE_BMP
    };
    typeMap[5] = (type_ext)
    {
        _(".gif"),wxBITMAP_TYPE_GIF
    };
    typeMap[6] = (type_ext)
    {
        _(".jpg"),wxBITMAP_TYPE_JPEG
    };
    typeMap[7] = (type_ext)
    {
        _(".pcx"),wxBITMAP_TYPE_PCX
    };
    typeMap[8] = (type_ext)
    {
        _(".tif"),wxBITMAP_TYPE_TIF
    };
    typeMap[9] = (type_ext)
    {
        _(".xpm"),wxBITMAP_TYPE_XPM
    };
    typeMap[10] = (type_ext)
    {
        _(".ico"),wxBITMAP_TYPE_ICO
    };
    typeMap[11] = (type_ext)
    {
        _(".cur"),wxBITMAP_TYPE_CUR
    };

    *type = typeMap[saveoption].type;
    *ext = typeMap[saveoption].ext;
}

wxString MyFrame::DefaultFileTypes()
{
    return wxString(_("PNG Image (*.png)|*.png|"
                      "Portable Pixel Map (.PPM)|*.ppm|"
                      "Portable Graymap Image (.pgm)|*.pgm|"
                      "Portable Bitmap Image (.pbm)|*.pbm|"
                      "Windows Bitmap Image (.bmp)|*.bmp|"
                      "GIF Image (.gif)|*.gif|"
                      "JPEG Image (*.jpg;*.jpeg)|*.jpg;*.jpeg|"
                      "PCX Image (*.pcx)|*.pcx|"
                      "XPM Image (*.xpm)|*.xpm|"
                      "Windows Icon (*.ico)|*.ico|"
                      "Windows Cursor Image (*.cur)|*.cur|"
                     ));
}

void MyFrame::OnSaveObject(wxCommandEvent & event)
{
//    bool status;
//    CImage *obj,*aux;
//    Pixel u,v;
//
//    wxString FILETYPES = DefaultFileTypes();
//
//    if (!AppData->IsLoaded())
//    {
//        wxMessageBox(_T("There is no image loaded!"), _T("No Data"), wxOK | wxICON_EXCLAMATION, this);
//        return;
//    }
//
//    wxFileDialog *saveFileDialog =
//        new wxFileDialog ( this,
//                           _T("Save object"),
//                           _T(""),
//                           _T(""),
//                           FILETYPES,
//                           wxSAVE|wxOVERWRITE_PROMPT,
//                           wxDefaultPosition);
//
//    saveFileDialog->SetDirectory(AppData->dirname);
//
//    if (saveFileDialog->ShowModal() == wxID_OK)
//    {
//        wxBusyCursor wait;
//        SetStatusText(_T("Saving file ")+saveFileDialog->GetFilename());
//
//        /** The opt has the index of the type filter chosen by the user
//         * and is used to tell the file extension and type to be used
//         * for saving the image
//         */
//        int opt = saveFileDialog->GetFilterIndex();
//
//        wxBitmapType type;
//        wxString ext;
//        FilterSaveType(opt, &type, &ext);
//
//        wxString path = saveFileDialog->GetPath();
//
//        if (!path.EndsWith(ext)) path.Append(ext);
//
//        obj = CopyCImageMask(AppData->orig, AppData->label, AppData->bkgColor);
//
//        ComputeMBB(obj, AppData->bkgColor, &(u.x), &(u.y), &(v.x), &(v.y));
//        aux = CopySubCImage(obj, u.x, u.y, v.x, v.y);
//
//        DestroyCImage(&obj);
//        obj = aux;
//
//        if (obj != NULL)
//        {
//
//            wxImage* img = ConvertToWXImage(obj);
//            img->SaveFile(path,type);
//            delete img;
//            DestroyCImage(&obj);
//            SetStatusText(_T("Saving file ")+saveFileDialog->GetFilename()+_T("... Done"));
//            status = true;
//        }
//        else
//        {
//            SetStatusText(_("Error! Select an object first!\n"));
//        }
//    }
}

void MyFrame::OnSaveObjMap(wxCommandEvent & event)
{
//    SaveMap(AppData->GetImg("objMap"), _("Save object probability map"), _("Error! No object map selected!"));
}


void MyFrame::OnSaveBkgMap(wxCommandEvent & event)
{
//    SaveMap(AppData->GetImg("bkgMap"), _("Save object probability map"), _("Error! No object map selected!"));
}


void MyFrame::SaveMap(Image* img, wxString savemsg, wxString errormsg)
{
//    bool status;
//
//    wxString FILETYPES = _("Portable Graymap Image (.pgm)|*.pgm|");
//
//    if (!AppData->IsLoaded())
//    {
//        wxMessageBox(_T("There is no image loaded!"), _T("No Data"), wxOK | wxICON_EXCLAMATION, this);
//        return;
//    }
//
//    wxFileDialog *saveFileDialog =
//        new wxFileDialog ( this,
//                           savemsg,
//                           _T(""),
//                           _T(""),
//                           FILETYPES,
//                           wxSAVE|wxOVERWRITE_PROMPT,
//                           wxDefaultPosition);
//
//    saveFileDialog->SetDirectory(AppData->dirname);
//
//    if (saveFileDialog->ShowModal() == wxID_OK)
//    {
//        wxBusyCursor wait;
//        SetStatusText(_T("Saving file ")+saveFileDialog->GetFilename());
//
//        /** The opt has the index of the type filter chosen by the user
//         * and is used to tell the file extension and type to be used
//         * for saving the image
//         */
////        int opt = saveFileDialog->GetFilterIndex();
//
//        wxString ext = _(".pgm");
//        wxString path = saveFileDialog->GetPath();
//
//        if (!path.EndsWith(ext)) path.Append(ext);
//
//        if (img != NULL)
//        {
//            WriteImage(img, path.char_str());
//
//            SetStatusText(_T("Saving file ")+saveFileDialog->GetFilename()+_T("... Done"));
//            status = true;
//        }
//        else
//        {
//            SetStatusText(errormsg);
//        }
//   app_reset_frame(); }
}

void MyFrame::OnCleanMarkers(wxCommandEvent & event)
{
    //app_reset_frame();
    //app_draw_frames();
}

void MyFrame::OnSaveMarkers(wxCommandEvent & event)
{
//    static char dir[100] = {'\0'};
//    int p,n,s,filter,nseeds,op,i=0,mk,lb,x,y;
//    FILE *fp;
//
//    static const
//    wxChar
//    *FILETYPES = _T( "Text files (.TXT)|*.txt|"
//                     "All files|*.*"
//                   );
//
//    if (!AppData->IsLoaded())
//    {
//        wxMessageBox(_T("There is no image loaded!"), _T("No Data"), wxOK | wxICON_EXCLAMATION, this);
//        return;
//    }
//
//    wxFileDialog *saveFileDialog =
//        new wxFileDialog ( this,
//                           _T("Save Markers"),
//                           _T(""),
//                           _T(""),
//                           FILETYPES,
//                           wxSAVE|wxOVERWRITE_PROMPT,
//                           wxDefaultPosition);
//
//    if (dir[0]!='\0')
//    {
//        wxString wxdir(dir, wxConvUTF8);
//        saveFileDialog->SetDirectory(wxdir);
//    }
//    if (saveFileDialog->ShowModal() == wxID_OK)
//    {
//        wxBusyCursor wait;
//        SetStatusText(_T("Saving file ")+saveFileDialog->GetFilename());
//
//        char path[512];
//        strcpy( dir,  saveFileDialog->GetDirectory().ToAscii() );
//        strcpy( path, saveFileDialog->GetPath().ToAscii() );
//
//        s = strlen(path);
//        filter = saveFileDialog->GetFilterIndex();
//        if ( (s<3 || strcasecmp(path + s - 3, "txt")!=0) && filter==0 )
//            strcat(path,".txt");
//
//        op = GetOperationMode();
//        if (op<0) return;
//        i = op;
//
//        nseeds = 0;
//        n = AppData->GetWidth()*AppData->GetHeight();
//        for (p=0; p<n; p++)
//        {
//            mk = (AppData->seedMkMap[i])->val[p];
//            if (mk>0)
//                nseeds++;
//        }
//
//        fp = fopen(path,"w");
//        if (!fp)
//        {
//            wxMessageBox(_T("Error opening file for writing!"), _T("Error"), wxOK | wxICON_EXCLAMATION, this);
//            return;
//        }
//        fprintf(fp,"%d %d %d\n",nseeds,AppData->GetWidth(), AppData->GetHeight());
//
//        for (p=0; p<n; p++)
//        {
//            mk = (AppData->seedMkMap[i])->val[p];
//
//            if (mk>0)
//            {
//                lb = (AppData->seedLbMap[i])->val[p];
//                x = p%AppData->GetWidth();
//                y = p/AppData->GetWidth();
//                fprintf(fp,"%d %d %d %d\n",x,y,mk,lb);
//            }
//
//        }
//        fclose(fp);
//
//        SetStatusText(_T("Saving file ")+saveFileDialog->GetFilename()+_T("... Done"));
//    }
}

void MyFrame::OnSaveFeats(wxCommandEvent & event)
{
//    static char dir[100] = {'\0'};
//    int p,n,s,filter,op,i=0;
//    FILE *fp;
//
//    static const
//    wxChar
//    *FILETYPES = _T( "Text files (.TXT)|*.txt|"
//                     "All files|*.*"
//                   );
//
//    if (!AppData->IsLoaded())
//    {
//        wxMessageBox(_T("There is no image loaded!"), _T("No Data"), wxOK | wxICON_EXCLAMATION, this);
//        return;
//    }
//
//    wxFileDialog *saveFileDialog =
//        new wxFileDialog ( this,
//                           _T("Save Markers"),
//                           _T(""),
//                           _T(""),
//                           FILETYPES,
//                           wxSAVE|wxOVERWRITE_PROMPT,
//                           wxDefaultPosition);
//
//    if (dir[0]!='\0')
//    {
//        wxString wxdir(dir, wxConvUTF8);
//        saveFileDialog->SetDirectory(wxdir);
//    }
//    if (saveFileDialog->ShowModal() == wxID_OK)
//    {
//        wxBusyCursor wait;
//        SetStatusText(_T("Saving file ")+saveFileDialog->GetFilename());
//
//        char path[512];
//        strcpy( dir,  saveFileDialog->GetDirectory().ToAscii() );
//        strcpy( path, saveFileDialog->GetPath().ToAscii() );
//
//        s = strlen(path);
//        filter = saveFileDialog->GetFilterIndex();
//        if ( (s<3 || strcasecmp(path + s - 3, "txt")!=0) && filter==0 )
//            strcat(path,".txt");
//
//        op = GetOperationMode();
//        if (op<0) return;
//        i = op;
//
//        n = AppData->GetWidth()*AppData->GetHeight();
//
//        fp = fopen(path,"w");
//        if (!fp)
//        {
//            wxMessageBox(_T("Error opening file for writing!"), _T("Error"), wxOK | wxICON_EXCLAMATION, this);
//            return;
//        }
//        fprintf(fp,"%d %d %d\n",AppData->GetWidth(),AppData->GetHeight(), AppData->feat->nfeats);
//        if (AppData->feat != NULL)
//        {
//            for (p=0; p<n; p++)
//            {
//                int i;
////                fprintf(fp,"%d ",p);
//                for(i = 0; i < AppData->feat->nfeats; i++)
//                {
//                    fprintf(fp,"%f ",AppData->feat->elem[p].feat[i]);
//                }
//                fprintf(fp,"\n");
//            }
//            fclose(fp);
//        }
//        SetStatusText(_T("Saving file ")+saveFileDialog->GetFilename()+_T("... Done"));
//    }
}

void MyFrame::OnLoadMarkers(wxCommandEvent & event)
{
//    static char dir[100] = {'\0'};
//    int i,p,nseeds,x,y,mk,lb,op;
//    FILE *fp;
//
//    static const
//    wxChar
//    *FILETYPES = _T( "Text files (.TXT)|*.txt|"
//                     "All files|*.*"
//                   );
//
//    if (!AppData->IsLoaded())
//    {
//        wxMessageBox(_T("There is no image loaded!"), _T("No Data"), wxOK | wxICON_EXCLAMATION, this);
//        return;
//    }
//
//    wxFileDialog *openFileDialog =
//        new wxFileDialog ( this,
//                           _T("Load Markers"),
//                           _T(""),
//                           _T(""),
//                           FILETYPES,
//                           wxOPEN,
//                           wxDefaultPosition);
//
//    if (dir[0]!='\0')
//    {
//        wxString wxdir(dir, wxConvUTF8);
//        openFileDialog->SetDirectory(wxdir);
//    }
//    if (openFileDialog->ShowModal() == wxID_OK)
//    {
//        wxBusyCursor wait;
//        SetStatusText(_T("Loading ")+openFileDialog->GetFilename());
//
//        char path[512];
//        strcpy( dir,  openFileDialog->GetDirectory().ToAscii() );
//        strcpy( path, openFileDialog->GetPath().ToAscii() );
//
//        op = GetOperationMode();
//        if (op<0) return;
//
//        fp = fopen(path,"r");
//        if (!fp)
//        {
//            wxMessageBox(_T("Error opening file!"), _T("Error"), wxOK | wxICON_EXCLAMATION, this);
//            return;
//        }
//
//        //app_reset_frame();
//        int w,h;
//        fscanf(fp," %d %d %d\n",&nseeds,&w,&h);
//        for (i=0;i<nseeds;i++)
//        {
//            fscanf(fp," %d %d %d %d \n",&x,&y,&mk,&lb);
//            if (ValidPixel(AppData->grad,x,y))
//            {
//                p = x + y*AppData->GetWidth();
//                (AppData->seedMkMap[op])->val[p] = mk;
//                (AppData->seedLbMap[op])->val[p] = lb;
//            }
//        }
//        fclose(fp);
//
//        SetStatusText(_T("Loading ")+openFileDialog->GetFilename()+_T("... Done"));
//        //app_draw_frames();
//    }
}


void MyFrame::LoadGraph(char *filename)
{
//    int s;
//    ExSparseGraph* exGraph;
//
//
//    if (AppData->IsLoaded())
//        AppData->UnloadData();
//
//    s = strlen(filename);
//    if ( strcasecmp(filename + s - 3, "txt") == 0 )
//    {
//        exGraph = ReadExSparseGraphFromTxt( filename );
//    }
//    else
//    {
//        wxMessageBox(_T("Unable to load graph data. Invalid file format!"), _T("Load Graph Error"), wxOK | wxICON_EXCLAMATION, this);
//        return;
//    }
//
//    int cols = ((exGraph)->G)->ncols;
//    int rows = ((exGraph)->G)->nrows;
//
//    AppData->CreateData(cols,rows, TXT_GRAPH, exGraph);
//    AppData->regions  = NULL;//CreateImage(AppData->GetWidth(), AppData->GetHeight());
//
//    AppData->SetLoaded(true);
//    SetOperationMode(1);
//    EnableOperationMode(0, false);
//    //app_reset_frame();
//    //app_draw_frames();
}


void MyFrame::ExportGraph(char *filename)
{
//    Image *label,*nodeval;
//    Set   *S=NULL;
//    int method,p,n,op;
//    char msg[512],text[512];
//    GraphDrawOptDialog dialog(this);
//
//    if (!AppData->IsLoaded()) return;
//
//    if (AppData->GetWidth()*AppData->GetHeight()>50*50)
//    {
//        sprintf(msg,"The graph has too many nodes (%d nodes).\n",AppData->GetWidth()*AppData->GetHeight());
//        sprintf(text,"Do you want to continue?"); //Proceed anyway?");
//        strcat(msg, text);
//
//        wxString wxmsg(msg, wxConvUTF8);
//        wxMessageDialog *question = new wxMessageDialog(this, wxmsg, _T("Continue?"), wxYES_NO | wxICON_QUESTION, wxDefaultPosition);
//        if (question->ShowModal() != wxID_YES)
//            return;
//    }
//
//    if (dialog.ShowConfigDialog()) return;
//
//    GetMethod(&method);
//    op = GetOperationMode();
//    if (op<0) return;
//
//    nodeval = dialog.GetNodeVal();
//
//    S = AppData->GetAllSeeds(op);
//    label = CopyImage(AppData->label);
//
//    n = AppData->GetWidth()*AppData->GetHeight();
//    for (p=0; p<n; p++)
//    {
//        if (AppData->IsInternalSeed(p, op))
//            label->val[p] = 1;
//        else if (AppData->IsExternalSeed(p, op))
//            label->val[p] = 0;
//    }
//
//    WriteSparseGraph2EPS(AppData->exGraph->G,
//                         filename,
//                         AppData->pred,
//                         label,
//                         nodeval,
//                         S, &GraphDrawOptDialog::opt);
//    DestroyImage(&nodeval);
//    DestroyImage(&label);
//    DestroySet(&S);
}



void MyFrame::ExportImages(char *filename)
{
//    Image *img8,*img7,*aux1,*i255;
//    CImage *cimg, *hcimg;
//    Set *Si=NULL,*Se=NULL,*seed=NULL;
//    char path[512];
//    int s, sel_highlight, sel_marker;
//    bool fill;
//
//    if (!AppData->IsLoaded()) return;
//
//    s = strlen(filename);
//    if (s<4) return;
//    filename[s-4] = '\0';
//
//    if (AppData->type==COLOR_IMAGE)
//    {
//        cimg = CImageRGBtoYCbCr(AppData->orig);
//        aux1 = CopyImage(cimg->C[0]);
//        DestroyCImage(&cimg);
//    }
//    else //GREY_IMAGE
//        aux1 = CopyImage((AppData->orig)->C[0]);
//
//    img8 = ConvertToNbits(aux1, 8);
//    img7 = ConvertToNbits(aux1, 7);
//    DestroyImage(&aux1);
//
//
//    i255 = CreateImage(AppData->GetWidth(),AppData->GetHeight());
//    SetImage(i255,255);
//
//    //Train Marker (colorful)
//    sprintf(path,"%s_trainmarker.ppm",filename);
//    GetViewOptions(&sel_highlight, &sel_marker);
//    cimg = (CImage*)calloc(1,sizeof(CImage));
//    cimg->C[0] = ConvertToNbits((AppData->orig)->C[0], 8);
//    cimg->C[1] = ConvertToNbits((AppData->orig)->C[1], 8);
//    cimg->C[2] = ConvertToNbits((AppData->orig)->C[2], 8);
//    AppData->HighlightMarkers(cimg, 0);
//    WriteCImage(cimg, path);
//    DestroyCImage(&cimg);
//
//
//    //Execution Marker (colorful)
//    sprintf(path,"%s_execmarker.ppm",filename);
//    cimg = (CImage*)calloc(1,sizeof(CImage));
//    cimg->C[0] = ConvertToNbits((AppData->orig)->C[0], 8);
//    cimg->C[1] = ConvertToNbits((AppData->orig)->C[1], 8);
//    cimg->C[2] = ConvertToNbits((AppData->orig)->C[2], 8);
//    AppData->HighlightMarkers(cimg, 1);
//    WriteCImage(cimg, path);
//    DestroyCImage(&cimg);
//
//
//    //Orig + Label+ Seeds (colorful)
//    sprintf(path,"%s_seg.ppm",filename);
//    cimg = (CImage*)calloc(1,sizeof(CImage));
//    cimg->C[0] = ConvertToNbits((AppData->orig)->C[0], 8);
//    cimg->C[1] = ConvertToNbits((AppData->orig)->C[1], 8);
//    cimg->C[2] = ConvertToNbits((AppData->orig)->C[2], 8);
//    fill = (sel_highlight==ID_Highlight_Fill);
//    hcimg = CWideHighlight(cimg, AppData->label, 2.9, AppData->objColor, fill);
//    if (sel_marker==ID_MarkerOnOff_On)
//        AppData->HighlightMarkers(hcimg, 1);
//    WriteCImage(hcimg, path);
//    DestroyCImage(&hcimg);
//    DestroyCImage(&cimg);
//
//
//    //Orig + Label+ Seeds (grey)
//    sprintf(path,"%s_seg.pgm",filename);
//    Si = AppData->GetInternalSeeds(1);
//    Se = AppData->GetExternalSeeds(1);
//    aux1 = WideHighlight(img8, AppData->label, 2.9, 255, fill);
//    seed = Si;
//    while (seed!=NULL)
//    {
//        aux1->val[seed->elem] = 255;
//        seed = seed->next;
//    }
//    seed = Se;
//    while (seed!=NULL)
//    {
//        aux1->val[seed->elem] = 0;
//        seed = seed->next;
//    }
//    WriteImage(aux1, path);
//    DestroyImage(&aux1);
//    DestroySet(&Si);
//    DestroySet(&Se);
//
//    int method;
//
//    GetMethod(&method);
//
//    //Gradiente
//    sprintf(path,"%s_grad.pgm",filename);
//    WriteImage(AppData->grad, path);
//
//    //ObjMap
//    sprintf(path,"%s_obj.pgm",filename);
//    WriteImage((AppData->exGraph)->t_link_S, path);
//
//    //BkgMap
//    sprintf(path,"%s_bkg.pgm",filename);
//    WriteImage((AppData->exGraph)->t_link_T, path);
//
//    DestroyImage(&i255);
//    DestroyImage(&img8);
//    DestroyImage(&img7);
}


void MyFrame::OnQuit(wxCommandEvent& event)
{
//    delete AppData;
    Close(TRUE);
}


int MyFrame::ChooseLabelColour(int prevcolor)
{
    wxColourDialog *colourDialog;
    wxColourData cdata;
    wxColour c;
    int r,g,b;

    r = t0(prevcolor);
    g = t1(prevcolor);
    b = t2(prevcolor);
    c.Set(r,g,b);
    cdata.SetColour(c);
    colourDialog = new wxColourDialog(this, &cdata);

    if (colourDialog->ShowModal() == wxID_OK)
    {
        cdata = colourDialog->GetColourData();
        c = cdata.GetColour();
        r = c.Red();
        g = c.Green();
        b = c.Blue();

        return triplet(r,g,b);
    }

    return -1;
}


void MyFrame::OnAbout(wxCommandEvent& WXUNUSED(event))
{
    wxString lic_unicamp = wxString(_("RESTRICTED FOR RESEARCH AND EDUCATIONAL USAGE\n"\
                                      "IN UNICAMP FACILITIES.\n"\
                                      "Terms of use: this release of USIS is available for research\n"\
                                      "and educational usage inside Unicamp only. The authors grant\n"\
                                      "permission to copy and install this software in computers\n"\
                                      "inside the campus. Users are not authorized to copy, sell, trade\n"\
                                      "or redistribute this software to/with third parties. The source\n"\
                                      "code, if made available, is for the convenience of compiling on\n"\
                                      "multiple platforms only. Derivative works and redistributions of\n"\
                                      "the source are not allowed at all."));

    wxString z(_("USIS version 1.0\nEdition/Distribution: unrestricted\n\n"\
                 "USIS - User-Steered Image Segmentation\n\n"\
                 "(C) 2005-2006 Alexandre X. Falcao and Thiago V. Spina\n"\
                 "Developed by Alexandre X. Falcao and Thiago V. Spina at the Institute of Computing,\n"\
                 "Unicamp, Campinas, Brazil.\n\n"\
                 "Website: http://www.ic.unicamp.br/~afalcao\n"\
                 "Contact: afalcao@ic.unicamp.br or thiago.spina@gmail.com\n\n"));

    wxString wxz = z.Append(lic_unicamp);
    wxMessageBox(wxz, _T("About USIS"), wxOK | wxICON_INFORMATION, this);
}



void MyFrame::OnRun(wxCommandEvent& WXUNUSED(event))
{
//    Image *aux1;
//    Image *objMap=NULL;
//    Image *bkgMap=NULL;
//
//    SparseGraph *graph;
//    //  FeatMap *fmap;
//    Features *f=NULL;
//    Subgraph *sg=NULL;
//    Subgraph* sgeval = NULL;
//    Set *Si=NULL,*Se=NULL,*Ppts=NULL;
//    timer tic,toc;
//    float totaltime;
//    int op,p,n,type,input,kmax,nscales;
//    int nsi, nse;
//
//    static int prevnsi = -1; // Previous internal seeds set size
//    static int prevnse = -1; // Previous external seeds set size
////    static int prevfeat = -1; // Previous feature choice
////    static int prevfeatmethod = -1; // Previous feat method
//    static int prevdistmethod = -1; // Previous distance method
//    static int prevWobj = -1; // Previsous Wobj
////    static int prevnormfeats = -1; // Previous value for Normalize Feats checkbox
//    static bool newfeats = false;
//
//    int method,measure,maxorder,lambda;
//    int volume=0, area=0;
//    bool posproc;
//    IFTGCExtraParameters *par_iftgc;
//    KCCExtraParameters *par_kcc;
//    MFExtraParameters *par_mf;
//    OPFExtraParameters *par_opf;
//    float Wobj;
//
//    if (!AppData->IsLoaded()) return;
//
////    wxWindowDisabler disableAll;
////    wxBusyCursor wait;
//
//    SetStatusText( _T("Please wait - Computation in progress...") );
//    gettimeofday(&tic,NULL);
//
//    n = AppData->GetWidth()*AppData->GetHeight();
//    op = GetOperationMode();
//
//    wxProgressDialog pd(_("Working..."),_("Please wait... Computation in progress..."),100,this,
//    wxPD_APP_MODAL | wxPD_AUTO_HIDE );
//
////        wxGauge pd(NULL,-1,100);
//    pd.Show();
//
//    if (op==1) // Execution
//    {
//
//        GetMethod(&method);
//
//        //----------Methods-----------------------------
//        if (method==ID_Method_DIFT)
//        {
//            pd.Update(10,_("Segmenting Image"));
//
//            Si = AppData->GetNewInternalSeeds(AppData->checkpoint, 1);
//            Se = AppData->GetNewExternalSeeds(AppData->checkpoint, 1);
//
//            if (AppData->checkpoint==0)
//            {
//                SetImage(AppData->pred, NIL);
//                SetImage(AppData->cost, INT_MAX);
//                SetImage(AppData->label, 0);
//            }
//
//            ChangeSparseGraphType((AppData->exGraph)->G,
//                                  DISSIMILARITY);
//
//            pd.Update(30,_("Segmenting Image"));
//
//            DifferentialIFT(AppData->label, AppData->cost,
//                            AppData->pred, (AppData->exGraph)->G,
//                            Si, Se);
//
//            pd.Update(60,_("Segmenting Image"));
//
//            AppData->checkpoint = AppData->markerID;
//        }
//
//        else if (method==ID_Method_TP)
//        {
//            pd.Update(10,_("Segmenting Image"));
//
//            Si = AppData->GetInternalSeeds(1);
//            Se = AppData->GetExternalSeeds(1);
//
//            SetImage(AppData->pred, NIL);
//            SetImage(AppData->cost, INT_MAX);
//            SetImage(AppData->label, 0);
//
//            pd.Update(10,_("Segmenting Image"));
//
//            ChangeSparseGraphType((AppData->exGraph)->G,
//                                  DISSIMILARITY);
//            pd.Update(20,_("Segmenting Image"));
//
//            DifferentialIFT(AppData->label, AppData->cost,
//                            AppData->pred, (AppData->exGraph)->G,
//                            Si, NULL);
//            Ppts = GetTPObject(AppData->pred, Se, (AppData->exGraph)->G);
//
//            pd.Update(50,_("Segmenting Image"));
//
//            if (Ppts!=NULL)
//            {
//                DestroyImage(&AppData->label);
//                AppData->label = TreeCut(AppData->pred, Ppts);
//            }
//            pd.Update(60,_("Segmenting Image"));
//
//            AppData->checkpoint = 0;
//        }
//        else if (method==ID_Method_KCC)
//        {
//            int Th, area;
//            if (param->type!=ExtraParameters::KCC) return;
//            par_kcc = (KCCExtraParameters *)param;
//            par_kcc->GetParameters(&Th, &area);
//
//            pd.Update(10,_("Segmenting Image"));
//
//            Si = AppData->GetInternalSeeds(1);
//            Se = AppData->GetExternalSeeds(1);
//
//            aux1 = CopyImage(AppData->label);
//            SetImage(aux1, 0);
//
//            ChangeSparseGraphType((AppData->exGraph)->G,
//                                  DISSIMILARITY);
//            pd.Update(30,_("Segmenting Image"));
//
//            KappaConnComp(aux1, (AppData->exGraph)->G,
//                          Si, Se, (float)Th);
//
//            pd.Update(60,_("Segmenting Image"));
//
//            DestroyImage(&AppData->label);
//            AppData->label = AreaClose(aux1, area);
//
//            pd.Update(70,_("Segmenting Image"));
//
//            DestroyImage(&aux1);
//
//            AppData->checkpoint = 0;
//        }
//
//        else if (method==ID_Method_IFT_GC)
//        {
//            if (param->type!=ExtraParameters::IFTGC) return;
//            par_iftgc = (IFTGCExtraParameters *)param;
//            par_iftgc->GetParameters(&measure, &maxorder,
//                                     &lambda, &posproc);
//
//            Si = AppData->GetInternalSeeds(1);
//            Se = AppData->GetExternalSeeds(1);
//
//            pd.Update(10,_("Segmenting Image"));
//
//            SetImage(AppData->label, 0);
//
//            ChangeSparseGraphType((AppData->exGraph)->G,
//                                  CAPACITY);
//
//            pd.Update(40,_("Segmenting Image"));
//
//            IFTGraphCut(AppData->label, AppData->exGraph,
//                        Si, Se, measure,
//                        (float)maxorder,
//                        (float)lambda, posproc);
//
//            pd.Update(70,_("Segmenting Image"));
//
//            AppData->checkpoint = 0;
//        }
//
//        else if (method==ID_Method_MF)
//        {
//            if (param->type!=ExtraParameters::MF) return;
//            par_mf = (MFExtraParameters *)param;
//            par_mf->GetParameters(&lambda);
//
//            Si = AppData->GetInternalSeeds(1);
//            Se = AppData->GetExternalSeeds(1);
//            pd.Update(10,_("Segmenting Image"));
//
//            ChangeSparseGraphType((AppData->exGraph)->G,
//                                  CAPACITY);
//            //MaxFlow(AppData->label, AppData->exGraph,
//            //        Si, Se, (float)lambda);
//            pd.Update(20,_("Segmenting Image"));
//
//            MaxFlowKolmogorov(AppData->label,
//                              AppData->exGraph,
//                              Si, Se, (float)lambda);
//
//            pd.Update(70,_("Segmenting Image"));
//
//            AppData->checkpoint = 0;
//        }
//        else if (method==ID_Method_OPF)
//        {
//            if (param->type!=ExtraParameters::OPF) return;
//
//            int di=0;
//
//            par_opf = (OPFExtraParameters *)param;
//            par_opf->GetParameters(&volume, &area, &kmax, &di);
//
//            pd.Update(10,_("Segmenting Image"));
//
//            if (!(AppData->feat))
//            {
//                return;
//            }
//
//            GetGradOptions(&type, &input, &Wobj);
//
//            DImage* a = GetFeature(AppData->feat,1);
//            DImage* b = GetFeature(AppData->feat,2);
//
//            f = CreateFeatures(AppData->GetWidth(),AppData->GetHeight(),2);
//            SetFeature(f, 0, a);
//            SetFeature(f, 1, b);
//
////            f = AppData->feat;
//
//            if(AppData->sg != NULL) DestroySubgraph(&AppData->sg);
//
//            AppData->sg = APP_CreateSubgraph(f, kmax, di);
//
//            sg = AppData->sg;
//
//            //Si = AppData->GetNewInternalSeeds(AppData->checkpoint, 1);
//            //Se = AppData->GetNewExternalSeeds(AppData->checkpoint, 1);
//            Si = AppData->GetInternalSeeds(1);
//            Se = AppData->GetExternalSeeds(1);
//
//            pd.Update(20,_("Segmenting Image"));
//
//            if (AppData->regions != NULL) DestroyImage(&AppData->regions);
//
//            AppData->regions = APP_FilterPDF(AppData->sg, volume, area);
//            WriteImage(AppData->regions,(char*)"regions.pgm");
//
//            pd.Update(50,_("Segmenting Image"));
//
//
//            if (Si != NULL || Se != NULL)
//            {
//
//                int nlabels = MaximumValue(AppData->regions)+1;
//
//                uchar *mask = AllocUCharArray(nlabels);
//                Set *S = NULL;
//                for (S=Si; S != NULL; S=S->next)
//                {
//                    mask[AppData->regions->val[S->elem]] = 1;
//                }
//                /*
//                for (S=Se; S != NULL; S=S->next) {
//                  mask[AppData->regions->val[S->elem]] = 1;
//                }
//                */
//                ChangeSparseGraphType((AppData->exGraph)->G,
//                                      DISSIMILARITY);
//                pd.Update(60,_("Segmenting Image"));
//
//                aux1 = CopyImage(AppData->cost);
//
//                for (p=0; p<n; p++)
//                {
//                    if (mask[AppData->regions->val[p]] == 0)
//                    {
//                        aux1->val[p] = 0;
//                    }
//                    else
//                    {
//                        aux1->val[p] = INT_MAX;
//                    }
//                }
//
//                free(mask);
//
//                DifferentialIFT(AppData->label, aux1,
//                                AppData->pred, (AppData->exGraph)->G,
//                                Si, Se);
//
//                pd.Update(70,_("Segmenting Image"));
//
//                for (p=0; p<n; p++)
//                {
//                    if (aux1->val[p] != 0)
//                    {
//                        AppData->cost->val[p] = aux1->val[p];
//                    }
//                }
//                //SetImage(AppData->seedMkMap[op], 0);
//                DestroyImage(&aux1);
//                AppData->checkpoint = AppData->markerID;
//            }
//        }
//        else if (method == ID_Method_LWIRE)
//        {
//            bool isOri;
//            ((LWIREExtraParameters *)param)->GetParameters(&isOri);
//            Views[0]->canvas->SetInteractionHandler(new LWireHandler(isOri));
//        }
//        DestroySet(&Si);
//        DestroySet(&Se);
//    }
//
//    else if (op==0) //Pre_proc
//    {
//        AppData->checkpoint = 0;
//
//        GetGradOptions(&type, &input, &Wobj);
//
//        Si = AppData->GetInternalSeeds(0);
//        Se = AppData->GetExternalSeeds(0);
//
//        nscales = 4;
//
//        nsi = GetSetSize(Si);
//        nse = GetSetSize(Se);
//
//        int distmethod = chClassifMethod->GetCurrentSelection();
//
//
//        f  = AppData->feat;
//
//        PrecomputedDistance = 0;
//
//        if (AppData->sg != NULL)
//        {
//            DestroySubgraph(&(AppData->sg));
//        }
//
//        if(prevdistmethod != distmethod || prevnsi != nsi || prevnse != nse)
//        {
//            float acc = -1;
//            newfeats = false;
//            prevdistmethod = distmethod;
//            prevnsi = nsi;
//            prevnse = nse;
//
//            objMap = AppData->objMap;
//            bkgMap = AppData->bkgMap;
//
//            if ((Si!=NULL)&&(Se!=NULL))
//            {
//                switch(chClassifMethod->GetCurrentSelection())
//                {
//                    case 0:
//                        if(objMap != NULL) DestroyImage(&objMap);
//                        if(bkgMap != NULL) DestroyImage(&bkgMap);
//
//                        sg = APP_BestkSubgraph(f, Si, Se, &sgeval, &acc);
//                        pd.Update(30,_("Please wait, estimating graph arc-weights"));
//
//                        APP_ImageDDFMaps(sg, f, Si, Se, &objMap, &bkgMap);
//                        pd.Update(60,_("Please wait, estimating graph arc-weights"));
//                        DestroySubgraph(&sgeval);
//                        DestroySubgraph(&sg);
//
//
//                        /// Uses regular features instead of normalized
//                        /// for gradient estimation
//                        AppData->SetUseNormalized(false);
//                        system("rm -f opfgp_tree_bst.jpg");
//                        break;
//                    case 1:
//                        if(objMap != NULL) DestroyImage(&objMap);
//                        if(bkgMap != NULL) DestroyImage(&bkgMap);
//
//                        objMap = NULL;
//                        bkgMap = NULL;
//                        if(AppData->normfeats == NULL)
//                        {
//                            fprintf(stderr,"\nNormalizing Features...\n");
//                            f = CopyFeatures(AppData->feat);
//                            FNormalizeFeatures(f);
//                            AppData->normfeats = f;
//                        }
//                        f = AppData->normfeats;
//                        sg = APP_OPFLearning(f, Si, Se);
//                        pd.Update(30,_("Please wait, estimating graph arc-weights"));
//                        ImagePVMapsCompGraph(sg, f, &objMap, &bkgMap);
//                        pd.Update(60,_("Please wait, estimating graph arc-weights"));
//                        DestroySubgraph(&sg);
//
//                        /// Uses normalized features instead of regular
//                        /// for gradient estimation
//                        AppData->SetUseNormalized(true);
//                        system("rm -f opfgp_tree_bst.jpg");
//                        break;
//                    case 2:
//                        if(objMap != NULL) DestroyImage(&objMap);
//                        if(bkgMap != NULL) DestroyImage(&bkgMap);
//                        pd.Update(10,_("Please wait, estimating graph arc-weights"));
//
//                        if(AppData->normfeats == NULL)
//                        {
//                            fprintf(stderr,"\nNormalizing Features...\n");
//                            f = CopyFeatures(AppData->feat);
//                            FNormalizeFeatures(f);
//                            AppData->normfeats = f;
//                        }
//                        f = AppData->normfeats;
//
//
//                        pd.Update(20,_("Please wait, estimating graph arc-weights"));
//
//                        ClassifyOPFGP(f,Si,Se, NULL, NULL, &objMap,&bkgMap);
//                        pd.Update(70,_("Please wait, estimating graph arc-weights"));
//
//                        DestroySubgraph(&sg);
//
//                        /// the result is written to opfgp_bst_tree.jpg
//                        /// processing bst gp tree, so that it can be visualized
//                        system("rm -f opfgp_tree_bst.jpg");
//                        system("python visualizetree.py opfgp.bst opfgp_tree_bst.jpg");
//
//                        /// Uses normalized features instead of regular
//                        /// for gradient estimation
//                        AppData->SetUseNormalized(true);
//
//                        /// Displaying gp tree button
//
//                        vsizer->Show(gosizer, true, true);
//                        gosizer->Show(buGPTree, true, true);
//                        vosizer->Layout();
//                        sgsizer->Layout();
//                        vsizer->Layout();
//                        break;
//                }
//
//                AppData->objMap = objMap;
//                AppData->bkgMap = bkgMap;
//
//            }
//
//
//
//            //-------------ObjMap-------------------------
//            //objMap = APP_ImagePDF(sg, f, 1, Si, Se);
//            //objMap = APP_StatisticalReconstruction(fmap, AppData->GetWidth(), AppData->GetHeight(), 1);
//            //-------------BkgMap-------------------------
//            //bkgMap = APP_ImagePDF(sg, f, 0, Si, Se);
//            //bkgMap = APP_StatisticalReconstruction(fmap, AppData->GetWidth(), AppData->GetHeight(), 0);
//            //--------------------------------------
//
//            if(AppData->UseNormalizedFeats() && AppData->normfeats != NULL)
//                f = AppData->normfeats;
//            else
//                f = AppData->feat;
//
//            if (objMap!=NULL && bkgMap==NULL)
//            {
//                bkgMap = Complement(objMap); // not used
//            }
//            else if (objMap==NULL && bkgMap!=NULL)
//            {
//                objMap = Complement(bkgMap); // not used
//            }
//            else if (objMap==NULL && bkgMap==NULL)
//            {
//                objMap = CreateImage(AppData->GetWidth(),AppData->GetHeight());
//                bkgMap = CreateImage(AppData->GetWidth(),AppData->GetHeight());
//            }
//
//            DestroySet(&Si);
//            DestroySet(&Se);
//
//            //-------------Gradient-------------------------
//
//            Wobj  = Wobj / 100.0;
//            fprintf(stderr,"\nGradient...\n");
//            graph = FeatObjMaps2SparseGraph(f,objMap,Wobj);
//            pd.Update(80);
//            //graph = ImgObjMaps2SparseGraph(AppData->orig,objMap,Wobj,AppData->type);
//
//            if(AppData->grad != NULL)
//                DestroyImage(&AppData->grad);
//
//            if(AppData->grad != NULL)
//                DestroyExSparseGraph(&AppData->exGraph);
//
//            AppData->grad = ArcWeightImage(graph);
//            pd.Update(90);
//            AppData->exGraph = SparseGraph2ExSparseGraph(graph,
//                              objMap,
//                              bkgMap);
//
//            pd.Update(100);
//        }else if(prevWobj != Wobj)
//        {
//
//            objMap = AppData->objMap;
//            bkgMap = AppData->bkgMap;
//
//            if(AppData->UseNormalizedFeats())
//                f = AppData->normfeats;
//            else
//                f = AppData->feat;
//
//            //-------------Gradient-------------------------
//
//            Wobj  = Wobj / 100.0;
//
//            graph = FeatObjMaps2SparseGraph(f,objMap,Wobj);
//            pd.Update(70);
//
//            if(AppData->grad != NULL)
//                DestroyImage(&AppData->grad);
//
//            if(AppData->grad != NULL)
//                DestroyExSparseGraph(&AppData->exGraph);
//
//            //graph = ImgObjMaps2SparseGraph(AppData->orig,objMap,Wobj,AppData->type);
//
//            AppData->grad = ArcWeightImage(graph);
//            pd.Update(80);
//            AppData->exGraph = SparseGraph2ExSparseGraph(graph,
//                              objMap,
//                              bkgMap);
//            pd.Update(100);
//        }
//
//    }
//    gettimeofday(&toc,NULL);
//    totaltime = (toc.tv_sec-tic.tv_sec)*1000.0 + (toc.tv_usec-tic.tv_usec)*0.001;
//    printf("\nOnRun Time: %f ms\n",totaltime);
//
//    //app_draw_frames();
//    SetStatusText( _T("Done") );
}

void MyFrame::OnCreateVideo(wxCommandEvent& event)
{
//    static char cut_name[4][50]=
//        {"Mean Cut","Normalized Cut",
//         "Energy func","None"
//        };
//    char command[5000];
//    char filename[2000];
//    Image *label,*cost,*pred,*rank;
//    CImage *plot,*cimg,*frame;
//    VideoOpt opt;
//    FileList *L,*L2;
//    Curve *M;
//    Set *Si,*Se;
//    IFTGCExtraParameters *par;
//    int measure,maxorder,lambda;
//    bool posproc;
//    int delay,iw,i;
//
//    if (!AppData->IsLoaded()) return;
//
//    if ( opt.ShowConfigDialog(this) )
//        return;
//
//    wxWindowDisabler disableAll;
//    wxBusyInfo busy(_T("Please wait, working..."));
//    wxBusyCursor wait;
//    SetStatusText(_T("Please wait - Computation in progress..."));
//    wxTheApp->Yield();
//
//    L = CreateFileList(opt.nframes);
//    AddFiles(L,(char*)"./out", (char*)"frame", 1,
//             opt.nframes, (char*)".ppm");
//
//    if (param->type==ExtraParameters::IFTGC)
//    {
//        par = (IFTGCExtraParameters *)param;
//        par->GetParameters(&measure, &maxorder,
//                           &lambda, &posproc);
//    }
//    else
//    {
//        measure = 0;
//        maxorder = 100;
//        lambda = 40;
//        posproc = false;
//    }
//
//    Si = AppData->GetInternalSeeds(1);
//    Se = AppData->GetExternalSeeds(1);
//    label = CreateImage(AppData->GetWidth(), AppData->GetHeight());
//    cost  = CreateImage(AppData->GetWidth(), AppData->GetHeight());
//    pred  = CreateImage(AppData->GetWidth(), AppData->GetHeight());
//    rank  = CreateImage(AppData->GetWidth(), AppData->GetHeight());
//    ChangeSparseGraphType((AppData->exGraph)->G,
//                          CAPACITY);
//
//    M = IFTVideo(label, cost, pred, rank,
//                 AppData->exGraph,
//                 Si, Se, measure,
//                 (float)maxorder, (float)lambda);
//
//    switch (event.GetId())
//    {
//    case ID_VideoDIFT:
//        WriteIFTVideoFrames(AppData->orig,
//                            label, rank,
//                            Si, Se, false,
//                            AppData->objColor,
//                            AppData->bkgColor,
//                            opt.w, opt.h, L);
//        break;
//    case ID_VideoTP:
//        WriteTPVideoFrames(AppData->orig,
//                           pred, Si,
//                           AppData->objColor,
//                           AppData->bkgColor,
//                           opt.w, opt.h, L);
//        break;
//    case ID_VideoIFTGC:
//        iw = MIN(opt.w/2, label->ncols+20);
//        WriteIFTVideoFrames(AppData->orig,
//                            label, rank,
//                            Si, Se, true,
//                            AppData->objColor,
//                            AppData->bkgColor,
//                            iw, opt.h, L);
//        L2 = CreateFileList(opt.nframes);
//        AddFiles(L2,(char*)"./out", (char*)"plot", 1,
//                 opt.nframes, (char*)".ppm");
//        FastWritePlotVideoFrames(M, cut_name[measure],
//                                 (char*)"Propagation order (%)",
//                                 cut_name[measure],
//                                 AppData->objColor,
//                                 AppData->bkgColor,
//                                 opt.w-iw, opt.h, L2);
//        MergeCImageList(L, L2, L);
//        plot = PlotCurve(M, opt.w-iw, opt.h,
//                         NULL, NULL,
//                         cut_name[measure],
//                         (char*)"Propagation order (%)",
//                         cut_name[measure],
//                         AppData->objColor,
//                         AppData->bkgColor,
//                         true);
//        cimg = IFTVideoFrame(GetMinimumCurveIndex(M),
//                             AppData->orig,
//                             label, rank,
//                             Si, Se, true,
//                             AppData->objColor,
//                             AppData->bkgColor,
//                             iw, opt.h);
//        frame = MergeCImages(cimg, plot);
//        opt.nframes++;
//        sprintf(filename,(char*)"./out/frame%03d.ppm",opt.nframes);
//        WriteCImage(frame,filename);
//
//        DeleteFilesInFileList(L2);
//        DestroyFileList(&L2);
//        DestroyCImage(&frame);
//        DestroyCImage(&plot);
//        DestroyCImage(&cimg);
//        break;
//    case ID_VideoKCC:
//        iw = MIN(opt.w/2, label->ncols+20);
//        Curve *nhist = NormHistogram(cost);
//        Curve *rhist = RemoveEmptyBins(nhist);
//        Curve *fhist = CreateCurve(rhist->n+1);
//        fhist->X[0] = 0.0;
//        fhist->Y[0] = 0.0;
//        for (i=0; i<rhist->n; i++)
//        {
//            fhist->Y[i+1] = 100.0*rhist->Y[i];
//            fhist->X[i+1] = rhist->X[i];
//        }
//
//        WriteKCCVideoFrames(AppData->orig,
//                            label, cost,
//                            Si, Se, false,
//                            AppData->objColor,
//                            AppData->bkgColor,
//                            iw, opt.h, L);
//        L2 = CreateFileList(opt.nframes);
//        AddFiles(L2,(char*)"./out", (char*)"plot", 1,
//                 opt.nframes, (char*)".ppm");
//        //"CT-bone Segmentation",
//        //"MR-wrist Segmentation"
//        FastWritePlotVideoFrames(fhist,
//                                 (char*)"",
//                                 (char*)"optimum-path costs",
//                                 (char*)"wavefront area (%)",
//                                 AppData->objColor,
//                                 AppData->bkgColor,
//                                 opt.w-iw, opt.h, L2);
//        MergeCImageList(L, L2, L);
//
//        DeleteFilesInFileList(L2);
//        DestroyFileList(&L2);
//        DestroyCurve(&nhist);
//        DestroyCurve(&rhist);
//        DestroyCurve(&fhist);
//        break;
//    }
//
//    sprintf(filename,"./out/frame%03d.ppm",opt.nframes);
//    frame = ReadCImage(filename);
//
//    for (i=1; i<=2*opt.fps; i++)
//    {
//        sprintf(filename,"./out/frame%03d.ppm",opt.nframes+i);
//        WriteCImage(frame,filename);
//        AddFile(L, filename);
//    }
//    DestroyCImage(&frame);
//
//    switch (opt.type)
//    {
//    case VideoOpt::GIF:
//        delay = ROUND(100.0/opt.fps);
//        sprintf(command,"convert -delay %d -loop 1 ./out/*.ppm ./out/anim.gif",delay);
//        system(command);
//        sprintf(command,"rm ./out/*.ppm -f");
//        system(command);
//        break;
//    case VideoOpt::AVI:
//        ConvertCImageList2jpeg(L);
//        sprintf(command,"rm ./out/*.ppm -f");
//        system(command);
//        sprintf(command,"mencoder mf://out/*.jpg -mf w=%d:h=%d:fps=%d:type=jpg -ovc lavc -lavcopts vcodec=msmpeg4 -oac copy -o out/anim.avi",opt.w,opt.h,opt.fps);
//        system(command);
//        sprintf(command,"rm ./out/*.jpg -f");
//        system(command);
//        break;
//    }
//    DestroyFileList(&L);
//    DestroyCurve(&M);
//    DestroySet(&Si);
//    DestroySet(&Se);
//    DestroyImage(&label);
//    DestroyImage(&cost);
//    DestroyImage(&pred);
//    DestroyImage(&rank);
}

void MyFrame::OnSelectView(wxCommandEvent & event)
{
    //printf("event  id: %d\n",event.GetId());
    int viewtype;
    int w,h,min;
    viewtype = event.GetId();

    if (viewtype == ID_View0) this->UniformView();

    else
    {
        min = splitter->GetMinimumPaneSize();
        splitter->GetSize(&w, &h);
        if (viewtype < ID_View3)
        {
            splitter->SetSashPosition(h - min - 1, true);

            min = topWindow->GetMinimumPaneSize();
            topWindow->GetSize(&w, &h);
            if (viewtype == ID_View1)
                topWindow->SetSashPosition(w - min - 1, true);
            else
                topWindow->SetSashPosition(min, true);
        }

        else
        {
            splitter->SetSashPosition(min, true);

            min = bottomWindow->GetMinimumPaneSize();
            bottomWindow->GetSize(&w, &h);
            if (viewtype == ID_View3)
                bottomWindow->SetSashPosition(w - min - 1, true);
            else
                bottomWindow->SetSashPosition(min, true);
        }
    }
}

void MyFrame::OnChangeMethod(wxCommandEvent& WXUNUSED(event))
{
//    int method;
//
//    if (param != NULL) delete param;
//
//    GetMethod(&method);
//
//    if (method==ID_Method_IFT_GC)
//    {
//        param = new IFTGCExtraParameters(panel, prsizer);
//    }
//    else if (method==ID_Method_MF)
//    {
//        param = new MFExtraParameters(panel, prsizer);
//    }
//    else if (method==ID_Method_TP)
//    {
//        param = new TPExtraParameters(panel, prsizer);
//    }
//    else if (method==ID_Method_DIFT)
//    {
//        param = new DIFTExtraParameters(panel, prsizer);
//    }
//    else if (method==ID_Method_KCC)
//    {
//        param = new KCCExtraParameters(panel, prsizer);
//    }
//    else if (method == ID_Method_OPF) //ID_Method_OPF
//    {
//        param = new OPFExtraParameters(panel, prsizer);
//    }
//    else if (method==ID_Method_LWIRE)
//    {
//        param = new LWIREExtraParameters(panel, prsizer);
//        //app_reset_frame();
//    }
//
//    if (method == ID_Method_LWIRE)
//    {
//        bool isOri;
//        ((LWIREExtraParameters *)param)->GetParameters(&isOri);
////        Views[0]->canvas->SetInteractionHandler(new LWireHandler(isOri));
//        toolBar->EnableTool(ID_Clean_Markers,false);
//        toolBar->EnableTool(ID_Run,false);
//    }
//    else
//    {
//        int r = GetBrushSize();
////        Views[0]->canvas->SetInteractionHandler(new ImageMode::AddMarkersHandler(r,"SEG"));
//        toolBar->EnableTool(ID_Clean_Markers,true);
//        toolBar->EnableTool(ID_Run,true);
//    }
//
//    param->RefreshParametersLayout();
//    vsizer->SetSizeHints(panel);
//    prsizer->Layout();
//    vsizer->Layout();
//    if (GetSizer()!=NULL)
//        GetSizer()->Layout();
//    //app_draw_frames();
}

void MyFrame::OnChangeHighlight(wxCommandEvent& WXUNUSED(event))
{
    //app_draw_frames();
}

void MyFrame::OnChangeGradOpt(wxCommandEvent& WXUNUSED(event))
{
    //app_draw_frames();
}

void MyFrame::OnChangeMarkerOnOff(wxCommandEvent& WXUNUSED(event))
{
    //app_draw_frames();
}

void MyFrame::OnChangeBorderMk(wxCommandEvent& WXUNUSED(event))
{
//    if (!AppData->IsLoaded()) return;
//    RefreshBorderMk();
    //app_draw_frames();
}

void MyFrame::OnChangeOri(wxCommandEvent& event)
{
//    bool isOri;
//    ((LWIREExtraParameters*)param)->GetParameters(&isOri);
//
//    if (isOri == true)
//        Views[0]->canvas->SetInteractionHandler(new LWireHandler(true));
//    else
//        Views[0]->canvas->SetInteractionHandler(new LWireHandler(false));

}

void MyFrame::OnShowTieZones(wxCommandEvent& WXUNUSED(event))
{
//    CImage *cimg;
//    Image *tzones;
//    int method,p,n;
//    Set *Si=NULL,*Se=NULL;
//
//    if (!AppData->IsLoaded()) return;
//
//    n = AppData->GetWidth()*AppData->GetHeight();
//    GetMethod(&method);
//    if (method!=ID_Method_DIFT)
//        return;
//    if (AppData->type==TXT_GRAPH)
//        return;
//
//    if ( AppData->bpp>8 )
//    {
//        cimg = (CImage*)calloc(1,sizeof(CImage));
//        cimg->C[0] = ConvertToNbits((AppData->orig)->C[0], 8);
//        cimg->C[1] = ConvertToNbits((AppData->orig)->C[1], 8);
//        cimg->C[2] = ConvertToNbits((AppData->orig)->C[2], 8);
//    }
//    else
//        cimg = CopyCImage(AppData->orig);
//
//    Si = AppData->GetInternalSeeds(1);
//    Se = AppData->GetExternalSeeds(1);
//    ChangeSparseGraphType((AppData->exGraph)->G,
//                          DISSIMILARITY);
//    tzones = GetTieZones((AppData->exGraph)->G, Si, Se);
//
//    for (p=0; p<n; p++)
//    {
//        if (tzones->val[p]>0)
//        {
//            (cimg->C[0])->val[p] = t0(AppData->objColor);
//            (cimg->C[1])->val[p] = t1(AppData->objColor);
//            (cimg->C[2])->val[p] = t2(AppData->objColor);
//        }
//    }
//    WriteCImage(cimg, (char*)"tiezones.ppm");
//    DisplayImage(_("tiezones.ppm"));
//
//    DestroySet(&Si);
//    DestroySet(&Se);
//    DestroyCImage(&cimg);
//    DestroyImage(&tzones);
}


void MyFrame::OnRepeatTrainingSeeds(wxCommandEvent& WXUNUSED(event))
{
//    DestroyImage(&(AppData->seedLbMap[1]));
//    DestroyImage(&(AppData->seedMkMap[1]));
//    AppData->seedLbMap[1] = CopyImage(AppData->seedLbMap[0]);
//    AppData->seedMkMap[1] = CopyImage(AppData->seedMkMap[0]);
//    AppData->checkpoint = 0;
//    //app_draw_frames();
}

void MyFrame::OnShowTopology(wxCommandEvent& WXUNUSED(event))
{
//    CImage *cimg;
//    Image *path,*aux1,*aux2,*img;
//    Set *B=NULL;
//    int method,p,n;
////    GraphDrawOptions opt;
////    SparseGraph *sg;
////    Image *nodecolor,*bkgcolor,*nodeval;
////    Set *S=NULL;
////    int color,Imax;
//
//    if (!AppData->IsLoaded()) return;
//
//    n = AppData->GetWidth()*AppData->GetHeight();
//    GetMethod(&method);
//    if (method!=ID_Method_TP) return;
//
//    B = AppData->GetExternalSeeds(1);
//    path = DescendantCount(AppData->pred, B);
//
//    if (AppData->type==TXT_GRAPH)
//    {
//
//    }
//    else
//    {
//        if (AppData->type==COLOR_IMAGE)
//        {
//            cimg = CImageRGBtoYCbCr(AppData->orig);
//            aux1 = CopyImage(cimg->C[0]);
//            DestroyCImage(&cimg);
//        }
//        else //GREY_IMAGE
//            aux1 = CopyImage((AppData->orig)->C[0]);
//
//        img = ConvertToNbits(aux1, 7);
//        DestroyImage(&aux1);
//        aux2 = ConvertToNbits(path, 8);
//
//        cimg = CreateCImage(AppData->GetWidth(), AppData->GetHeight());
//        for (p=0; p<n; p++)
//        {
//            if (aux2->val[p]>0)
//            {
//                (cimg->C[0])->val[p] = ROUND((float)(aux2->val[p]/255.0) * t0(AppData->objColor));
//                (cimg->C[1])->val[p] = ROUND((float)(aux2->val[p]/255.0) * t1(AppData->objColor));
//                (cimg->C[2])->val[p] = ROUND((float)(aux2->val[p]/255.0) * t2(AppData->objColor));
//            }
//            else
//            {
//                (cimg->C[0])->val[p] = img->val[p];
//                (cimg->C[1])->val[p] = img->val[p];
//                (cimg->C[2])->val[p] = img->val[p];
//    app_reset_frame();        }
//        }
//        WriteCImage(cimg, (char*)"topology.ppm");
//
//        DisplayImage(_("topology.ppm"));
//
//        DestroyCImage(&cimg);
//        aux1 = LabelTrees(AppData->pred);
//        WriteImage(aux1,(char*)"trees.pgm");
//        cimg = ColourLabels(AppData->orig, aux1, 2.9, true);
//        WriteCImage(cimg, (char*)"trees.ppm");
//
//        DestroyImage(&img);
//        DestroyImage(&aux1);
//        DestroyImage(&aux2);
//    }
//
//    DestroyImage(&path);
//    DestroyCImage(&cimg);
//    DestroySet(&B);
}

void MyFrame::OnFilterPDF(wxCommandEvent& WXUNUSED(event))
{

//    int method=NIL,volume=0, area=0, kmax=0;
//    OPFExtraParameters *par_opf = NULL;
//
//    if (!AppData->IsLoaded() || !AppData->sg) return;
//
//    GetMethod(&method);
//    if (method==ID_Method_OPF)
//    {
//
//        if (param->type!=ExtraParameters::OPF) return;
//        int di = 0;
//
//        par_opf = (OPFExtraParameters *)param;
//        par_opf->GetParameters(&volume, &area,&kmax, &di);
//
//        SetStatusText( _T("Filtering...") );
//
//        if (AppData->regions)
//        {
//            DestroyImage(&AppData->regions);
//        }
//        AppData->regions = APP_FilterPDF(AppData->sg, volume, area);
//
//        //app_draw_frames();
//        SetStatusText( _T("Done") );
//
//    }
}


void MyFrame::OnShowPlot(wxCommandEvent& WXUNUSED(event))
{
//    char command[200];
//    int method;
//
//    if (!AppData->IsLoaded()) return;
//
//    GetMethod(&method);
//    if (method==ID_Method_IFT_GC)
//    {
//        sprintf(command,"gnuplot \"plot.plt\"");
//        system(command);
////        sprintf(command,"display plot.eps &");
//        DisplayImage(_("plot.eps"));
//
//    }
}


void MyFrame::OnChangeMaxOrd(wxSpinEvent& WXUNUSED(event))
{
//    IFTGCExtraParameters *aux;
//    //printf("Class: %s\n",typeid( *param ).name());
//
//    if (param->type!=ExtraParameters::IFTGC) return;
//    aux = (IFTGCExtraParameters *)param;
//
//    if ( aux->GetAutoRun() )
//    {
//        wxCommandEvent event(0,0);
//        OnRun(event);
//    }
}

void MyFrame::RefreshBorderMk()
{
//    if ( param->GetBorderMk() )
//    {
//        AppData->markerID++;
//        AppData->DrawBorderMarker(AppData->markerID);
//    }
//    else
//    {
//        AppData->DrawBorderMarker(0);
//        AppData->checkpoint = 0;
//    }
}

void MyFrame::DisplayImage(wxString filename)
{
    wxImage img(filename,wxBITMAP_TYPE_ANY);

    DisplayImage(img, filename);
}

void MyFrame::DisplayImage(wxImage& img, wxString filename)
{
    if (!img.Ok()) return;

    wxBitmap bmp(img);

    int width = bmp.GetWidth();
    int height = bmp.GetHeight();

    wxFrame* frame = new wxFrame(NULL, wxID_ANY, filename, wxDefaultPosition, wxSize(width,height));

    wxScrolledWindow* sw = new wxScrolledWindow(frame);

    wxStaticBitmap* sb = new wxStaticBitmap(sw, -1, bmp);

    sw->SetScrollbars(10, 10, width/10, height/10);
    sw->Scroll(10,10);

    frame->Show();

}

void MyFrame::DisplayImage(CImage* cimg, wxString filename)
{
    wxImage* img = ConvertToWXImage(cimg);

    DisplayImage(*img, filename);
}

void MyFrame::OnShowGPTree(wxCommandEvent& event)
{
//    if (AppData->GetImg("objMap") != NULL)
//        DisplayImage(_("opfgp_tree_bst.jpg"));
}

void MyFrame::OnChooseClassif(wxCommandEvent& event)
{
    if (chClassifMethod->GetSelection() == 2)
    {
        vsizer->Show(gosizer, true, true);
        gosizer->Show(buGPTree, true, true);
        vosizer->Layout();
        sgsizer->Layout();
        vsizer->Layout();
    }
    else
    {
        gosizer->Hide(buGPTree,true);
    }
}


void MyFrame::UniformView()
{
    int w,h;
    /*
    this->splitter->Layout();
    this->topWindow->Layout();
    this->bottomWindow->Layout();
    this->splitter->Update();
    this->topWindow->Update();
    this->bottomWindow->Update();
    */
    splitter->GetSize(&w, &h);
    splitter->SetSashPosition(h/2, true);

    topWindow->GetSize(&w, &h);
    topWindow->SetSashPosition(w/2, true);

    bottomWindow->GetSize(&w, &h);
    bottomWindow->SetSashPosition(w/2, true);
}

