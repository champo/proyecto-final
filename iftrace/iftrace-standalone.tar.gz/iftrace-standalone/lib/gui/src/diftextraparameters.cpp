#include "diftextraparameters.h"

#ifndef _VIDEO_XPM_
#define _VIDEO_XPM_
#include "video.xpm"
#endif

DIFTExtraParameters :: DIFTExtraParameters(wxWindow *parent,
					   wxSizer  *sizer)
  : ExtraParameters(parent, sizer){
  this->type = DIFT;
  buTieZones = new wxButton(parent, ID_ButTieZones, _T("Show TieZones"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("button1"));

  hbsTieZones = new wxBoxSizer(wxHORIZONTAL);
  hbsTieZones->Add(buTieZones, 1, wxALIGN_CENTER);
  sizer->Add(hbsTieZones, 0, wxEXPAND);

  wxStaticText *tVideo = new wxStaticText(parent, -1, _T("Region Growing"), wxDefaultPosition, wxDefaultSize, wxALIGN_LEFT, _T("staticText1"));

  wxBitmap *bmVideo = new wxBitmap(video_xpm);
  buVideo = new wxBitmapButton(parent, ID_VideoDIFT, *bmVideo, wxDefaultPosition, wxDefaultSize, wxBU_AUTODRAW, wxDefaultValidator, _T("b_video"));

  hbsVideo = new wxBoxSizer(wxHORIZONTAL);
  hbsVideo->Add(tVideo,  0, wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL);
  hbsVideo->Add(buVideo, 0, wxALIGN_LEFT);
  sizer->Add(hbsVideo, 0, wxEXPAND);
}

void DIFTExtraParameters :: RefreshParametersLayout(){}
