#include "opfextraparameters.h"

OPFExtraParameters :: OPFExtraParameters(wxWindow *parent,
        wxSizer  *sizer)
        : ExtraParameters(parent, sizer)
{
    this->type = OPF;
    wxStaticText *tVolumeOpen = new wxStaticText(parent, -1, _T("Volume Opening"), wxDefaultPosition, wxDefaultSize, wxALIGN_LEFT, _T("staticText1"));
    spVolumeOpen = new wxSpinCtrl(parent, ID_VolumeOpen, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxSP_ARROW_KEYS, 1, 99000, 10000, _T("wxSpinCtrl1"));

    wxStaticText *tAreaOpen = new wxStaticText(parent, -1, _T("Area Merge"), wxDefaultPosition, wxDefaultSize, wxALIGN_LEFT, _T("staticText2"));
    spAreaOpen = new wxSpinCtrl(parent, ID_AreaOpen, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxSP_ARROW_KEYS, 1, 500, 10, _T("wxSpinCtrl2"));

    wxStaticText *tKmax   = new wxStaticText(parent, -1, _T("Kmax"), wxDefaultPosition, wxDefaultSize, wxALIGN_LEFT, _T("staticText5"));
    spKmax = new wxSpinCtrl(parent, ID_Kmax, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxSP_ARROW_KEYS, 1, 500, 25, _T("wxSpinCtrl1"));

    wxStaticText *tImageBand = new wxStaticText(parent, -1, _T("Image Bandwidth"), wxDefaultPosition, wxDefaultSize, wxALIGN_LEFT, _T("staticText3"));
    spImageBand = new wxSpinCtrl(parent, ID_ImageBand, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxSP_ARROW_KEYS, 1, 100, 5, _T("wxSpinCtrl1"));

    hbsKmax      = new wxBoxSizer(wxHORIZONTAL);
    hbsKmax->Add(tKmax,  1, wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL);
    hbsKmax->Add(spKmax, 0, wxALIGN_RIGHT);
    sizer->Add(hbsKmax,  0, wxEXPAND);

    hbsVolumeOpen = new wxBoxSizer(wxHORIZONTAL);
    hbsVolumeOpen->Add(tVolumeOpen,  1, wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL);
    hbsVolumeOpen->Add(spVolumeOpen, 0, wxALIGN_RIGHT);
    sizer->Add(hbsVolumeOpen,    0, wxEXPAND);

    hbsAreaOpen = new wxBoxSizer(wxHORIZONTAL);
    hbsAreaOpen->Add(tAreaOpen, 1, wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL);
    hbsAreaOpen->Add(spAreaOpen, 0, wxALIGN_RIGHT);
    sizer->Add(hbsAreaOpen, 0, wxEXPAND);

    hbsImageBand = new wxBoxSizer(wxHORIZONTAL);
    hbsImageBand = new wxBoxSizer(wxHORIZONTAL);
    hbsImageBand->Add(tImageBand, 1, wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL);
    hbsImageBand->Add(spImageBand, 0, wxALIGN_RIGHT);
    sizer->Add(hbsImageBand, 0, wxEXPAND);

    buFilterPDF=  new wxButton(parent, ID_ButFilterPDF, _T("Filter PDF and merge regions"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("button1"));

    hbsFilterPDF = new wxBoxSizer(wxHORIZONTAL);
    hbsFilterPDF->Add(buFilterPDF, 0, wxALIGN_RIGHT);
    sizer->Add(hbsFilterPDF, 0, wxEXPAND);
}

void OPFExtraParameters::GetParameters(int *volume, int *area, int *kmax, int *di)
{
    *volume = spVolumeOpen->GetValue();
    *area  = spAreaOpen->GetValue();
    *kmax = spKmax->GetValue();
    *di = spImageBand->GetValue();
}

void OPFExtraParameters :: RefreshParametersLayout(){}
