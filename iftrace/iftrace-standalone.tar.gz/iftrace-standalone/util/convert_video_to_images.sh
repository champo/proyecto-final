#! /bin/bash

if [ $# -eq 2 ]
then
    ffmpeg -i $1 -r $2 -f image2 %05d.ppm
elif [ $# -eq 3 ]
then
    ffmpeg -i $1 -r $2 -f image2  %05d.$3
# Converts and rotates video
elif [ $# -eq 4 ]
then
    ffmpeg -i $1 -r $2 -f image2  -vf "transpose=$4" %05d.$3
else
    echo "usage: $0 [video file name] [fps]  <output file type - default ppm> <tranpose video {0,1,2,3}>";
    exit 1;
fi

