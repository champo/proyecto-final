#! /bin/bash

if [ $# -lt 4 ]; then
    echo "usage: $0 <output folder>  <input folder> <image type> <output image type> [output frame name]";
    exit 1;
fi

j=1;
mkdir -p $1
frame_name="frame"
if [ $# -ge 5 ]; then
    frame_name=$5
fi

for i in $(ls $2/*.$3); do
   number=`printf "%05d" $j`;
   mkdir -p $1/$number;
   if [ $3 != "ppm" ]
   then
       mv $i $1/$number/$frame_name.$3;
   else
       mv $i $1/$number/$frame_name.ppm
   fi
   #echo $i;
   #echo $j;
   echo $number;
   let j=$j+1;
done

mogrify -format $4 $1/*/$frame_name.$3

